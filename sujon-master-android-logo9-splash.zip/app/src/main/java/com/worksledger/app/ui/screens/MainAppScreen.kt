package com.worksledger.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.activity.compose.BackHandler
import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.worksledger.app.sync.GoogleDriveSyncManager
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import com.worksledger.app.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.worksledger.app.data.AppDao
import com.worksledger.app.data.SettingsEntity
import com.worksledger.app.ui.theme.*

sealed class Screen {
    data class Main(val tab: String) : Screen()
    object MonthlyHisab : Screen()
    data class WorkerStatement(val workerId: String, val initialDate: String?) : Screen()
    data class SiteDetail(val siteId: String) : Screen()
    data class PhotoEditor(val noteId: String) : Screen()
    object Settings : Screen()
}

@Composable
fun MainAppScreen(dao: AppDao) {
    val settingsState by dao.getSettings().collectAsState(initial = null)
    val settings = settingsState ?: SettingsEntity()

    // Lock must be derived from the loaded settings, not from the first
    // composition (when settings are still null). Otherwise a PIN-enabled
    // app opens unlocked after restart - the old remember() bug.
    var unlocked by remember { mutableStateOf(false) }
    var showSplash by remember { mutableStateOf(true) }
    val isLocked = settings.pinLockEnabled && settings.pinCode.isNotEmpty() && !unlocked
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Main("overview")) }

    // System back must return to the main tab from any detail screen, never
    // exit the app. Previously there was no BackHandler, so pressing system
    // back in the photo editor (especially when its top bar was hidden by a
    // large/zoomed photo) closed the whole app instead of going to Notes.
    BackHandler(enabled = currentScreen !is Screen.Main) {
        currentScreen = when (val s = currentScreen) {
            is Screen.MonthlyHisab -> Screen.Main("overview")
            is Screen.WorkerStatement -> Screen.Main("team")
            is Screen.SiteDetail -> Screen.Main("sites")
            is Screen.PhotoEditor -> Screen.Main("notes")
            is Screen.Settings -> Screen.Main("overview")
            else -> Screen.Main("overview")
        }
    }

    // Splash: logo 9 (neon purple) animation, ~2.3s, then the app opens.
    // Uses animateFloatAsState with tween only - no initialValue parameter,
    // no FastOutSlowEasing, no bare launch (those failed to compile before).
    if (showSplash) {
        SplashScreen(onFinished = { showSplash = false })
        return
    }

    if (isLocked) {
        NativeLockScreen(
            correctPin = settings.pinCode,
            onUnlocked = { unlocked = true }
        )
        return
    }

    // Auto-sync: runs at app level, not in Settings. It polls the saved
    // toggle every 30 seconds and uploads a backup whenever Auto Sync is ON
    // and Google is signed in, on ANY screen. It uploads once immediately
    // on app open if the toggle is already ON, then every 30s after that.
    // Failures are silent here; manual "এখনই ব্যাকআপ নিন" still shows its toast.
    val appContext = LocalContext.current
    val rootSyncManager = remember { GoogleDriveSyncManager(appContext) }
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val prefs = appContext.getSharedPreferences("sujon_master_prefs", Context.MODE_PRIVATE)
                if (prefs.getBoolean("autoSyncEnabled", false) && rootSyncManager.getSignedInAccount() != null) {
                    val json = exportDbAsJson(dao, appContext)
                    rootSyncManager.uploadBackupToDrive(json)
                }
            } catch (e: Exception) {
                // Ignore: next 30s cycle retries. Do not crash the app for sync.
            }
            delay(30_000)
        }
    }

    Scaffold(
        bottomBar = {
            if (currentScreen is Screen.Main) {
                val currentTab = (currentScreen as Screen.Main).tab
                NativeBottomNav(
                    currentTab = currentTab,
                    onTabSelected = { currentScreen = Screen.Main(it) },
                    isEnglish = settings.language == "en",
                    themeStart = themeColors(settings.theme).first
                )
            }
        },
        containerColor = PageBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val screen = currentScreen) {
                is Screen.Main -> {
                    when (screen.tab) {
                        "daily" -> NativeDailyScreen(dao = dao, settings = settings)
                        "team" -> NativeTeamScreen(
                            dao = dao,
                            settings = settings,
                            onOpenStatement = { workerId ->
                                currentScreen = Screen.WorkerStatement(workerId, null)
                            }
                        )
                        "sites" -> NativeSitesScreen(
                            dao = dao,
                            settings = settings,
                            onOpenSiteDetail = { siteId ->
                                currentScreen = Screen.SiteDetail(siteId)
                            }
                        )
                        "notes" -> NativeNotesScreen(
                            dao = dao,
                            settings = settings,
                            onOpenEditor = { noteId ->
                                currentScreen = Screen.PhotoEditor(noteId)
                            }
                        )
                        "prices" -> NativePricesScreen(dao = dao, settings = settings)
                        else -> NativeOverviewScreen(
                            dao = dao,
                            settings = settings,
                            onNavigateTab = { currentScreen = Screen.Main(it) },
                            onOpenSettings = { currentScreen = Screen.Settings },
                            onOpenMonthly = { currentScreen = Screen.MonthlyHisab }
                        )
                    }
                }
                is Screen.MonthlyHisab -> {
                    NativeMonthlyHisabScreen(
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("overview") }
                    )
                }
                is Screen.WorkerStatement -> {
                    NativeWorkerStatementScreen(
                        workerId = screen.workerId,
                        initialDate = screen.initialDate,
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("team") }
                    )
                }
                is Screen.SiteDetail -> {
                    NativeSiteDetailScreen(
                        siteId = screen.siteId,
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("sites") }
                    )
                }
                is Screen.PhotoEditor -> {
                    NativePhotoEditorScreen(
                        noteId = screen.noteId,
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("notes") }
                    )
                }
                is Screen.Settings -> {
                    NativeSettingsScreen(
                        dao = dao,
                        settings = settings,
                        onLockNow = { unlocked = false },
                        onBack = { currentScreen = Screen.Main("overview") }
                    )
                }
            }
        }
    }
}

// Bottom Navigation: 6 equal cells, icon above a short single-line label
@Composable
fun NativeBottomNav(
    currentTab: String,
    onTabSelected: (String) -> Unit,
    isEnglish: Boolean,
    themeStart: Color = OceanStart
) {
    data class NavItem(val id: String, val labelBn: String, val labelEn: String, val icon: ImageVector)

    val items = listOf(
        NavItem("overview", "ওভারভিউ", "Overview", Icons.Default.Home),
        NavItem("daily", "ডেইলি", "Daily", Icons.Default.CalendarToday),
        NavItem("team", "টিম", "Team", Icons.Default.People),
        NavItem("sites", "সাইট", "Sites", Icons.Default.Apartment),
        NavItem("notes", "নোট", "Notes", Icons.Default.Description),
        NavItem("prices", "প্রাইস", "Prices", Icons.Default.LocalOffer)
    )

    Surface(
        color = SurfaceColor,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { item ->
                val isSelected = currentTab == item.id
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onTabSelected(item.id) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.labelBn,
                        tint = if (isSelected) themeStart else MutedText,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = if (isEnglish) item.labelEn else item.labelBn,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) themeStart else MutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    // Logo grows 0.3x -> 1x and fades in, text fades in after it.
    // animateFloatAsState has no initialValue parameter in this Compose
    // version, so the start value is a remembered state that LaunchedEffect
    // flips to the target on first composition.
    var scaleTarget by remember { mutableStateOf(0.3f) }
    var alphaTarget by remember { mutableStateOf(0f) }
    val logoScale by animateFloatAsState(
        targetValue = scaleTarget,
        animationSpec = tween(durationMillis = 900),
        label = "logoScale"
    )
    val logoAlpha by animateFloatAsState(
        targetValue = alphaTarget,
        animationSpec = tween(durationMillis = 700),
        label = "logoAlpha"
    )
    val textAlpha by animateFloatAsState(
        targetValue = alphaTarget,
        animationSpec = tween(durationMillis = 600, delayMillis = 800),
        label = "textAlpha"
    )
    LaunchedEffect(Unit) {
        scaleTarget = 1f
        alphaTarget = 1f
        delay(2300)
        onFinished()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF22014E)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                contentDescription = "SUJON MASTER logo",
                modifier = Modifier
                    .size(200.dp)
                    .graphicsLayer(scaleX = logoScale, scaleY = logoScale, alpha = logoAlpha)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "SUJON \u26A1 MASTER",
                color = Color.White.copy(alpha = textAlpha),
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "\u0987\u09B2\u09C7\u0995\u099F\u09CD\u09B0\u09BF\u0995 \u2022 \u09AA\u09CD\u09B2\u09BE\u09AE\u09CD\u09AC\u09BF\u0982 \u2022 \u09B8\u09CD\u09AF\u09BE\u09A8\u09BF\u099F\u09BE\u09B0\u09BF",
                color = Color.White.copy(alpha = 0.85f * textAlpha),
                fontSize = 12.sp
            )
        }
    }
}
