package com.worksledger.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint as AndroidPaint
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.worksledger.app.data.*
import com.worksledger.app.pdf.NativePdfGenerator
import com.worksledger.app.sync.GoogleDriveSyncManager
import com.worksledger.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

// Helper for Bengali number formatting in Kotlin
fun toBengaliNum(num: Any?): String {
    if (num == null) return "০"
    val digits = arrayOf("০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯")
    return num.toString().map { c ->
        if (c in '0'..'9') digits[c - '0'] else c.toString()
    }.joinToString("")
}

fun formatTk(amount: Double, hide: Boolean = false): String {
    if (hide) return "৳ ••••"
    val formatted = String.format("%,.0f", Math.abs(amount))
    val bn = toBengaliNum(formatted)
    return if (amount < 0) "- ৳ $bn" else "৳ $bn"
}

fun themeColors(theme: String): Triple<Color, Color, Color> = when (theme) {
    "sunset" -> Triple(SunsetStart, SunsetMid, SunsetEnd)
    "leaf" -> Triple(LeafStart, LeafMid, LeafEnd)
    else -> Triple(OceanStart, OceanMid, OceanEnd)
}

fun getBengaliWeekday(dateStr: String): String {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        val date = sdf.parse(dateStr) ?: return ""
        val cal = Calendar.getInstance()
        cal.time = date
        when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY -> "শনিবার"
            Calendar.SUNDAY -> "রবিবার"
            Calendar.MONDAY -> "সোমবার"
            Calendar.TUESDAY -> "মঙ্গলবার"
            Calendar.WEDNESDAY -> "বুধবার"
            Calendar.THURSDAY -> "বৃহস্পতিবার"
            Calendar.FRIDAY -> "শুক্রবার"
            else -> ""
        }
    } catch (e: Exception) {
        ""
    }
}

fun formatBengaliDate(dateStr: String): String {
    return try {
        val parts = dateStr.split("-")
        if (parts.size == 3) {
            val d = toBengaliNum(parts[2].toInt())
            val mNum = parts[1].toInt()
            val y = toBengaliNum(parts[0])
            val months = arrayOf("", "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
            val monthName = if (mNum in 1..12) months[mNum] else parts[1]
            "$d $monthName $y"
        } else dateStr
    } catch (e: Exception) {
        dateStr
    }
}

// Reusable Swipe-To-Delete Component (Right to left swipe reveals delete with confirmation)
@Composable
fun SwipeToDeleteContainer(
    onDelete: () -> Unit,
    confirmTitle: String = "মুছে ফেলতে চান?",
    confirmMessage: String = "এই তথ্যটি স্থায়ীভাবে মুছে যাবে। আপনি কি নিশ্চিত?",
    content: @Composable () -> Unit
) {
    var offsetX by remember { mutableStateOf(0f) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = {
                showConfirmDialog = false
                offsetX = 0f
            },
            title = { Text(confirmTitle, fontWeight = FontWeight.Bold, color = InkText) },
            text = { Text(confirmMessage, fontSize = 13.sp, color = MutedText) },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDialog = false
                        offsetX = 0f
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("মুছুন", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showConfirmDialog = false
                        offsetX = 0f
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("বাতিল", color = InkText)
                }
            },
            containerColor = SurfaceColor,
            shape = RoundedCornerShape(20.dp)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
    ) {
        // Red background revealed when swiping left
        if (offsetX < 0) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(ExpenseRed)
                    .padding(end = 20.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("মুছে ফেলুন", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Swipable Foreground Content
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), 0) }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = {
                            if (offsetX < -120f) {
                                showConfirmDialog = true
                            } else {
                                offsetX = 0f
                            }
                        },
                        onDragCancel = { offsetX = 0f },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val newOffset = offsetX + dragAmount.x
                            // Only allow swiping to the left (negative values)
                            if (newOffset <= 0f && newOffset >= -200f) {
                                offsetX = newOffset
                            }
                        }
                    )
                }
        ) {
            content()
        }
    }
}

// 1. Native Overview Screen (Hero ONLY here - Rule 4)
@Composable
fun NativeOverviewScreen(
    dao: AppDao,
    settings: SettingsEntity,
    onNavigateTab: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenMonthly: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val dailyList by dao.getAllDailyEntries().collectAsState(initial = emptyList())
    val workers by dao.getAllWorkers().collectAsState(initial = emptyList())
    val attendance by dao.getAllAttendance().collectAsState(initial = emptyList())
    val sites by dao.getAllSites().collectAsState(initial = emptyList())

    val totalBalance = dailyList.sumOf { if (it.type == "income") it.amount else -it.amount }
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val todayIncome = dailyList.filter { it.date == todayStr && it.type == "income" }.sumOf { it.amount }
    val todayExpense = dailyList.filter { it.date == todayStr && it.type == "expense" }.sumOf { it.amount }
    val todayPresentCount = attendance.count { it.date == todayStr }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Hero Header (Rule 4: ONLY on Overview)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(listOf(themeStart, themeMid, themeEnd)),
                        shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.White)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "SUJON ⚡ MASTER",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "ইলেকট্রিক • প্লাম্বিং • স্যানিটারি লেজার",
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "সুজন ভাই, স্বাগতম",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "${formatBengaliDate(todayStr)} • ${getBengaliWeekday(todayStr)}",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("sunset" to "সানসেট", "ocean" to "ওশান", "leaf" to "লিফ").forEach { (themeKey, themeLabel) ->
                            val isThemeSelected = settings.theme == themeKey
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isThemeSelected) Color.White else Color.White.copy(alpha = 0.2f),
                                        RoundedCornerShape(20.dp)
                                    )
                                    .clickable {
                                        coroutineScope.launch {
                                            dao.updateSettings(settings.copy(theme = themeKey))
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = themeLabel,
                                    color = if (isThemeSelected) InkText else Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Balance Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = InkText)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "হাতে নগদ ব্যালেন্স (In Hand)", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                        IconButton(onClick = {
                            coroutineScope.launch {
                                dao.updateSettings(settings.copy(hideMoney = !settings.hideMoney))
                            }
                        }) {
                            Icon(
                                imageVector = if (settings.hideMoney) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "টাকা লুকান / দেখান",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Text(
                        text = formatTk(totalBalance, settings.hideMoney),
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("আজকের আয়", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                                Text(formatTk(todayIncome, settings.hideMoney), color = Color(0xFF7DFFC4), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("আজকের খরচ", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                                Text(formatTk(todayExpense, settings.hideMoney), color = Color(0xFFFFC9A8), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Quick Actions (Exactly 4 cards)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text("দ্রুত অ্যাকশন", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = InkText)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionCard(modifier = Modifier.weight(1f), icon = Icons.Default.Add, label = "নতুন হিসাব", tint = themeStart) { onNavigateTab("daily") }
                    ActionCard(modifier = Modifier.weight(1f), icon = Icons.Default.People, label = "হাজিরা", tint = themeStart) { onNavigateTab("team") }
                    ActionCard(modifier = Modifier.weight(1f), icon = Icons.Default.Apartment, label = "সাইট হিসাব", tint = themeStart) { onNavigateTab("sites") }
                    ActionCard(modifier = Modifier.weight(1f), icon = Icons.Default.LocalOffer, label = "দরদাম", tint = themeStart) { onNavigateTab("prices") }
                }
            }
        }

        // Monthly Hisab CTA
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("মাসিক হিসাব বিবরণী", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkText)
                    Text("প্রতি মাসের মোট আয়, খরচ ও লাভ-ক্ষতির সম্পূর্ণ তালিকা দেখুন", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onOpenMonthly,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                    ) {
                        Text("মাসিক হিসাব দেখুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ActionCard(modifier: Modifier = Modifier, icon: ImageVector, label: String, tint: Color = OceanStart, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(10.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFFE0F7F6), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = tint)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = InkText, textAlign = TextAlign.Center)
        }
    }
}

// 2. Native Daily Screen (Bug 1 & 10 Fixed: Full New Entry Dialog + Swipe to Delete)
@Composable
fun NativeDailyScreen(dao: AppDao, settings: SettingsEntity) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val dailyList by dao.getAllDailyEntries().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()
    var showDialog by remember { mutableStateOf(false) }

    // Dialog state
    var entryType by remember { mutableStateOf("income") } // "income" or "expense"
    var details by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    var dateText by remember { mutableStateOf(todayStr) }
    var errorMessage by remember { mutableStateOf("") }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text("নতুন হিসাব যোগ করুন", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = InkText)
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Text("বেছে নেওয়া তারিখের হিসাবে যুক্ত ও সংরক্ষিত হবে।", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Type Toggle: + আয় / - খরচ
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { entryType = "income" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (entryType == "income") IncomeGreen else Color(0xFFF1F5F9),
                                contentColor = if (entryType == "income") Color.White else InkText
                            )
                        ) {
                            Text("+ আয়", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { entryType = "expense" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (entryType == "expense") ExpenseRed else Color(0xFFF1F5F9),
                                contentColor = if (entryType == "expense") Color.White else InkText
                            )
                        ) {
                            Text("- খরচ", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text("বিবরণ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = details,
                        onValueChange = { details = it },
                        placeholder = { Text("যেমন: সাইট পেমেন্ট / মালামাল ক্রয়", fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("টাকা (৳)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        placeholder = { Text("৫০০০", fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("তারিখ (YYYY-MM-DD)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = dateText,
                        onValueChange = { dateText = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true
                    )

                    if (errorMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(errorMessage, color = ExpenseRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = amountText.toDoubleOrNull()
                        if (details.isBlank()) {
                            errorMessage = "বিবরণ লিখুন"
                            return@Button
                        }
                        if (amount == null || amount <= 0) {
                            errorMessage = "সঠিক টাকার পরিমাণ দিন"
                            return@Button
                        }
                        coroutineScope.launch {
                            val newEntry = DailyEntity(
                                id = UUID.randomUUID().toString(),
                                type = entryType,
                                details = details.trim(),
                                amount = amount,
                                date = dateText.trim(),
                                createdAt = System.currentTimeMillis()
                            )
                            dao.insertDailyEntry(newEntry)
                            showDialog = false
                            details = ""
                            amountText = ""
                            errorMessage = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("যোগ করুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDialog = false },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("বাতিল", color = InkText)
                }
            },
            containerColor = SurfaceColor,
            shape = RoundedCornerShape(22.dp)
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Daily accounts / দৈনিক হিসাব", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
            IconButton(onClick = {
                coroutineScope.launch {
                    dao.updateSettings(settings.copy(hideMoney = !settings.hideMoney))
                }
            }) {
                Icon(
                    imageVector = if (settings.hideMoney) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = "টাকা লুকান / দেখান",
                    tint = InkText,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                dateText = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                showDialog = true
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = themeStart)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("+ নতুন এন্ট্রি", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (dailyList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("কোনো হিসাব পাওয়া যায়নি। নতুন এন্ট্রি যোগ করুন।", color = MutedText, fontSize = 13.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(dailyList, key = { it.id }) { entry ->
                    SwipeToDeleteContainer(
                        onDelete = {
                            coroutineScope.launch { dao.deleteDailyEntryById(entry.id) }
                        },
                        confirmTitle = "এন্ট্রি মুছে ফেলবেন?",
                        confirmMessage = "${entry.details} (${formatTk(entry.amount)}) মুছে ফেলতে চান?"
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(entry.details, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkText)
                                    Text("${formatBengaliDate(entry.date)} • ${getBengaliWeekday(entry.date)}", fontSize = 11.sp, color = MutedText)
                                }
                                Text(
                                    text = (if (entry.type == "income") "+ " else "- ") + formatTk(entry.amount, settings.hideMoney),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (entry.type == "income") IncomeGreen else ExpenseRed,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. Native Team Screen (Bug 2, 5, 6, 10 Fixed: ৳ টাকা দিন, + OT, Add Worker, Attendance tap-only toggle, Swipe delete)
@Composable
fun NativeTeamScreen(
    dao: AppDao,
    settings: SettingsEntity,
    onOpenStatement: (String) -> Unit
) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val context = LocalContext.current
    val workers by dao.getAllWorkers().collectAsState(initial = emptyList())
    val attendance by dao.getAllAttendance().collectAsState(initial = emptyList())
    val payments by dao.getAllWorkerPayments().collectAsState(initial = emptyList())
    val overtime by dao.getAllOvertime().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val currentMonthPrefix = todayStr.substring(0, 7) // YYYY-MM

    // Dialog States
    var showAddWorkerDialog by remember { mutableStateOf(false) }
    var newWorkerName by remember { mutableStateOf("") }
    var newWorkerRole by remember { mutableStateOf("মিস্ত্রি") } // মিস্ত্রি / হেলপার
    var newWorkerWage by remember { mutableStateOf("৮০০") }

    // Payment Dialog State
    var paymentWorker by remember { mutableStateOf<WorkerEntity?>(null) }
    var paymentAmount by remember { mutableStateOf("") }
    var paymentNote by remember { mutableStateOf("অগ্রিম") }
    var paymentDate by remember { mutableStateOf(todayStr) }

    // Worker search + regular-first sorting
    var searchText by remember { mutableStateOf("") }

    // Manual OT Dialog State (Rule 6: Manual OT amount box ONLY)
    var otWorker by remember { mutableStateOf<WorkerEntity?>(null) }
    var otAmount by remember { mutableStateOf("") }
    var otDate by remember { mutableStateOf(todayStr) }

    // Add Worker Dialog
    if (showAddWorkerDialog) {
        AlertDialog(
            onDismissRequest = { showAddWorkerDialog = false },
            title = { Text("+ নতুন কর্মী যোগ করুন", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("কর্মীর নাম", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = newWorkerName,
                        onValueChange = { newWorkerName = it },
                        placeholder = { Text("যেমন: আলমগীর") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("ধরন (Role)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("মিস্ত্রি", "হেলপার").forEach { role ->
                            OutlinedButton(
                                onClick = { newWorkerRole = role },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (newWorkerRole == role) themeStart else Color.Transparent,
                                    contentColor = if (newWorkerRole == role) Color.White else InkText
                                )
                            ) {
                                Text(role, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("দৈনিক হাজিরা (টাকা)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = newWorkerWage,
                        onValueChange = { newWorkerWage = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val wage = newWorkerWage.toDoubleOrNull() ?: 500.0
                        if (newWorkerName.isNotBlank()) {
                            coroutineScope.launch {
                                dao.insertWorker(
                                    WorkerEntity(
                                        id = UUID.randomUUID().toString(),
                                        name = newWorkerName.trim(),
                                        role = newWorkerRole,
                                        dailyWage = wage
                                    )
                                )
                                showAddWorkerDialog = false
                                newWorkerName = ""
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("যোগ করুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddWorkerDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    // Payment Dialog (৳ টাকা দিন)
    if (paymentWorker != null) {
        val worker = paymentWorker!!
        AlertDialog(
            onDismissRequest = { paymentWorker = null },
            title = { Text("${worker.name} — টাকা পরিশোধ", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("তারিখ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = paymentDate,
                        onValueChange = { paymentDate = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("টাকা (৳)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = paymentAmount,
                        onValueChange = { paymentAmount = it },
                        placeholder = { Text("১০০০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("বিবরণ / ধরন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("অগ্রিম", "সাপ্তাহিক", "ধার").forEach { chip ->
                            FilterChip(
                                selected = paymentNote == chip,
                                onClick = { paymentNote = chip },
                                label = { Text(chip, fontSize = 11.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = paymentNote,
                        onValueChange = { paymentNote = it },
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = paymentAmount.toDoubleOrNull()
                        if (amt != null && amt > 0) {
                            coroutineScope.launch {
                                dao.insertWorkerPayment(
                                    WorkerPaymentEntity(
                                        id = UUID.randomUUID().toString(),
                                        workerId = worker.id,
                                        date = paymentDate,
                                        amount = amt,
                                        note = paymentNote
                                    )
                                )
                                val savedWorkerId = worker.id
                                paymentWorker = null
                                paymentAmount = ""
                                // Auto-open that month's statement (Rule 2)
                                onOpenStatement(savedWorkerId)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("সংরক্ষণ", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { paymentWorker = null }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    // Manual OT Dialog (Rule 6: Manual OT amount box ONLY, NO hours, NO rate)
    if (otWorker != null) {
        val worker = otWorker!!
        AlertDialog(
            onDismissRequest = { otWorker = null },
            title = { Text("${worker.name} — ওভারটাইম (OT)", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("তারিখ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = otDate,
                        onValueChange = { otDate = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("ওভারটাইমের টাকা (ম্যানুয়াল পরিমাণ)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = otAmount,
                        onValueChange = { otAmount = it },
                        placeholder = { Text("যেমন: ২০০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = otAmount.toDoubleOrNull() ?: 0.0
                        coroutineScope.launch {
                            if (amt > 0) {
                                dao.insertOvertime(
                                    OvertimeEntity(
                                        id = UUID.randomUUID().toString(),
                                        workerId = worker.id,
                                        date = otDate,
                                        amount = amt
                                    )
                                )
                            } else {
                                dao.deleteOvertime(worker.id, otDate)
                            }
                            otWorker = null
                            otAmount = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("সংরক্ষণ", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { otWorker = null }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    // Sorting rule: regular workers on top.
    // 1) this month worked days (most first), 2) total worked days (most first),
    // 3) last worked date (most recent first). Workers with no attendance
    // (no hisab opened / never worked) fall to the bottom automatically.
    // Search filters by name, then the same sort applies.
    val sortedWorkers = workers
        .filter { searchText.isBlank() || it.name.contains(searchText.trim(), ignoreCase = true) }
        .sortedWith(
            compareByDescending<WorkerEntity> { w -> attendance.count { it.workerId == w.id && it.date.startsWith(currentMonthPrefix) } }
                .thenByDescending { w -> attendance.count { it.workerId == w.id } }
                .thenByDescending { w -> attendance.filter { it.workerId == w.id }.maxOfOrNull { it.date } ?: "" }
                .thenBy { it.name }
        )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("টিম ও হাজিরা", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
        Text(
            "উপস্থিত: ${attendance.count { it.date == todayStr }} / ${workers.size} জন • ${formatBengaliDate(todayStr)}",
            fontSize = 13.sp,
            color = MutedText
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Worker search
        OutlinedTextField(
            value = searchText,
            onValueChange = { searchText = it },
            placeholder = { Text("কর্মী খুঁজুন — নাম লিখুন", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MutedText) },
            trailingIcon = {
                if (searchText.isNotEmpty()) {
                    IconButton(onClick = { searchText = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "মুছুন", tint = MutedText)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SurfaceColor,
                unfocusedContainerColor = SurfaceColor
            )
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (sortedWorkers.isEmpty() && searchText.isNotBlank()) {
            Text("কোনো কর্মী পাওয়া যায়নি — অন্য নাম লিখে দেখুন", fontSize = 13.sp, color = MutedText, modifier = Modifier.padding(vertical = 12.dp))
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(sortedWorkers, key = { it.id }) { worker ->
                val isPresent = attendance.any { it.workerId == worker.id && it.date == todayStr }
                val monthDays = attendance.count { it.workerId == worker.id && it.date.startsWith(currentMonthPrefix) }
                val monthPayments = payments.filter { it.workerId == worker.id && it.date.startsWith(currentMonthPrefix) }.sumOf { it.amount }
                val monthOt = overtime.filter { it.workerId == worker.id && it.date.startsWith(currentMonthPrefix) }.sumOf { it.amount }
                val earned = (monthDays * worker.dailyWage) + monthOt
                val due = earned - monthPayments

                SwipeToDeleteContainer(
                    onDelete = {
                        coroutineScope.launch { dao.deleteWorkerAndRelations(worker.id) }
                    },
                    confirmTitle = "কর্মী মুছে ফেলতে চান?",
                    confirmMessage = "${worker.name} এবং তার সব হাজিরা ও পেমেন্ট রেকর্ড মুছে যাবে।"
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header: Avatar, Name, Role, Wage, Due
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(themeStart, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = worker.name.take(1),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(worker.name, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = InkText)
                                        Text("${worker.role} • হাজিরা ৳ ${worker.dailyWage.toInt()}", fontSize = 12.sp, color = MutedText)
                                    }
                                }

                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Summary Chips: এই মাসে X দিন, নিয়েছে ৳ Y, OT: ৳ Z
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFAF5F0)) {
                                    Text("এই মাসে $monthDays দিন", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = InkText)
                                }
                                Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFAF5F0)) {
                                    Text("নিয়েছে ${formatTk(monthPayments, settings.hideMoney)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = InkText)
                                }
                                Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFAF5F0)) {
                                    Text("OT: ৳ ${monthOt.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = InkText)
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Buttons Row 1: উপস্থিত (Tap-only toggle, NO অনুপস্থিত button), ৳ টাকা দিন, + OT
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Rule 5: Attendance tap-only toggle
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            if (isPresent) {
                                                dao.deleteAttendance(worker.id, todayStr)
                                            } else {
                                                dao.insertAttendance(AttendanceEntity(UUID.randomUUID().toString(), worker.id, todayStr))
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isPresent) themeStart else Color(0xFFE6F8F0),
                                        contentColor = if (isPresent) Color.White else themeStart
                                    )
                                ) {
                                    Text("উপস্থিত", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        paymentWorker = worker
                                        paymentDate = todayStr
                                        paymentAmount = ""
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = InkText)
                                ) {
                                    Text("৳ টাকা দিন", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        otWorker = worker
                                        otDate = todayStr
                                        otAmount = ""
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White,
                                        contentColor = InkText
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                                ) {
                                    Text("+ OT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Buttons Row 2: মাসিক হিসাব দেখুন & PDF শেয়ার
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onOpenStatement(worker.id) },
                                    modifier = Modifier.weight(1.2f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                                ) {
                                    Text("মাসিক হিসাব দেখুন", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        val cal = Calendar.getInstance()
                                        val curYear = cal.get(Calendar.YEAR)
                                        val curMonth = cal.get(Calendar.MONTH) + 1
                                        val workerAtt = attendance.filter { it.workerId == worker.id && it.date.startsWith(currentMonthPrefix) }
                                        val workerOt = overtime.filter { it.workerId == worker.id && it.date.startsWith(currentMonthPrefix) }
                                        val workerPay = payments.filter { it.workerId == worker.id && it.date.startsWith(currentMonthPrefix) }
                                        val pdf = NativePdfGenerator.generateWorkerPdf(
                                            context, worker, curYear, curMonth, workerAtt, workerOt, workerPay
                                        )
                                        NativePdfGenerator.sharePdf(context, pdf, "${worker.name} — হাজিরা ও জমার বিবরণী")
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = InkText)
                                ) {
                                    Text("PDF শেয়ার", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // + নতুন কর্মী যোগ করুন Button
        OutlinedButton(
            onClick = { showAddWorkerDialog = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = SurfaceColor)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = themeStart)
            Spacer(modifier = Modifier.width(6.dp))
            Text("+ নতুন কর্মী যোগ করুন", fontWeight = FontWeight.Bold, color = InkText)
        }
    }
}

// 4. Native Worker Statement Screen (Bug 3, 5, 10, 13 Fixed: Full Calendar, Day list, OT sheet, Payments list with swipe-delete, PDF share)
@Composable
fun NativeWorkerStatementScreen(
    workerId: String,
    initialDate: String?,
    dao: AppDao,
    settings: SettingsEntity,
    onBack: () -> Unit
) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val workers by dao.getAllWorkers().collectAsState(initial = emptyList())
    val worker = workers.find { it.id == workerId }

    val allAttendance by dao.getAllAttendance().collectAsState(initial = emptyList())
    val allPayments by dao.getAllWorkerPayments().collectAsState(initial = emptyList())
    val allOvertime by dao.getAllOvertime().collectAsState(initial = emptyList())

    // Month Navigation State
    val initialCal = Calendar.getInstance()
    if (initialDate != null && initialDate.length >= 7) {
        try {
            val parts = initialDate.split("-")
            initialCal.set(Calendar.YEAR, parts[0].toInt())
            initialCal.set(Calendar.MONTH, parts[1].toInt() - 1)
        } catch (_: Exception) {}
    }
    var currentYear by remember { mutableStateOf(initialCal.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableStateOf(initialCal.get(Calendar.MONTH) + 1) } // 1-12

    val monthPrefix = String.format("%04d-%02d", currentYear, currentMonth)

    // Filtered data for this worker & month
    val attendanceThisMonth = allAttendance.filter { it.workerId == workerId && it.date.startsWith(monthPrefix) }
    val paymentsThisMonth = allPayments.filter { it.workerId == workerId && it.date.startsWith(monthPrefix) }
    val overtimeThisMonth = allOvertime.filter { it.workerId == workerId && it.date.startsWith(monthPrefix) }

    // Manual OT Dialog on Double Tap / Tap
    var otTargetDate by remember { mutableStateOf<String?>(null) }
    var otTargetAmount by remember { mutableStateOf("") }

    if (otTargetDate != null) {
        val targetDate = otTargetDate!!
        AlertDialog(
            onDismissRequest = { otTargetDate = null },
            title = { Text("ওভারটাইম (OT) — ${formatBengaliDate(targetDate)}", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("ম্যানুয়াল ওভারটাইম টাকা (NO hours, NO rate)", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = otTargetAmount,
                        onValueChange = { otTargetAmount = it },
                        placeholder = { Text("যেমন: ২৫০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = otTargetAmount.toDoubleOrNull() ?: 0.0
                        coroutineScope.launch {
                            if (amt > 0) {
                                dao.insertOvertime(
                                    OvertimeEntity(UUID.randomUUID().toString(), workerId, targetDate, amt)
                                )
                            } else {
                                dao.deleteOvertime(workerId, targetDate)
                            }
                            otTargetDate = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("সংরক্ষণ", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { otTargetDate = null }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    if (worker == null) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Button(onClick = onBack) { Text("← টিমে ফিরুন") }
            Spacer(modifier = Modifier.height(20.dp))
            Text("কর্মী খুঁজে পাওয়া যায়নি")
        }
        return
    }

    // Calculations
    val workedDays = attendanceThisMonth.size
    val haziraTotal = workedDays * worker.dailyWage
    val otTotal = overtimeThisMonth.sumOf { it.amount }
    val totalEarned = haziraTotal + otTotal
    val totalTaken = paymentsThisMonth.sumOf { it.amount }
    val dueAmount = totalEarned - totalTaken

    // Month name
    val monthNames = arrayOf("", "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
    val monthLabel = "${monthNames[currentMonth]} ${toBengaliNum(currentYear)}"

    // Calculate calendar days
    val cal = Calendar.getInstance()
    cal.set(Calendar.YEAR, currentYear)
    cal.set(Calendar.MONTH, currentMonth - 1)
    cal.set(Calendar.DAY_OF_MONTH, 1)
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sun, 7 = Sat
    val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Back Button & Title
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("← টিমে ফিরুন", fontWeight = FontWeight.Bold, color = InkText)
                }

                Button(
                    onClick = {
                        val pdf = NativePdfGenerator.generateWorkerPdf(
                            context, worker, currentYear, currentMonth, attendanceThisMonth, overtimeThisMonth, paymentsThisMonth
                        )
                        NativePdfGenerator.sharePdf(context, pdf, "${worker.name} — Statement ($monthLabel)")
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = InkText)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PDF শেয়ার", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(worker.name, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
            Text("${worker.role} • দৈনিক হাজিরা ৳ ${worker.dailyWage.toInt()}", fontSize = 13.sp, color = MutedText)
        }

        // Month Selector (< নভেম্বর ২০২৬ >)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        if (currentMonth == 1) {
                            currentMonth = 12
                            currentYear--
                        } else {
                            currentMonth--
                        }
                    }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                    }

                    Text(monthLabel, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = InkText)

                    IconButton(onClick = {
                        if (currentMonth == 12) {
                            currentMonth = 1
                            currentYear++
                        } else {
                            currentMonth++
                        }
                    }) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                    }
                }
            }
        }

        // Rule 5: Monthly Worked-Day Calendar (Present = Dark box only, NO check-mark emoji, Single tap toggle, Double tap OT)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("হাজিরা ক্যালেন্ডার", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = InkText)
                    Text("এক ট্যাপে হাজিরা, ডাবল ট্যাপে OT পরিমাণ দিন। উপস্থিত দিনগুলো গাঢ় হবে।", fontSize = 11.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Weekday headers
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র", "শনি").forEach { w ->
                            Text(w, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MutedText)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Calendar Grid (7 columns)
                    val totalSlots = ((firstDayOfWeek - 1) + maxDays + 6) / 7 * 7
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (week in 0 until (totalSlots / 7)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (dayOfWeek in 1..7) {
                                    val slotIndex = week * 7 + (dayOfWeek - 1)
                                    val dayNum = slotIndex - (firstDayOfWeek - 2)
                                    if (dayNum in 1..maxDays) {
                                        val dayDateStr = String.format("%04d-%02d-%02d", currentYear, currentMonth, dayNum)
                                        val isPresent = attendanceThisMonth.any { it.date == dayDateStr }
                                        val otForDay = overtimeThisMonth.find { it.date == dayDateStr }

                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .clip(RoundedCornerShape(8.dp))
                                                // Rule 5: Present days shown ONLY by darkening that date's box
                                                .background(if (isPresent) InkText else Color(0xFFFAF5F0))
                                                .pointerInput(dayDateStr) {
                                                    detectTapGestures(
                                                        onTap = {
                                                            coroutineScope.launch {
                                                                if (isPresent) {
                                                                    dao.deleteAttendance(workerId, dayDateStr)
                                                                } else {
                                                                    dao.insertAttendance(AttendanceEntity(UUID.randomUUID().toString(), workerId, dayDateStr))
                                                                }
                                                            }
                                                        },
                                                        onDoubleTap = {
                                                            otTargetDate = dayDateStr
                                                            otTargetAmount = if (otForDay != null && otForDay.amount > 0) otForDay.amount.toInt().toString() else ""
                                                        }
                                                    )
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                // NO check-mark emoji anywhere on calendar (Rule 5)
                                                Text(
                                                    text = toBengaliNum(dayNum),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isPresent) Color.White else InkText
                                                )
                                                if (otForDay != null && otForDay.amount > 0) {
                                                    Text(
                                                        text = "OT",
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = if (isPresent) Color(0xFFFFC9A8) else ExpenseRed
                                                    )
                                                }
                                            }
                                        }
                                    } else {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Summary Tiles: Worked days, Hazira, OT line, Total earned, Taken, Due
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = InkText)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("হিসাব সারাংশ ($monthLabel)", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("কাজ করেছে", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("$workedDays দিন", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("হাজিরা বাবদ", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${haziraTotal.toInt()}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("ওভারটাইম (OT)", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${otTotal.toInt()}", color = Color(0xFFFFC9A8), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = Color.White.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("মোট পাওনা", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${totalEarned.toInt()}", color = Color(0xFF7DFFC4), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Column {
                            Text("নিয়েছে", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${totalTaken.toInt()}", color = Color(0xFFFFC9A8), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Column {
                            Text("বাকি (Due)", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${dueAmount.toInt()}", color = if (dueAmount > 0) Color(0xFFFF8B8B) else Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }

        // Section: Payments Taken (with swipe-to-delete)
        item {
            Text("টাকা নেওয়ার তালিকা (${paymentsThisMonth.size}টি)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkText)
        }

        if (paymentsThisMonth.isEmpty()) {
            item {
                Text("এই মাসে কোনো টাকা নেয়নি।", fontSize = 12.sp, color = MutedText)
            }
        } else {
            items(paymentsThisMonth, key = { it.id }) { p ->
                SwipeToDeleteContainer(
                    onDelete = {
                        coroutineScope.launch { dao.deleteWorkerPaymentById(p.id) }
                    },
                    confirmTitle = "পেমেন্ট মুছে ফেলবেন?",
                    confirmMessage = "তারিখ ${formatBengaliDate(p.date)} এর ৳ ${p.amount.toInt()} মুছে যাবে।"
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(p.note, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = InkText)
                                Text("${formatBengaliDate(p.date)} • ${getBengaliWeekday(p.date)}", fontSize = 11.sp, color = MutedText)
                            }
                            Text("- ৳ ${p.amount.toInt()}", fontWeight = FontWeight.Bold, color = ExpenseRed, fontSize = 15.sp)
                        }
                    }
                }
            }
        }

        // Section: Worked Days List
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text("কাজের দিনের তালিকা (${attendanceThisMonth.size} দিন)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkText)
        }

        if (attendanceThisMonth.isEmpty()) {
            item {
                Text("এই মাসে এখনও কোনো উপস্থিতি মার্ক করা হয়নি।", fontSize = 12.sp, color = MutedText)
            }
        } else {
            items(attendanceThisMonth.sortedBy { it.date }, key = { it.id }) { a ->
                val otForDay = overtimeThisMonth.find { it.date == a.date }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(formatBengaliDate(a.date), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = InkText)
                            Text(getBengaliWeekday(a.date), fontSize = 11.sp, color = MutedText)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("হাজিরা: ৳ ${worker.dailyWage.toInt()}", fontWeight = FontWeight.Bold, color = IncomeGreen, fontSize = 13.sp)
                            if (otForDay != null && otForDay.amount > 0) {
                                Text("OT: ৳ ${otForDay.amount.toInt()}", fontSize = 11.sp, color = themeStart, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. Native Sites Screen (Bug 5 & 10: Add Site Form with duplicate rejection, Received & Due cards, PDF Share)
@Composable
fun NativeSitesScreen(
    dao: AppDao,
    settings: SettingsEntity,
    onOpenSiteDetail: (String) -> Unit
) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val context = LocalContext.current
    val sites by dao.getAllSites().collectAsState(initial = emptyList())
    val payments by dao.getAllSitePayments().collectAsState(initial = emptyList())
    val expenses by dao.getAllSiteExpenses().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    var showAddDialog by remember { mutableStateOf(false) }
    var siteName by remember { mutableStateOf("") }
    var siteType by remember { mutableStateOf("ইলেকট্রিক + প্লাম্বিং") }
    var totalBillText by remember { mutableStateOf("") }
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    var startDateText by remember { mutableStateOf(todayStr) }
    var firstReceivedText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("+ নতুন সাইট হিসাব খুলুন", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Text("সাইটের নাম", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = siteName,
                        onValueChange = { siteName = it },
                        placeholder = { Text("যেমন: Aloua 2 tala") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("কাজের ধরন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("ইলেকট্রিক", "প্লাম্বিং", "ইলেকট্রিক + প্লাম্বিং").forEach { t ->
                            FilterChip(
                                selected = siteType == t,
                                onClick = { siteType = t },
                                label = { Text(t, fontSize = 10.sp) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("মোট চুক্তি / বিল (টাকা)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = totalBillText,
                        onValueChange = { totalBillText = it },
                        placeholder = { Text("যেমন: ২৫০০০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("কাজ শুরুর তারিখ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = startDateText,
                        onValueChange = { startDateText = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("প্রথম প্রাপ্ত টাকা (যদি থাকে)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = firstReceivedText,
                        onValueChange = { firstReceivedText = it },
                        placeholder = { Text("যেমন: ৫০০০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    if (errorMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(errorMessage, color = ExpenseRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmedName = siteName.trim()
                        if (trimmedName.isBlank()) {
                            errorMessage = "সাইটের নাম লিখুন"
                            return@Button
                        }
                        // Duplicate check
                        if (sites.any { it.name.equals(trimmedName, ignoreCase = true) }) {
                            errorMessage = "এই নামের সাইট ইতিমধ্যে আছে!"
                            return@Button
                        }
                        val bill = totalBillText.toDoubleOrNull() ?: 0.0
                        val initialRec = firstReceivedText.toDoubleOrNull() ?: 0.0
                        val newSiteId = UUID.randomUUID().toString()

                        coroutineScope.launch {
                            dao.insertSite(
                                SiteEntity(
                                    id = newSiteId,
                                    name = trimmedName,
                                    type = siteType,
                                    totalBill = bill,
                                    startDate = startDateText.trim()
                                )
                            )
                            if (initialRec > 0) {
                                dao.insertSitePayment(
                                    SitePaymentEntity(
                                        id = UUID.randomUUID().toString(),
                                        siteId = newSiteId,
                                        date = startDateText.trim(),
                                        amount = initialRec,
                                        details = "অগ্রিম বায়না / ১ম কিস্তি"
                                    )
                                )
                            }
                            showAddDialog = false
                            siteName = ""
                            totalBillText = ""
                            firstReceivedText = ""
                            errorMessage = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("খুলুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Eye button at the top: hides/shows site money (same hideMoney as Overview/Daily)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Site accounts / সাইট হিসাব", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
            IconButton(onClick = {
                coroutineScope.launch {
                    dao.updateSettings(settings.copy(hideMoney = !settings.hideMoney))
                }
            }) {
                Icon(
                    imageVector = if (settings.hideMoney) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = "টাকা লুকান / দেখান",
                    tint = InkText,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Text("Money received and due stay separate for each site.", fontSize = 12.sp, color = MutedText)
        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                startDateText = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                showAddDialog = true
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = themeStart)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("+ নতুন সাইট হিসাব খুলুন", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (sites.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("কোনো সাইট নেই। নতুন সাইট হিসাব খুলুন।", color = MutedText, fontSize = 13.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(sites, key = { it.id }) { site ->
                    val sitePayments = payments.filter { it.siteId == site.id }
                    val receivedTotal = sitePayments.sumOf { it.amount }
                    val dueTotal = site.totalBill - receivedTotal

                    SwipeToDeleteContainer(
                        onDelete = {
                            coroutineScope.launch { dao.deleteSiteAndRelations(site.id) }
                        },
                        confirmTitle = "সাইট মুছে ফেলবেন?",
                        confirmMessage = "${site.name} এর সব জমা ও খরচের হিসাব মুছে যাবে।"
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(site.name, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = InkText)
                                Text("${site.type} • কাজ শুরু: ${formatBengaliDate(site.startDate)}", fontSize = 12.sp, color = MutedText)

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("পেয়েছি", fontSize = 11.sp, color = MutedText)
                                        Text(formatTk(receivedTotal, settings.hideMoney), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = IncomeGreen)
                                    }
                                    Column {
                                        Text("মোট চুক্তি", fontSize = 11.sp, color = MutedText)
                                        Text(formatTk(site.totalBill, settings.hideMoney), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = InkText)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("বাকি", fontSize = 11.sp, color = MutedText)
                                        Text(formatTk(dueTotal, settings.hideMoney), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = ExpenseRed)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { onOpenSiteDetail(site.id) },
                                        modifier = Modifier.weight(1.2f),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                                    ) {
                                        Text("হিসাব দেখুন", fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = {
                                            val pdf = NativePdfGenerator.generateSitePdf(context, site, sitePayments)
                                            NativePdfGenerator.sharePdf(context, pdf, "${site.name} — জমার রশিদ")
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = InkText)
                                    ) {
                                        Text("PDF শেয়ার", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 6. Native Site Detail Screen (Bug 4, 10, 13: Received, Expense categories, Net, Forms, PDF Share)
@Composable
fun NativeSiteDetailScreen(siteId: String, dao: AppDao, settings: SettingsEntity, onBack: () -> Unit) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val sites by dao.getAllSites().collectAsState(initial = emptyList())
    val site = sites.find { it.id == siteId }

    val allPayments by dao.getAllSitePayments().collectAsState(initial = emptyList())
    val allExpenses by dao.getAllSiteExpenses().collectAsState(initial = emptyList())

    val sitePayments = allPayments.filter { it.siteId == siteId }
    val siteExpenses = allExpenses.filter { it.siteId == siteId }

    val totalReceived = sitePayments.sumOf { it.amount }
    val totalExpense = siteExpenses.sumOf { it.amount }
    val netAmount = totalReceived - totalExpense

    // Dialog states
    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var payAmountText by remember { mutableStateOf("") }
    var payDetailsText by remember { mutableStateOf("") }
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    var payDateText by remember { mutableStateOf(todayStr) }

    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var expCategory by remember { mutableStateOf("কর্মী খরচ") } // কর্মী খরচ / অন্যান্য খরচ
    var expWorkerCountText by remember { mutableStateOf("") }
    var expDetailsText by remember { mutableStateOf("") }
    var expAmountText by remember { mutableStateOf("") }
    var expDateText by remember { mutableStateOf(todayStr) }

    // Dialog: পাওয়া টাকা যোগ করুন
    if (showAddPaymentDialog) {
        AlertDialog(
            onDismissRequest = { showAddPaymentDialog = false },
            title = { Text("পাওয়া টাকা যোগ করুন", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("তারিখ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = payDateText,
                        onValueChange = { payDateText = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("বিবরণ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = payDetailsText,
                        onValueChange = { payDetailsText = it },
                        placeholder = { Text("যেমন: ২য় কিস্তি চেক / নগদ") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("টাকা (৳)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = payAmountText,
                        onValueChange = { payAmountText = it },
                        placeholder = { Text("৫০০০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = payAmountText.toDoubleOrNull()
                        if (amt != null && amt > 0) {
                            coroutineScope.launch {
                                dao.insertSitePayment(
                                    SitePaymentEntity(
                                        id = UUID.randomUUID().toString(),
                                        siteId = siteId,
                                        date = payDateText.trim(),
                                        amount = amt,
                                        details = payDetailsText.ifBlank { "প্রাপ্ত টাকা" }
                                    )
                                )
                                showAddPaymentDialog = false
                                payAmountText = ""
                                payDetailsText = ""
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("যোগ করুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddPaymentDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    // Dialog: খরচ যোগ করুন (কর্মী খরচ / অন্যান্য খরচ)
    if (showAddExpenseDialog) {
        AlertDialog(
            onDismissRequest = { showAddExpenseDialog = false },
            title = { Text("সাইটের খরচ যোগ করুন", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Text("তারিখ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = expDateText,
                        onValueChange = { expDateText = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("খরচের ধরন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("কর্মী খরচ", "অন্যান্য খরচ").forEach { cat ->
                            FilterChip(
                                selected = expCategory == cat,
                                onClick = { expCategory = cat },
                                label = { Text(cat) }
                            )
                        }
                    }

                    if (expCategory == "কর্মী খরচ") {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("কতজন কর্মী কাজ করেছে", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                        OutlinedTextField(
                            value = expWorkerCountText,
                            onValueChange = { expWorkerCountText = it },
                            placeholder = { Text("যেমন: ২") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("বিবরণ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = expDetailsText,
                        onValueChange = { expDetailsText = it },
                        placeholder = { Text("যেমন: মিস্ত্রি হাজিরা / গাড়ি ভাড়া") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("টাকা (৳)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = expAmountText,
                        onValueChange = { expAmountText = it },
                        placeholder = { Text("৮০০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = expAmountText.toDoubleOrNull()
                        if (amt != null && amt > 0) {
                            coroutineScope.launch {
                                dao.insertSiteExpense(
                                    SiteExpenseEntity(
                                        id = UUID.randomUUID().toString(),
                                        siteId = siteId,
                                        date = expDateText.trim(),
                                        category = expCategory,
                                        workerCount = expWorkerCountText.toIntOrNull(),
                                        details = expDetailsText.ifBlank { expCategory },
                                        amount = amt
                                    )
                                )
                                showAddExpenseDialog = false
                                expAmountText = ""
                                expDetailsText = ""
                                expWorkerCountText = ""
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("যোগ করুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddExpenseDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    if (site == null) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Button(onClick = onBack) { Text("← সাইটে ফিরুন") }
            Spacer(modifier = Modifier.height(20.dp))
            Text("সাইট খুঁজে পাওয়া যায়নি")
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = onBack, shape = RoundedCornerShape(12.dp)) {
                    Text("← সাইটে ফিরুন", fontWeight = FontWeight.Bold, color = InkText)
                }

                // Rule 12: Site PDF in Bengali ONLY, received-only list + total.
                Button(
                    onClick = {
                        val pdf = NativePdfGenerator.generateSitePdf(context, site, sitePayments)
                        NativePdfGenerator.sharePdf(context, pdf, "${site.name} — জমার রশিদ (PDF)")
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = InkText)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PDF শেয়ার", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(site.name, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
            Text("${site.type} • কাজ শুরু: ${formatBengaliDate(site.startDate)}", fontSize = 12.sp, color = MutedText)
        }

        // Summary Card: Received, Expense, Net (per-site only)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = InkText)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("সাইটের হিসাব সারাংশ", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("মোট পাওয়া", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${totalReceived.toInt()}", color = Color(0xFF7DFFC4), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Column {
                            Text("সাইট খরচ", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${totalExpense.toInt()}", color = Color(0xFFFFC9A8), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("নীট স্থিতি", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                            Text("৳ ${netAmount.toInt()}", color = if (netAmount >= 0) Color.White else Color(0xFFFF8B8B), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }

        // Action Buttons: পাওয়া টাকা যোগ করুন & খরচ যোগ করুন
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        payDateText = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        showAddPaymentDialog = true
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                ) {
                    Text("+ পাওয়া টাকা যোগ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        expDateText = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        showAddExpenseDialog = true
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("+ খরচ যোগ করুন", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Section: Received Payments List (with Swipe-to-delete)
        item {
            Text("পাওয়া টাকার তালিকা (${sitePayments.size}টি)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkText)
        }

        if (sitePayments.isEmpty()) {
            item {
                Text("এখনও কোনো টাকা জমা হয়নি।", fontSize = 12.sp, color = MutedText)
            }
        } else {
            items(sitePayments, key = { it.id }) { p ->
                SwipeToDeleteContainer(
                    onDelete = { coroutineScope.launch { dao.deleteSitePaymentById(p.id) } },
                    confirmTitle = "জমা টাকা মুছে ফেলবেন?",
                    confirmMessage = "তারিখ ${formatBengaliDate(p.date)} এর ৳ ${p.amount.toInt()} মুছে যাবে।"
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(p.details, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = InkText)
                                Text("${formatBengaliDate(p.date)} • ${getBengaliWeekday(p.date)}", fontSize = 11.sp, color = MutedText)
                            }
                            Text("+ ৳ ${p.amount.toInt()}", fontWeight = FontWeight.Bold, color = IncomeGreen, fontSize = 15.sp)
                        }
                    }
                }
            }
        }

        // Section: Site Expenses List (Rule 12: In app only, NEVER in PDF)
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("সাইটের খরচের তালিকা (${siteExpenses.size}টি)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkText)
            Text("এই খরচ শুধু এই সাইটের হিসাবের জন্য — PDF-এ যাবে না।", fontSize = 11.sp, color = MutedText)
        }

        if (siteExpenses.isEmpty()) {
            item {
                Text("এই সাইটে এখনও কোনো খরচ যুক্ত হয়নি।", fontSize = 12.sp, color = MutedText)
            }
        } else {
            items(siteExpenses, key = { it.id }) { exp ->
                SwipeToDeleteContainer(
                    onDelete = { coroutineScope.launch { dao.deleteSiteExpenseById(exp.id) } },
                    confirmTitle = "খরচ মুছে ফেলবেন?",
                    confirmMessage = "${exp.details} বাবদ ৳ ${exp.amount.toInt()} মুছে যাবে।"
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(exp.details, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = InkText)
                                val countStr = if (exp.workerCount != null && exp.workerCount > 0) " • ${exp.workerCount} জন কর্মী" else ""
                                Text("${exp.category}$countStr • ${formatBengaliDate(exp.date)}", fontSize = 11.sp, color = MutedText)
                            }
                            Text("- ৳ ${exp.amount.toInt()}", fontWeight = FontWeight.Bold, color = ExpenseRed, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}

// 7. Native Monthly Hisab Screen (Bug 6: Month Prev/Next, Income/Expense/Net, Grouped by day, Respects eye-hide)
@Composable
fun NativeMonthlyHisabScreen(dao: AppDao, settings: SettingsEntity, onBack: () -> Unit) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val dailyList by dao.getAllDailyEntries().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    val initialCal = Calendar.getInstance()
    var currentYear by remember { mutableStateOf(initialCal.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableStateOf(initialCal.get(Calendar.MONTH) + 1) }

    val monthPrefix = String.format("%04d-%02d", currentYear, currentMonth)
    val entriesThisMonth = dailyList.filter { it.date.startsWith(monthPrefix) }

    val monthIncome = entriesThisMonth.filter { it.type == "income" }.sumOf { it.amount }
    val monthExpense = entriesThisMonth.filter { it.type == "expense" }.sumOf { it.amount }
    val monthNet = monthIncome - monthExpense

    val monthNames = arrayOf("", "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
    val monthLabel = "${monthNames[currentMonth]} ${toBengaliNum(currentYear)}"

    // Group entries by date
    val groupedByDate = entriesThisMonth.groupBy { it.date }.toSortedMap(reverseOrder())

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack, shape = RoundedCornerShape(12.dp)) {
                Text("← ওভারভিউতে ফিরুন", fontWeight = FontWeight.Bold, color = InkText)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text("মাসিক হিসাব বিবরণী", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
        Spacer(modifier = Modifier.height(10.dp))

        // Month Selector (< নভেম্বর ২০২৬ >)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceColor)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    if (currentMonth == 1) {
                        currentMonth = 12
                        currentYear--
                    } else {
                        currentMonth--
                    }
                }) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                }

                Text(monthLabel, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = InkText)

                IconButton(onClick = {
                    if (currentMonth == 12) {
                        currentMonth = 1
                        currentYear++
                    } else {
                        currentMonth++
                    }
                }) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Monthly Summary Card (Respects eye-hide)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = InkText)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("মাসিক মোট সারাংশ ($monthLabel)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("মোট আয়", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text(formatTk(monthIncome, settings.hideMoney), color = Color(0xFF7DFFC4), fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Column {
                        Text("মোট খরচ", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text(formatTk(monthExpense, settings.hideMoney), color = Color(0xFFFFC9A8), fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("লাভ / স্থিতি", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text(formatTk(monthNet, settings.hideMoney), color = if (monthNet >= 0) Color.White else Color(0xFFFF8B8B), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Day-by-day grouped list
        if (groupedByDate.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("এই মাসে কোনো হিসাব এন্ট্রি নেই।", color = MutedText, fontSize = 13.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                groupedByDate.forEach { (dateStr, entries) ->
                    item {
                        Column {
                            // Date header with Bengali weekday
                            Text(
                                text = "${formatBengaliDate(dateStr)} — ${getBengaliWeekday(dateStr)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = themeStart
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                entries.forEach { entry ->
                                    SwipeToDeleteContainer(
                                        onDelete = { coroutineScope.launch { dao.deleteDailyEntryById(entry.id) } },
                                        confirmTitle = "এন্ট্রি মুছবেন?",
                                        confirmMessage = "${entry.details} মুছে ফেলতে চান?"
                                    ) {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(entry.details, fontWeight = FontWeight.Medium, fontSize = 13.sp, color = InkText)
                                                Text(
                                                    text = (if (entry.type == "income") "+ " else "- ") + formatTk(entry.amount, settings.hideMoney),
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (entry.type == "income") IncomeGreen else ExpenseRed,
                                                    fontSize = 14.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 8. Native Photo Editor Screen (Bug 7: Full view photo, Tools BELOW, Draw, Straight line ONLY, Clean text, Point, Erase, Color, Undo/Redo, PNG save)
@Composable
fun NativePhotoEditorScreen(noteId: String, dao: AppDao, settings: SettingsEntity, onBack: () -> Unit) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    BackHandler { onBack() }
    val notes by dao.getAllNotes().collectAsState(initial = emptyList())
    val note = notes.find { it.id == noteId }

    // Load the original note photo (file path OR content:// URI from the picker).
    // Previously the editor never loaded note.photoPath at all, so it always
    // opened on a blank dark canvas - that was the reported bug.
    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var photoLoadFailed by remember { mutableStateOf(false) }
    // Display size (px) of the photo box, and which text is being dragged.
    var displaySize by remember { mutableStateOf(IntSize.Zero) }
    var movingTextIndex by remember { mutableStateOf(-1) }
    // Pinch zoom (no button/option): two-finger pinch zooms the photo, one-finger
    // drag still draws. Zoom is for viewing only; saved drawing uses display
    // coordinates, so zoom does not change the saved photo.
    var zoomScale by remember { mutableStateOf(1f) }
    var zoomOffset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        val newScale = (zoomScale * zoomChange).coerceIn(1f, 4f)
        // Only pan when zoomed in; at 1x pan does nothing so one-finger drawing
        // is not disturbed. Only update scale when it actually changes (pinch).
        if (zoomChange != 1f || newScale > 1f) {
            zoomScale = newScale
            if (newScale > 1f) {
                val maxX = displaySize.width * (newScale - 1f) / 2f
                val maxY = displaySize.height * (newScale - 1f) / 2f
                zoomOffset = Offset(
                    (zoomOffset.x + panChange.x).coerceIn(-maxX, maxX),
                    (zoomOffset.y + panChange.y).coerceIn(-maxY, maxY)
                )
            } else zoomOffset = Offset.Zero
        }
    }
    LaunchedEffect(note?.photoPath) {
        val path = note?.photoPath
        if (path.isNullOrBlank()) {
            originalBitmap = null
            photoLoadFailed = false
        } else {
            originalBitmap = withContext(Dispatchers.IO) {
                try {
                    if (path.startsWith("content://")) {
                        context.contentResolver.openInputStream(Uri.parse(path))?.use { BitmapFactory.decodeStream(it) }
                    } else {
                        BitmapFactory.decodeFile(path)
                    }
                } catch (e: Exception) {
                    null
                }
            }
            photoLoadFailed = originalBitmap == null
        }
    }

    // Re-attach a photo when the saved one cannot be loaded (e.g. restored from an
    // old backup that only had the path, not the file). This does not lose the note.
    val reattachPicker = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null && note != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val file = File(context.filesDir, "note_photo_${UUID.randomUUID()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { out -> input.copyTo(out) } }
                    dao.insertNote(note.copy(photoPath = file.absolutePath))
                    val bmp = BitmapFactory.decodeFile(file.absolutePath)
                    withContext(Dispatchers.Main) { originalBitmap = bmp; photoLoadFailed = bmp == null }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(context, "ছবি যোগ করা যায়নি", Toast.LENGTH_SHORT).show() }
                }
            }
        }
    }

    // Drawing Tool Mode
    // No tool selected on open (NONE): pinch zoom / pan works when no edit tool
    // is clicked. Tapping a selected tool again deselects it back to NONE.
    // Previously DRAW was selected by default, so pinch zoom drew stray lines.
    var currentTool by remember { mutableStateOf("NONE") } // NONE, DRAW, LINE, TEXT, POINT, ERASE
    var currentColor by remember { mutableStateOf(Color(0xFF0D9488)) }
    var showTextInputDialog by remember { mutableStateOf(false) }
    var textToAdd by remember { mutableStateOf("") }

    // Drawing Elements Model
    data class DrawPath(val points: List<Offset>, val color: Color, val strokeWidth: Float, val isEraser: Boolean = false)
    data class DrawLine(val start: Offset, val end: Offset, val color: Color, val strokeWidth: Float)
    data class DrawPoint(val position: Offset, val color: Color, val radius: Float)
    data class DrawText(val text: String, val position: Offset, val color: Color, val textSize: Float)

    val paths = remember { mutableStateListOf<DrawPath>() }
    val lines = remember { mutableStateListOf<DrawLine>() }
    val points = remember { mutableStateListOf<DrawPoint>() }
    val texts = remember { mutableStateListOf<DrawText>() }

    // Undo / Redo history stacks
    val history = remember { mutableStateListOf<String>() } // keeps track of action type for undo

    var currentDrawingPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var lineStart by remember { mutableStateOf<Offset?>(null) }
    var lineCurrent by remember { mutableStateOf<Offset?>(null) }

    // Text Dialog
    if (showTextInputDialog) {
        AlertDialog(
            onDismissRequest = { showTextInputDialog = false },
            title = { Text("ছবিতে লেখা যোগ করুন", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column {
                    Text("লেখা দিন (প্যানেল বন্ধ হয়ে ছবিতে বসবে)", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = textToAdd,
                        onValueChange = { textToAdd = it },
                        placeholder = { Text("যেমন: ১২ ফুট পাইপ") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textToAdd.isNotBlank()) {
                            // Add in center of screen
                            texts.add(DrawText(textToAdd.trim(), if (displaySize.width > 0) Offset(displaySize.width / 2f, displaySize.height / 2f) else Offset(150f, 250f), currentColor, 36f))
                            history.add("TEXT")
                            showTextInputDialog = false
                            textToAdd = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("বসিয়ে দিন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showTextInputDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF1E293B))) {
        // Top Bar: Back, Title, Save, PNG Share
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .zIndex(1f)
                .background(Color(0xFF1E293B))
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }

            Text(
                text = "ফটো এডিটর (নোট পরিমাপ)",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        // Save bitmap back to file
                        coroutineScope.launch(Dispatchers.IO) {
                            try {
                                val file = File(context.filesDir, "note_${noteId}_edited.png")
                                val srcBmp = originalBitmap
                                val bmp = Bitmap.createBitmap(srcBmp?.width ?: 800, srcBmp?.height ?: 1000, Bitmap.Config.ARGB_8888)
                                val canvas = Canvas(bmp)
                                canvas.drawColor(android.graphics.Color.WHITE)
                                // Display box now keeps the photo aspect ratio, so one uniform
                                // scale maps display coords to bitmap coords.
                                val saveScale = if (srcBmp != null && displaySize.width > 0) srcBmp.width.toFloat() / displaySize.width.toFloat() else 1f
                                fun sc(o: Offset) = Offset(o.x * saveScale, o.y * saveScale)

                                val p = AndroidPaint().apply {
                                    isAntiAlias = true
                                }

                                if (srcBmp != null) {
                                    canvas.drawBitmap(srcBmp, null, android.graphics.Rect(0, 0, srcBmp.width, srcBmp.height), p)
                                }
                                paths.forEach { path ->
                                    if (path.points.size > 1) {
                                        p.color = path.color.toArgb()
                                        p.strokeWidth = path.strokeWidth * saveScale
                                        for (i in 0 until path.points.size - 1) {
                                            val a = sc(path.points[i]); val b = sc(path.points[i + 1]); canvas.drawLine(a.x, a.y, b.x, b.y, p)
                                        }
                                    }
                                }
                                points.forEach { pt ->
                                    p.color = pt.color.toArgb()
                                    val c = sc(pt.position); canvas.drawCircle(c.x, c.y, pt.radius * saveScale, p)
                                }

                                lines.forEach { l ->
                                    p.color = l.color.toArgb()
                                    p.strokeWidth = l.strokeWidth * saveScale
                                    val a = sc(l.start); val b = sc(l.end); canvas.drawLine(a.x, a.y, b.x, b.y, p)
                                }

                                texts.forEach { tt ->
                                    p.color = tt.color.toArgb()
                                    p.textSize = tt.textSize * saveScale
                                    val c = sc(tt.position); canvas.drawText(tt.text, c.x, c.y, p)
                                }

                                FileOutputStream(file).use { out ->
                                    bmp.compress(Bitmap.CompressFormat.PNG, 95, out)
                                }

                                // Update note photoPath in Room
                                if (note != null) {
                                    dao.insertNote(note.copy(photoPath = file.absolutePath))
                                }

                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "ছবি সংরক্ষণ করা হয়েছে", Toast.LENGTH_SHORT).show()
                                    onBack()
                                }
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "সংরক্ষণ ব্যর্থ", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                ) {
                    Text("সংরক্ষণ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // FULL VIEW Photo & Drawing Canvas (Never shrinking the photo)
        // Aspect ratio: the box now matches the photo aspect, so FillBounds does
        // NOT stretch/flatten the photo. Previously the box was a fixed phone
        // shape and the photo was stretched into it (800x1000 on save too).
        // Outer container clips the photo, so a large / zoomed photo can never
        // draw over the top bar or the tools. The previous fix put clipToBounds
        // BEFORE graphicsLayer on the same Box, so the scaled layer escaped the
        // clip and still covered the back button. Now the clip is on the outer
        // container and graphicsLayer(clip = true) is on the inner photo Box.
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF0F172A))
                .clipToBounds(),
            contentAlignment = Alignment.Center
        ) {
        Box(
            modifier = Modifier
                .then(if (originalBitmap != null) Modifier.aspectRatio(originalBitmap!!.width.toFloat() / originalBitmap!!.height.toFloat()) else Modifier.fillMaxSize())
                .fillMaxWidth()
                .onSizeChanged { displaySize = it }
                .transformable(state = transformState)
                .graphicsLayer(scaleX = zoomScale, scaleY = zoomScale, translationX = zoomOffset.x, translationY = zoomOffset.y, clip = true)
                .pointerInput(currentTool, currentColor) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            when (currentTool) {
                                "DRAW", "ERASE" -> currentDrawingPoints = listOf(offset)
                                "LINE" -> {
                                    lineStart = offset
                                    lineCurrent = offset
                                }
                                "POINT" -> {
                                    points.add(DrawPoint(offset, currentColor, 8f))
                                    history.add("POINT")
                                }
                                // TEXT: pick the nearest text to drag-move it. Previously
                                // text was fixed at (150,250) and could never be moved.
                                "TEXT" -> {
                                    movingTextIndex = texts.indices.minByOrNull { i ->
                                        val d = texts[i].position - offset; d.x * d.x + d.y * d.y
                                    }?.takeIf { i ->
                                        val d = texts[i].position - offset; d.x * d.x + d.y * d.y < 120f * 120f
                                    } ?: -1
                                }
                            }
                        },
                        onDrag = { change, dragAmount ->
                            if (currentTool == "NONE" && zoomScale > 1f) {
                                // Pan the zoomed photo with one finger in NONE mode.
                                val maxX = displaySize.width * (zoomScale - 1f) / 2f
                                val maxY = displaySize.height * (zoomScale - 1f) / 2f
                                zoomOffset = Offset(
                                    (zoomOffset.x + dragAmount.x).coerceIn(-maxX, maxX),
                                    (zoomOffset.y + dragAmount.y).coerceIn(-maxY, maxY)
                                )
                            }
                            if (currentTool != "NONE") change.consume()
                            when (currentTool) {
                                "DRAW", "ERASE" -> currentDrawingPoints = currentDrawingPoints + change.position
                                "LINE" -> lineCurrent = change.position
                                "TEXT" -> {
                                    if (movingTextIndex >= 0 && movingTextIndex < texts.size) {
                                        texts[movingTextIndex] = texts[movingTextIndex].copy(position = change.position)
                                    }
                                }
                            }
                        },
                        onDragEnd = {
                            movingTextIndex = -1
                            when (currentTool) {
                                "DRAW" -> {
                                    if (currentDrawingPoints.isNotEmpty()) {
                                        paths.add(DrawPath(currentDrawingPoints, currentColor, 6f, false))
                                        history.add("PATH")
                                        currentDrawingPoints = emptyList()
                                    }
                                }
                                "ERASE" -> {
                                    if (currentDrawingPoints.isNotEmpty()) {
                                        paths.add(DrawPath(currentDrawingPoints, Color(0xFF0F172A), 24f, true))
                                        history.add("PATH")
                                        currentDrawingPoints = emptyList()
                                    }
                                }
                                "LINE" -> {
                                    if (lineStart != null && lineCurrent != null) {
                                        lines.add(DrawLine(lineStart!!, lineCurrent!!, currentColor, 5f))
                                        history.add("LINE")
                                        lineStart = null
                                        lineCurrent = null
                                    }
                                }
                            }
                        }
                    )
                }
        ) {
            // Original photo, drawn UNDER the drawing overlay (FillBounds so
            // drawing coordinates line up with the displayed photo).
            if (originalBitmap != null) {
                Image(
                    bitmap = originalBitmap!!.asImageBitmap(),
                    contentDescription = "নোটের ছবি",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
            } else if (note?.photoPath != null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (photoLoadFailed) "ছবি লোড করা যায়নি" else "ছবি লোড হচ্ছে...",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        if (photoLoadFailed) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = { reattachPicker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = themeStart)) {
                                Text("ছবি আবার যোগ করুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Render Drawing Overlay
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                // Draw completed paths
                paths.forEach { p ->
                    if (p.points.size > 1) {
                        for (i in 0 until p.points.size - 1) {
                            drawLine(
                                color = p.color,
                                start = p.points[i],
                                end = p.points[i + 1],
                                strokeWidth = p.strokeWidth
                            )
                        }
                    }
                }

                // Draw completed straight lines (Straight line ONLY - Rule 7)
                lines.forEach { l ->
                    drawLine(
                        color = l.color,
                        start = l.start,
                        end = l.end,
                        strokeWidth = l.strokeWidth
                    )
                }

                // Draw points
                points.forEach { pt ->
                    drawCircle(color = pt.color, radius = pt.radius, center = pt.position)
                }

                // Draw texts
                texts.forEach { t ->
                    drawContext.canvas.nativeCanvas.apply {
                        val paint = AndroidPaint().apply {
                            color = t.color.toArgb()
                            textSize = t.textSize
                            isAntiAlias = true
                            typeface = android.graphics.Typeface.DEFAULT_BOLD
                        }
                        drawText(t.text, t.position.x, t.position.y, paint)
                    }
                }

                // Draw active gesture
                if (currentDrawingPoints.size > 1) {
                    val activeColor = if (currentTool == "ERASE") Color(0xFF0F172A) else currentColor
                    val activeStroke = if (currentTool == "ERASE") 24f else 6f
                    for (i in 0 until currentDrawingPoints.size - 1) {
                        drawLine(
                            color = activeColor,
                            start = currentDrawingPoints[i],
                            end = currentDrawingPoints[i + 1],
                            strokeWidth = activeStroke
                        )
                    }
                }

                if (lineStart != null && lineCurrent != null) {
                    drawLine(
                        color = currentColor,
                        start = lineStart!!,
                        end = lineCurrent!!,
                        strokeWidth = 5f
                    )
                }
            }
        }
        }

        // Tools Section (BELOW the photo - Rule 7, never shrinking the photo)
        Surface(
            color = Color(0xFF1E293B),
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                // Zoom controls: +/- buttons (pinch alone was unreliable because
                // the drawing gesture consumed it). Zoom is viewing-only.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "জুম: ${(zoomScale * 100).toInt()}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = {
                                zoomScale = (zoomScale - 0.5f).coerceIn(1f, 4f)
                                if (zoomScale <= 1f) zoomOffset = Offset.Zero
                            },
                            modifier = Modifier.size(36.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("-", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                        Button(
                            onClick = { zoomScale = (zoomScale + 0.5f).coerceIn(1f, 4f) },
                            modifier = Modifier.size(36.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("+", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                        OutlinedButton(
                            onClick = { zoomScale = 1f; zoomOffset = Offset.Zero },
                            modifier = Modifier.height(36.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("1x", color = Color.White, fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                // Color Palette Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            Color(0xFF0D9488), // Teal
                            Color(0xFF0284C7), // Blue
                            Color(0xFFEF4444), // Red
                            Color(0xFFF59E0B), // Yellow
                            Color(0xFF10B981), // Green
                            Color.White,
                            Color.Black
                        ).forEach { col ->
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .background(col, CircleShape)
                                    .border(
                                        width = if (currentColor == col) 3.dp else 1.dp,
                                        color = if (currentColor == col) Color.White else Color.Gray,
                                        shape = CircleShape
                                    )
                                    .clickable { currentColor = col }
                            )
                        }
                    }

                    // Undo / Redo
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = {
                                if (history.isNotEmpty()) {
                                    val last = history.removeLast()
                                    when (last) {
                                        "PATH" -> if (paths.isNotEmpty()) paths.removeLast()
                                        "LINE" -> if (lines.isNotEmpty()) lines.removeLast()
                                        "POINT" -> if (points.isNotEmpty()) points.removeLast()
                                        "TEXT" -> if (texts.isNotEmpty()) texts.removeLast()
                                    }
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Undo, contentDescription = "Undo", tint = Color.White)
                        }

                        IconButton(
                            onClick = {
                                paths.clear()
                                lines.clear()
                                points.clear()
                                texts.clear()
                                history.clear()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear All", tint = Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Tool Selector Buttons: Draw, Straight line ONLY, Text, Point, Erase
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    EditorToolButton(icon = Icons.Default.Brush, label = "ড্র", selected = currentTool == "DRAW", selectedColor = themeStart) {
                        currentTool = if (currentTool == "DRAW") "NONE" else "DRAW"
                    }
                    EditorToolButton(icon = Icons.Default.Timeline, label = "সোজা দাগ", selected = currentTool == "LINE", selectedColor = themeStart) {
                        currentTool = if (currentTool == "LINE") "NONE" else "LINE"
                    }
                    EditorToolButton(icon = Icons.Default.TextFields, label = "লেখা", selected = currentTool == "TEXT", selectedColor = themeStart) {
                        if (currentTool == "TEXT") currentTool = "NONE" else { currentTool = "TEXT"; showTextInputDialog = true }
                    }
                    EditorToolButton(icon = Icons.Default.FiberManualRecord, label = "পয়েন্ট", selected = currentTool == "POINT", selectedColor = themeStart) {
                        currentTool = if (currentTool == "POINT") "NONE" else "POINT"
                    }
                    EditorToolButton(icon = Icons.Default.AutoFixNormal, label = "ইরেজার", selected = currentTool == "ERASE", selectedColor = themeStart) {
                        currentTool = if (currentTool == "ERASE") "NONE" else "ERASE"
                    }
                }
            }
        }
    }
}

@Composable
fun EditorToolButton(icon: ImageVector, label: String, selected: Boolean, selectedColor: Color = OceanStart, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) selectedColor else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(20.dp))
        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

// 9. Native Prices Screen (Bug 8 & 10: Search, Category filtering chips, + নতুন পণ্য যোগ করুন form with duplicate check, Swipe delete)
@Composable
fun NativePricesScreen(dao: AppDao, settings: SettingsEntity) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val prices by dao.getAllPrices().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("সব") } // সব / ইলেকট্রিক / প্লাম্বিং / স্যানিটারি

    var showAddDialog by remember { mutableStateOf(false) }
    var newProductName by remember { mutableStateOf("") }
    var newProductCat by remember { mutableStateOf("ইলেকট্রিক") }
    var newProductUnit by remember { mutableStateOf("প্রতি পিস") }
    var newProductPrice by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    // Filter list
    val filteredPrices = prices.filter { p ->
        val matchesCategory = (selectedCategory == "সব") || (p.category.equals(selectedCategory, ignoreCase = true))
        val matchesSearch = searchQuery.isBlank() || p.name.contains(searchQuery.trim(), ignoreCase = true)
        matchesCategory && matchesSearch
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("+ নতুন পণ্য যোগ করুন", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Text("পণ্যের নাম", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = newProductName,
                        onValueChange = { newProductName = it },
                        placeholder = { Text("যেমন: এলইডি লাইট ১৮ ওয়াট") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("ক্যাটাগরি", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("ইলেকট্রিক", "প্লাম্বিং", "স্যানিটারি").forEach { cat ->
                            FilterChip(
                                selected = newProductCat == cat,
                                onClick = { newProductCat = cat },
                                label = { Text(cat, fontSize = 11.sp) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("একক (Unit)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = newProductUnit,
                        onValueChange = { newProductUnit = it },
                        placeholder = { Text("যেমন: প্রতি কয়েল / প্রতি পিস") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("দর / দাম (টাকা)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = newProductPrice,
                        onValueChange = { newProductPrice = it },
                        placeholder = { Text("৩৫০") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    if (errorMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(errorMessage, color = ExpenseRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = newProductName.trim()
                        if (trimmed.isBlank()) {
                            errorMessage = "পণ্যের নাম লিখুন"
                            return@Button
                        }
                        if (prices.any { it.name.equals(trimmed, ignoreCase = true) }) {
                            errorMessage = "এই পণ্যটি ইতিমধ্যে তালিকায় আছে!"
                            return@Button
                        }
                        val price = newProductPrice.toDoubleOrNull()
                        if (price == null || price <= 0) {
                            errorMessage = "সঠিক মূল্য দিন"
                            return@Button
                        }
                        coroutineScope.launch {
                            dao.insertPrice(
                                PriceEntity(
                                    id = UUID.randomUUID().toString(),
                                    name = trimmed,
                                    category = newProductCat,
                                    unit = newProductUnit.ifBlank { "প্রতি পিস" },
                                    price = price
                                )
                            )
                            showAddDialog = false
                            newProductName = ""
                            newProductPrice = ""
                            errorMessage = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("যোগ করুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("প্রাইস লিস্ট", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
        Text("Sample prices — check the real price at work time.", fontSize = 12.sp, color = MutedText)
        Spacer(modifier = Modifier.height(12.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("খুঁজুন: কেবল, পাইপ, সুইচ...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MutedText) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips (সব / ইলেকট্রিক / প্লাম্বিং / স্যানিটারি)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("সব", "ইলেকট্রিক", "প্লাম্বিং", "স্যানিটারি").forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { showAddDialog = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = themeStart)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("+ নতুন পণ্য যোগ করুন", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredPrices.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("কোনো পণ্য পাওয়া যায়নি।", color = MutedText, fontSize = 13.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredPrices, key = { it.id }) { price ->
                    SwipeToDeleteContainer(
                        onDelete = { coroutineScope.launch { dao.deletePriceById(price.id) } },
                        confirmTitle = "পণ্য মুছে ফেলবেন?",
                        confirmMessage = "${price.name} তালিকা থেকে মুছে যাবে।"
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val badgeText = when (price.category) {
                                        "ইলেকট্রিক" -> "ELE"
                                        "প্লাম্বিং" -> "PLU"
                                        else -> "SAN"
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .background(themeStart, RoundedCornerShape(10.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(badgeText, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(price.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = InkText)
                                        Text(price.unit, fontSize = 12.sp, color = MutedText)
                                    }
                                }
                                Text("৳ ${price.price.toInt()}", fontWeight = FontWeight.ExtraBold, color = InkText, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 10. Native Notes Screen (Bug 7, 9 & 10: Auto-numbering "নোট ১, নোট ২", Single-line list, Detail tap, Photo Editor tap, Photo picker, Swipe delete)
@Composable
fun NativeNotesScreen(dao: AppDao, settings: SettingsEntity, onOpenEditor: (String) -> Unit) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val notes by dao.getAllNotes().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    var showAddDialog by remember { mutableStateOf(false) }
    var noteTitle by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var attachedPhotoPath by remember { mutableStateOf<String?>(null) }
    var expandedNoteId by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    // Android Photo Picker Launcher: copy the picked image into internal
    // storage and store the FILE path. A raw content:// URI can lose its
    // permission after restart, so it must not be stored as-is.
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val file = File(context.filesDir, "note_photo_${UUID.randomUUID()}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(file).use { output -> input.copyTo(output) }
                    }
                    withContext(Dispatchers.Main) { attachedPhotoPath = file.absolutePath }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { attachedPhotoPath = uri.toString() }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("নতুন নোট যোগ করুন", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    Text("নোটের নাম", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = noteTitle,
                        onValueChange = { noteTitle = it },
                        placeholder = { Text("যেমন: সাইটের মাপ") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Text("নাম না দিলে নোট ১, নোট ২... হিসেবে দেখাবে।", fontSize = 11.sp, color = MutedText)

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("নোট", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        placeholder = { Text("এখানে লিখুন...") },
                        modifier = Modifier.fillMaxWidth().height(100.dp),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("ছবি (ইচ্ছা হলে)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkText)
                    OutlinedButton(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (attachedPhotoPath != null) "✓ ছবি সংযুক্ত হয়েছে" else "ছবি যোগ করুন — ফোন থেকে বেছে নিন", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalTitle = noteTitle.trim().ifBlank {
                            "নোট ${toBengaliNum(notes.size + 1)}"
                        }
                        coroutineScope.launch {
                            dao.insertNote(
                                NoteEntity(
                                    id = UUID.randomUUID().toString(),
                                    title = finalTitle,
                                    text = noteText.trim(),
                                    photoPath = attachedPhotoPath
                                )
                            )
                            showAddDialog = false
                            noteTitle = ""
                            noteText = ""
                            attachedPhotoPath = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("নোট যোগ করুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Work notes & drawings / নোট", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
        Text("নোট জমা হলে নিচে এক লাইনে নাম দেখাবে — নাম চাপলে পুরো নোট ও ড্রয়িং খুলবে।", fontSize = 12.sp, color = MutedText)
        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { showAddDialog = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = themeStart)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("+ নতুন নোট যোগ করুন", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (notes.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("কোনো নোট নেই। নতুন নোট লিখুন।", color = MutedText, fontSize = 13.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(notes, key = { it.id }) { note ->
                    val isExpanded = expandedNoteId == note.id

                    SwipeToDeleteContainer(
                        onDelete = { coroutineScope.launch { dao.deleteNoteById(note.id) } },
                        confirmTitle = "নোট মুছে ফেলবেন?",
                        confirmMessage = "${note.title} মুছে ফেলতে চান?"
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    expandedNoteId = if (isExpanded) null else note.id
                                },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                // Rule 9: Single-line "নোট N — name"
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = note.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = InkText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = null,
                                        tint = MutedText
                                    )
                                }

                                // Full note detail on row tap
                                if (isExpanded) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    if (note.text.isNotBlank()) {
                                        Text(note.text, fontSize = 13.sp, color = InkText, lineHeight = 20.sp)
                                        Spacer(modifier = Modifier.height(10.dp))
                                    }

                                    // Photo section / Editor trigger
                                    Button(
                                        onClick = { onOpenEditor(note.id) },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                                    ) {
                                        Icon(Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("ফটো এডিটর ও ড্রয়িং খুলুন", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 11. Native Settings Screen (Bug 11: Real Google Sign-in with minimal drive.appdata scope, real upload/restore, Auto-sync 30s debounce, offline backup)
@Composable
fun NativeSettingsScreen(
    dao: AppDao,
    settings: SettingsEntity,
    onLockNow: () -> Unit,
    onBack: () -> Unit
) {
    val (themeStart, themeMid, themeEnd) = themeColors(settings.theme)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val syncManager = remember { GoogleDriveSyncManager(context) }

    var googleAccountEmail by remember { mutableStateOf(syncManager.getSignedInAccount()?.email) }
    var isSyncing by remember { mutableStateOf(false) }
    var lastSyncText by remember { mutableStateOf("এখনও ব্যাকআপ নেওয়া হয়নি") }
    // Auto-sync must survive restart: persist in SharedPreferences, not remember only.
    // Previously remember-only, so ON became OFF after reopening the app.
    val autoSyncPrefs = remember { context.getSharedPreferences("sujon_master_prefs", Context.MODE_PRIVATE) }
    var autoSyncEnabled by remember { mutableStateOf(autoSyncPrefs.getBoolean("autoSyncEnabled", false)) }
    var newPinText by remember { mutableStateOf("") }
    var offlineBackupJson by remember { mutableStateOf<String?>(null) }
    var showOfflineRestoreDialog by remember { mutableStateOf(false) }
    val offlineBackupPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (!text.isNullOrBlank()) {
                        withContext(Dispatchers.Main) {
                            offlineBackupJson = text
                            showOfflineRestoreDialog = true
                        }
                    } else {
                        withContext(Dispatchers.Main) { Toast.makeText(context, "ব্যাকআপ ফাইল খালি", Toast.LENGTH_SHORT).show() }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(context, "ব্যাকআপ ফাইল পড়া যায়নি", Toast.LENGTH_SHORT).show() }
                }
            }
        }
    }
    if (showOfflineRestoreDialog && offlineBackupJson != null) {
        AlertDialog(
            onDismissRequest = { showOfflineRestoreDialog = false },
            title = { Text("অফলাইন ব্যাকআপ থেকে ফিরিয়ে আনবেন?", fontWeight = FontWeight.Bold, color = InkText) },
            text = { Text("এটি স্থানীয় ডেটা প্রতিস্থাপন করবে (আপনার ডিভাইসের PIN অপরিবর্তিত থাকবে)।", fontSize = 13.sp, color = MutedText) },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                importJsonToDb(offlineBackupJson!!, dao, currentPin = settings.pinCode, context = context)
                                showOfflineRestoreDialog = false
                                Toast.makeText(context, "অফলাইন ব্যাকআপ থেকে ডেটা ফিরিয়ে আনা হয়েছে", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "ব্যাকআপ ফাইল ঠিক নয়", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("ফিরিয়ে আনুন", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                OutlinedButton(onClick = { showOfflineRestoreDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    // Restore confirmation dialog state
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var cloudBackupTimestamp by remember { mutableStateOf<Long?>(null) }
    var cloudBackupJson by remember { mutableStateOf<String?>(null) }

    // Google Sign-In Activity Launcher
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.result
                googleAccountEmail = account?.email
                Toast.makeText(context, "Google সাইন-ইন সফল: ${account?.email}", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "সাইন-ইন ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            val detail = try {
                val t = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                t.result
                "no exception"
            } catch (e: Exception) {
                "${e.javaClass.simpleName}: ${e.message}"
            }
            Toast.makeText(context, "সাইন-ইন ব্যর্থ (result=${result.resultCode}): $detail", Toast.LENGTH_LONG).show()
        }
    }

    // Auto-sync loop was HERE before and never worked in real use: this
    // Settings screen is disposed as soon as the user leaves Settings, so its
    // LaunchedEffect was cancelled and no upload ever happened after that.
    // The real loop now lives in MainAppScreen (runs while the app is open,
    // whatever screen is shown). This screen only saves the toggle.

    // Restore Confirmation Dialog
    if (showRestoreConfirmDialog && cloudBackupJson != null) {
        val dateStr = if (cloudBackupTimestamp != null) SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(cloudBackupTimestamp!!)) else "অজ্ঞাত"
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = false },
            title = { Text("ক্লাউড থেকে ফিরিয়ে আনবেন?", fontWeight = FontWeight.Bold, color = InkText) },
            text = {
                Text("ক্লাউড ব্যাকআপের তারিখ: $dateStr। এটি স্থানীয় ডেটা প্রতিস্থাপন করবে (আপনার ডিভাইসের PIN অপরিবর্তিত থাকবে)।", fontSize = 13.sp, color = MutedText)
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            importJsonToDb(cloudBackupJson!!, dao, currentPin = settings.pinCode, context = context)
                            showRestoreConfirmDialog = false
                            Toast.makeText(context, "ক্লাউড থেকে ডেটা সফলভাবে পুনরুদ্ধার করা হয়েছে", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("ফিরিয়ে আনুন", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRestoreConfirmDialog = false }, shape = RoundedCornerShape(12.dp)) {
                    Text("বাতিল", color = InkText)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = SurfaceColor
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Button(
                onClick = onBack,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = themeStart)
            ) {
                Text("← ফিরে যান", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text("সেটিংস ও ক্লাউড সিঙ্ক", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
        }

        // Theme + Hide Money Card (Vibrant Flow options)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("থিম ও টাকা লুকান", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
                    Text("Vibrant Flow থিম বদলান, টাকার অংক লুকান বা দেখান", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("sunset" to "সানসেট", "ocean" to "ওশান", "leaf" to "লিফ").forEach { (themeKey, themeLabel) ->
                            val isThemeSelected = settings.theme == themeKey
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        dao.updateSettings(settings.copy(theme = themeKey))
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isThemeSelected) themeStart else Color(0xFFF1F5F9),
                                    contentColor = if (isThemeSelected) Color.White else InkText
                                )
                            ) {
                                Text(themeLabel, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("bn" to "বাংলা", "en" to "English").forEach { (langKey, langLabel) ->
                            val isLangSelected = settings.language == langKey
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        dao.updateSettings(settings.copy(language = langKey))
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isLangSelected) themeStart else Color(0xFFF1F5F9),
                                    contentColor = if (isLangSelected) Color.White else InkText
                                )
                            ) {
                                Text(langLabel, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                    Text("ভাষা বদলালে শুধু নিচের মেনু লেবেল বদলাবে, ভেতরের লেখা বাংলাই থাকবে।", fontSize = 11.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("টাকা লুকান (Eye Hide)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkText)
                        Switch(
                            checked = settings.hideMoney,
                            onCheckedChange = { hidden ->
                                coroutineScope.launch {
                                    dao.updateSettings(settings.copy(hideMoney = hidden))
                                }
                            }
                        )
                    }
                }
            }
        }

        // Offline Backup Card (JSON share / restore, PIN never exported)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("অফলাইন ব্যাকআপ (JSON)", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
                    Text("ইন্টারনেট ছাড়া ব্যাকআপ ফাইল শেয়ার করুন, পরে সেই ফাইল থেকে ফিরিয়ে আনুন। PIN এই ফাইলে যাবে না।", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            coroutineScope.launch(Dispatchers.IO) {
                                try {
                                    val json = exportDbAsJson(dao, context)
                                    val file = File(context.cacheDir, "sujon_master_backup.json")
                                    FileOutputStream(file).use { it.write(json.toByteArray(Charsets.UTF_8)) }
                                    val uri = FileProvider.getUriForFile(context, "com.worksledger.app.fileprovider", file)
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/json"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        putExtra(Intent.EXTRA_SUBJECT, "SUJON MASTER Backup")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    withContext(Dispatchers.Main) { context.startActivity(Intent.createChooser(intent, "ব্যাকআপ ফাইল শেয়ার করুন")) }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) { Toast.makeText(context, "ব্যাকআপ তৈরি ব্যর্থ", Toast.LENGTH_SHORT).show() }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                    ) { Text("ব্যাকআপ ফাইল সংরক্ষণ / শেয়ার করুন", fontWeight = FontWeight.Bold) }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { offlineBackupPicker.launch("*/*") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("ব্যাকআপ ফাইল থেকে ফিরিয়ে আনুন", color = InkText, fontWeight = FontWeight.Bold) }
                    Text("নোটের ছবি ফাইল এই JSON এ যাবে না, শুধু নোটের লেখা ও ছবির পথ যাবে।", fontSize = 11.sp, color = MutedText)
                }
            }
        }

        // Google Backup / Sync Card (Vibrant Flow style)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Google Backup / Sync", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
                    Text("গুগল ড্রাইভ অ্যাপ ফোল্ডারে (appDataFolder) ব্যাকআপ", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (googleAccountEmail == null) {
                        Button(
                            onClick = {
                                val signInIntent = syncManager.getGoogleSignInClient().signInIntent
                                googleSignInLauncher.launch(signInIntent)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                        ) {
                            Icon(Icons.Default.Cloud, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Google দিয়ে সাইন-ইন করুন", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF5F0))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("সংযুক্ত: $googleAccountEmail", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = InkText)
                                Text("সর্বশেষ: $lastSyncText", fontSize = 11.sp, color = MutedText)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Upload Now
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isSyncing = true
                                    val json = exportDbAsJson(dao, context)
                                    val result = syncManager.uploadBackupToDrive(json)
                                    isSyncing = false
                                    if (result.isSuccess) {
                                        val now = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
                                        lastSyncText = now
                                        Toast.makeText(context, "ব্যাকআপ সফল হয়েছে • $now", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, result.exceptionOrNull()?.message ?: "ব্যাকআপ ব্যর্থ", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = themeStart),
                            enabled = !isSyncing
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isSyncing) "ব্যাকআপ হচ্ছে..." else "এখনই ব্যাকআপ নিন", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Restore From Cloud
                        OutlinedButton(
                            onClick = {
                                coroutineScope.launch {
                                    isSyncing = true
                                    val result = syncManager.downloadBackupFromDrive()
                                    isSyncing = false
                                    if (result.isSuccess) {
                                        val (json, modified) = result.getOrThrow()
                                        cloudBackupJson = json
                                        cloudBackupTimestamp = modified
                                        showRestoreConfirmDialog = true
                                    } else {
                                        Toast.makeText(context, result.exceptionOrNull()?.message ?: "ক্লাউড থেকে ব্যাকআপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            enabled = !isSyncing
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, tint = themeStart)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ক্লাউড থেকে ফিরিয়ে আনুন", color = InkText, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Auto-Sync Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("অটো সিঙ্ক (Auto Sync)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkText)
                                Text("হিসাব বদলালে ৩০ সেকেন্ড পর স্বয়ংক্রিয় ব্যাকআপ", fontSize = 11.sp, color = MutedText)
                            }
                            Switch(
                                checked = autoSyncEnabled,
                                onCheckedChange = {
                                    autoSyncEnabled = it
                                    autoSyncPrefs.edit().putBoolean("autoSyncEnabled", it).apply()
                                }
                            )
                        }

                        TextButton(
                            onClick = {
                                syncManager.getGoogleSignInClient().signOut()
                                googleAccountEmail = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("সাইন-আউট করুন", color = ExpenseRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Security / PIN Lock Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("সিকিউরিটি ও PIN লক", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = InkText)
                    Text("অ্যাপ ওপেন করার সময় ৪ সংখ্যার PIN পাসওয়ার্ড", fontSize = 12.sp, color = MutedText)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        if (settings.pinCode.length == 4) "PIN সেট করা আছে (বদলাতে নিচে নতুন PIN দিন)" else "PIN এখনও সেট করা নেই - আগে নিচে ৪ সংখ্যার PIN সেট করুন",
                        fontSize = 12.sp, color = MutedText
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newPinText,
                        onValueChange = { v -> newPinText = v.filter { it.isDigit() }.take(4) },
                        placeholder = { Text("নতুন ৪ সংখ্যার PIN", fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (newPinText.length == 4) {
                                coroutineScope.launch {
                                    dao.updateSettings(settings.copy(pinCode = newPinText))
                                    newPinText = ""
                                }
                                Toast.makeText(context, "PIN সংরক্ষণ করা হয়েছে", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "৪ সংখ্যার PIN দিন", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = themeStart)
                    ) { Text("PIN সংরক্ষণ করুন", fontWeight = FontWeight.Bold) }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("PIN লক সক্রিয়", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = InkText)
                        Switch(
                            checked = settings.pinLockEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled && settings.pinCode.length != 4) {
                                    Toast.makeText(context, "আগে ৪ সংখ্যার PIN সেট করুন", Toast.LENGTH_SHORT).show()
                                } else {
                                    coroutineScope.launch {
                                        dao.updateSettings(settings.copy(pinLockEnabled = enabled))
                                    }
                                }
                            }
                        )
                    }

                    if (settings.pinLockEnabled) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onLockNow,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = InkText)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("এখনই লক করুন", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 12. Native Lock Screen
@Composable
fun NativeLockScreen(correctPin: String, onUnlocked: () -> Unit) {
    var entered by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize().background(OceanStart),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text("SUJON ⚡ MASTER", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("৪ সংখ্যার PIN দিন", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            Spacer(modifier = Modifier.height(24.dp))

            // 4 Dots
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                for (i in 0..3) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .background(
                                if (i < entered.length) Color.White else Color.White.copy(alpha = 0.3f),
                                CircleShape
                            )
                    )
                }
            }

            if (error) {
                Spacer(modifier = Modifier.height(12.dp))
                Text("ভুল PIN! আবার চেষ্টা করুন", color = Color(0xFFFFC9A8), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Keypad
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "DEL")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (r in 0..3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        for (c in 0..2) {
                            val key = keys[r * 3 + c]
                            if (key.isEmpty()) {
                                Spacer(modifier = Modifier.size(64.dp))
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                        .clickable {
                                            if (key == "DEL") {
                                                if (entered.isNotEmpty()) entered = entered.dropLast(1)
                                                error = false
                                            } else {
                                                if (entered.length < 4) {
                                                    entered += key
                                                    if (entered.length == 4) {
                                                        if (entered == correctPin && correctPin.isNotEmpty()) {
                                                            onUnlocked()
                                                        } else {
                                                            error = true
                                                            entered = ""
                                                        }
                                                    }
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (key == "DEL") "⌫" else toBengaliNum(key),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// JSON Serialization Helpers for Cloud Backup
suspend fun exportDbAsJson(dao: AppDao, context: Context): String = withContext(Dispatchers.IO) {
    val root = JSONObject()
    root.put("version", 1)
    root.put("timestamp", System.currentTimeMillis())
    fun arr(items: List<JSONObject>): JSONArray {
        val a = JSONArray()
        items.forEach { a.put(it) }
        return a
    }
    root.put("daily", arr(dao.getAllDailyEntries().first().map {
        JSONObject().put("id", it.id).put("type", it.type).put("details", it.details).put("amount", it.amount).put("date", it.date).put("createdAt", it.createdAt)
    }))
    root.put("workers", arr(dao.getAllWorkers().first().map {
        JSONObject().put("id", it.id).put("name", it.name).put("role", it.role).put("dailyWage", it.dailyWage).put("createdAt", it.createdAt)
    }))
    root.put("attendance", arr(dao.getAllAttendance().first().map {
        JSONObject().put("id", it.id).put("workerId", it.workerId).put("date", it.date)
    }))
    root.put("overtime", arr(dao.getAllOvertime().first().map {
        JSONObject().put("id", it.id).put("workerId", it.workerId).put("date", it.date).put("amount", it.amount)
    }))
    root.put("workerPayments", arr(dao.getAllWorkerPayments().first().map {
        JSONObject().put("id", it.id).put("workerId", it.workerId).put("date", it.date).put("amount", it.amount).put("note", it.note).put("createdAt", it.createdAt)
    }))
    root.put("sites", arr(dao.getAllSites().first().map {
        JSONObject().put("id", it.id).put("name", it.name).put("type", it.type).put("totalBill", it.totalBill).put("startDate", it.startDate).put("createdAt", it.createdAt)
    }))
    root.put("sitePayments", arr(dao.getAllSitePayments().first().map {
        JSONObject().put("id", it.id).put("siteId", it.siteId).put("date", it.date).put("amount", it.amount).put("details", it.details).put("createdAt", it.createdAt)
    }))
    root.put("siteExpenses", arr(dao.getAllSiteExpenses().first().map {
        JSONObject().put("id", it.id).put("siteId", it.siteId).put("date", it.date).put("category", it.category).put("workerCount", if (it.workerCount != null) it.workerCount else JSONObject.NULL).put("details", it.details).put("amount", it.amount).put("createdAt", it.createdAt)
    }))
    root.put("notes", arr(dao.getAllNotes().first().map { note ->
        val jo = JSONObject().put("id", note.id).put("title", note.title).put("text", note.text).put("photoPath", if (note.photoPath != null) note.photoPath else JSONObject.NULL).put("createdAt", note.createdAt)
        // Include the photo FILE itself (Base64, scaled to max 1024px, JPEG 80) so a
        // cloud/offline restore after uninstall still has the photo. Previously only
        // photoPath was saved, so after uninstall the file was gone and the editor
        // showed "ছবি লোড করা যায়নি".
        try {
            val f = if (note.photoPath.isNullOrBlank() || note.photoPath.startsWith("content://")) null else File(note.photoPath)
            val bmp0 = if (f != null && f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
            if (bmp0 != null) {
                val scale = minOf(1f, 1024f / maxOf(bmp0.width, bmp0.height).toFloat())
                val bmp = if (scale < 1f) Bitmap.createScaledBitmap(bmp0, (bmp0.width * scale).toInt(), (bmp0.height * scale).toInt(), true) else bmp0
                val baos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 80, baos)
                jo.put("photoData", Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP))
                if (bmp != bmp0) bmp.recycle()
            } else jo.put("photoData", JSONObject.NULL)
        } catch (e: Exception) { jo.put("photoData", JSONObject.NULL) }
        jo
    }))
    root.put("prices", arr(dao.getAllPrices().first().map {
        JSONObject().put("id", it.id).put("name", it.name).put("category", it.category).put("unit", it.unit).put("price", it.price).put("createdAt", it.createdAt)
    }))
    // Settings WITHOUT pinCode and WITHOUT pinLockEnabled: PIN is never exported.
    val cur = dao.getSettings().first()
    val s = JSONObject().put("theme", cur?.theme ?: "ocean").put("language", cur?.language ?: "bn").put("hideMoney", cur?.hideMoney ?: false).put("seedInitialized", true)
    root.put("settings", s)
    root.toString()
}

suspend fun importJsonToDb(jsonStr: String, dao: AppDao, currentPin: String, context: Context) = withContext(Dispatchers.IO) {
    val root = JSONObject(jsonStr)
    val current = dao.getSettings().first()
    // Clear existing data first, so restore replaces (never merges) local accounts.
    dao.getAllDailyEntries().first().forEach { dao.deleteDailyEntryById(it.id) }
    dao.getAllWorkers().first().forEach { dao.deleteWorkerAndRelations(it.id) }
    dao.getAllAttendance().first().forEach { dao.deleteAttendance(it.workerId, it.date) }
    dao.getAllOvertime().first().forEach { dao.deleteOvertime(it.workerId, it.date) }
    dao.getAllWorkerPayments().first().forEach { dao.deleteWorkerPaymentById(it.id) }
    dao.getAllSites().first().forEach { dao.deleteSiteAndRelations(it.id) }
    dao.getAllSitePayments().first().forEach { dao.deleteSitePaymentById(it.id) }
    dao.getAllSiteExpenses().first().forEach { dao.deleteSiteExpenseById(it.id) }
    dao.getAllNotes().first().forEach { dao.deleteNoteById(it.id) }
    dao.getAllPrices().first().forEach { dao.deletePriceById(it.id) }
    fun objs(key: String): List<JSONObject> {
        val a = root.optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).mapNotNull { try { a.getJSONObject(it) } catch (e: Exception) { null } }
    }
    objs("daily").forEach { o -> dao.insertDailyEntry(DailyEntity(o.optString("id"), o.optString("type"), o.optString("details"), o.optDouble("amount"), o.optString("date"), o.optLong("createdAt", System.currentTimeMillis()))) }
    objs("workers").forEach { o -> dao.insertWorker(WorkerEntity(o.optString("id"), o.optString("name"), o.optString("role"), o.optDouble("dailyWage"), o.optLong("createdAt", System.currentTimeMillis()))) }
    objs("attendance").forEach { o -> dao.insertAttendance(AttendanceEntity(o.optString("id"), o.optString("workerId"), o.optString("date"))) }
    objs("overtime").forEach { o -> dao.insertOvertime(OvertimeEntity(o.optString("id"), o.optString("workerId"), o.optString("date"), o.optDouble("amount"))) }
    objs("workerPayments").forEach { o -> dao.insertWorkerPayment(WorkerPaymentEntity(o.optString("id"), o.optString("workerId"), o.optString("date"), o.optDouble("amount"), o.optString("note"), o.optLong("createdAt", System.currentTimeMillis()))) }
    objs("sites").forEach { o -> dao.insertSite(SiteEntity(o.optString("id"), o.optString("name"), o.optString("type"), o.optDouble("totalBill"), o.optString("startDate"), o.optLong("createdAt", System.currentTimeMillis()))) }
    objs("sitePayments").forEach { o -> dao.insertSitePayment(SitePaymentEntity(o.optString("id"), o.optString("siteId"), o.optString("date"), o.optDouble("amount"), o.optString("details"), o.optLong("createdAt", System.currentTimeMillis()))) }
    objs("siteExpenses").forEach { o ->
        val wc = if (o.isNull("workerCount")) null else o.optInt("workerCount")
        dao.insertSiteExpense(SiteExpenseEntity(o.optString("id"), o.optString("siteId"), o.optString("date"), o.optString("category"), wc, o.optString("details"), o.optDouble("amount"), o.optLong("createdAt", System.currentTimeMillis())))
    }
    objs("notes").forEach { o ->
        var restoredPath: String? = if (o.isNull("photoPath")) null else o.optString("photoPath")
        // If the backup carries photoData (Base64), write it back to internal storage
        // and use the new file path, so the photo survives uninstall/restore.
        try {
            val data = if (o.isNull("photoData")) null else o.optString("photoData")
            if (!data.isNullOrBlank()) {
                val bytes = Base64.decode(data, Base64.DEFAULT)
                val file = File(context.filesDir, "note_photo_${o.optString("id")}.jpg")
                FileOutputStream(file).use { it.write(bytes) }
                restoredPath = file.absolutePath
            }
        } catch (e: Exception) { }
        dao.insertNote(NoteEntity(o.optString("id"), o.optString("title"), o.optString("text"), restoredPath, o.optLong("createdAt", System.currentTimeMillis())))
    }
    objs("prices").forEach { o -> dao.insertPrice(PriceEntity(o.optString("id"), o.optString("name"), o.optString("category"), o.optString("unit"), o.optDouble("price"), o.optLong("createdAt", System.currentTimeMillis()))) }
    // Restore theme/language/hideMoney, but NEVER overwrite PIN or lock state.
    val bs = root.optJSONObject("settings")
    dao.updateSettings(
        SettingsEntity(
            id = 1,
            theme = bs?.optString("theme", current?.theme ?: "ocean") ?: (current?.theme ?: "ocean"),
            language = bs?.optString("language", current?.language ?: "bn") ?: (current?.language ?: "bn"),
            hideMoney = bs?.optBoolean("hideMoney", current?.hideMoney ?: false) ?: (current?.hideMoney ?: false),
            pinLockEnabled = current?.pinLockEnabled ?: false,
            pinCode = currentPin,
            seedInitialized = true
        )
    )
}
