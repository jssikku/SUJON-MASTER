package com.worksledger.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Vibrant Flow Colors
val PageBackground = Color(0xFFFFF8F1)
val SurfaceColor = Color(0xFFFFFFFF)
val LineBorder = Color(0xFFF0DDD2)
val InkText = Color(0xFF1D1A18)
val MutedText = Color(0xFF7A6F68)
val IncomeGreen = Color(0xFF0A9D6B)
val ExpenseRed = Color(0xFFE5484D)

// Sunset: #FF5A3C → #FFB020 → #FF3D8A
val SunsetStart = Color(0xFFFF5A3C)
val SunsetMid = Color(0xFFFFB020)
val SunsetEnd = Color(0xFFFF3D8A)

// Ocean: #009E8F → #2563EB → #00C2D1
val OceanStart = Color(0xFF009E8F)
val OceanMid = Color(0xFF2563EB)
val OceanEnd = Color(0xFF00C2D1)

// Leaf: #16A34A → #84CC16 → #009E8F
val LeafStart = Color(0xFF16A34A)
val LeafMid = Color(0xFF84CC16)
val LeafEnd = Color(0xFF009E8F)

// Light Mode ONLY (Rule 3)
private val LightColorScheme = lightColorScheme(
    primary = OceanStart,
    onPrimary = Color.White,
    background = PageBackground,
    surface = SurfaceColor,
    onBackground = InkText,
    onSurface = InkText,
    outline = LineBorder
)

@Composable
fun SujonMasterTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
