package com.worksledger.app.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.worksledger.app.data.AttendanceEntity
import com.worksledger.app.data.OvertimeEntity
import com.worksledger.app.data.SiteEntity
import com.worksledger.app.data.SitePaymentEntity
import com.worksledger.app.data.WorkerEntity
import com.worksledger.app.data.WorkerPaymentEntity
import java.io.File
import java.io.FileOutputStream

object NativePdfGenerator {

    /**
     * RULE 13: Worker PDF in English ONLY, EXACTLY 1 page covering the full account:
     * worked-days table and money-taken table on the same page, with both totals and summary/due.
     */
    private fun dayAbbr(dateStr: String): String {
        return try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH)
            val d = sdf.parse(dateStr) ?: return ""
            val cal = java.util.Calendar.getInstance()
            cal.time = d
            when (cal.get(java.util.Calendar.DAY_OF_WEEK)) {
                java.util.Calendar.SATURDAY -> "Sat"
                java.util.Calendar.SUNDAY -> "Sun"
                java.util.Calendar.MONDAY -> "Mon"
                java.util.Calendar.TUESDAY -> "Tue"
                java.util.Calendar.WEDNESDAY -> "Wed"
                java.util.Calendar.THURSDAY -> "Thu"
                else -> "Fri"
            }
        } catch (e: Exception) { "" }
    }

    private fun trunc(text: String, max: Int): String {
        return if (text.length <= max) text else text.substring(0, max - 1) + "…"
    }

    /** Worker PDF: English, EXACTLY 1 page, boxed tables. */
    fun generateWorkerPdf(
        context: Context,
        worker: WorkerEntity,
        year: Int,
        month: Int,
        attendance: List<AttendanceEntity>,
        overtime: List<OvertimeEntity>,
        payments: List<WorkerPaymentEntity>
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint().apply { isAntiAlias = true }

        val att = attendance.sortedBy { it.date }
        val pays = payments.sortedBy { it.date }
        val totalDays = att.size
        val haziraEarned = totalDays * worker.dailyWage
        val otEarned = overtime.sumOf { it.amount }
        val totalEarned = haziraEarned + otEarned
        val totalTaken = pays.sumOf { it.amount }
        val due = totalEarned - totalTaken

        // Header band (boxed)
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#0F172A")
        canvas.drawRect(20f, 20f, 575f, 80f, paint)
        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 16f
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("SUJON MASTER \u2014 WORKER STATEMENT", 35f, 48f, paint)
        paint.textSize = 10f
        paint.typeface = Typeface.DEFAULT
        paint.color = Color.parseColor("#94A3B8")
        canvas.drawText("ELECTRIC \u2022 PLUMBING \u2022 SANITARY CONTRACTOR", 35f, 68f, paint)

        // Worker info line
        paint.color = Color.parseColor("#0F172A")
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 11f
        canvas.drawText("Name: ${worker.name}  |  Role: ${worker.role}  |  Daily Wage: BDT ${worker.dailyWage.toInt()}  |  Month: $year-${String.format("%02d", month)}", 20f, 100f, paint)

        // 6 summary boxes
        val boxLabels = listOf("Worked Days", "Hazira Earned", "OT Earned", "Total Earned", "Taken", "Due")
        val boxValues = listOf("$totalDays", "BDT ${haziraEarned.toInt()}", "BDT ${otEarned.toInt()}", "BDT ${totalEarned.toInt()}", "BDT ${totalTaken.toInt()}", "BDT ${due.toInt()}")
        val boxW = 87f
        val boxGap = 6f
        val boxTop = 112f
        val boxH = 48f
        for (i in 0 until 6) {
            val x = 20f + i * (boxW + boxGap)
            paint.style = Paint.Style.STROKE
            paint.color = Color.parseColor("#CBD5E1")
            paint.strokeWidth = 1f
            canvas.drawRect(x, boxTop, x + boxW, boxTop + boxH, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#64748B")
            paint.textSize = 8f
            paint.typeface = Typeface.DEFAULT
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(boxLabels[i], x + boxW / 2, boxTop + 16f, paint)
            paint.color = Color.parseColor("#0F172A")
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 12f
            canvas.drawText(boxValues[i], x + boxW / 2, boxTop + 36f, paint)
            paint.textAlign = Paint.Align.LEFT
        }

        // Tables: side by side, boxed, with header + total rows, exactly 1 page
        val maxRows = maxOf(att.size, pays.size, 1)
        val tableTop = 176f
        val headerH = 20f
        val totalRowH = 20f
        var rowH = (800f - tableTop - headerH - totalRowH) / maxRows
        if (rowH > 18f) rowH = 18f
        if (rowH < 9f) rowH = 9f

        fun drawTable(x0: Float, width: Float, title: String, headers: List<Pair<Float, String>>, rows: List<List<String>>, totalLabel: String, totalValue: String) {
            // Title band
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#0F172A")
            canvas.drawRect(x0, tableTop, x0 + width, tableTop + headerH, paint)
            paint.color = Color.WHITE
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 9f
            canvas.drawText(title, x0 + 8f, tableTop + 14f, paint)
            // Header row (column names are drawn as a second dark row? Keep title only, then rows with borders)
            var y = tableTop + headerH
            // Column header row
            paint.color = Color.parseColor("#E2E8F0")
            canvas.drawRect(x0, y, x0 + width, y + 16f, paint)
            paint.color = Color.parseColor("#0F172A")
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 8f
            var cx = x0
            for ((cw, h) in headers) {
                canvas.drawText(h, cx + 4f, y + 11f, paint)
                cx += cw
            }
            y += 16f
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 8.5f
            for (ri in rows.indices) {
                val row = rows[ri]
                if (ri % 2 == 1) {
                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#F8FAFC")
                    canvas.drawRect(x0, y, x0 + width, y + rowH, paint)
                }
                paint.style = Paint.Style.STROKE
                paint.color = Color.parseColor("#CBD5E1")
                paint.strokeWidth = 0.7f
                canvas.drawRect(x0, y, x0 + width, y + rowH, paint)
                // vertical dividers
                var vx = x0
                for ((cw, _) in headers) {
                    vx += cw
                    if (vx < x0 + width - 1f) canvas.drawLine(vx, y, vx, y + rowH, paint)
                }
                paint.style = Paint.Style.FILL
                paint.color = Color.BLACK
                var tx = x0
                for (ci in row.indices) {
                    val cw = headers[ci].first
                    canvas.drawText(row[ci], tx + 4f, y + rowH - 5f, paint)
                    tx += cw
                }
                y += rowH
            }
            // Total row
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#E0F2FE")
            canvas.drawRect(x0, y, x0 + width, y + totalRowH, paint)
            paint.style = Paint.Style.STROKE
            paint.color = Color.parseColor("#0F172A")
            paint.strokeWidth = 1.2f
            canvas.drawRect(x0, y, x0 + width, y + totalRowH, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#0F172A")
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 9f
            canvas.drawText(totalLabel, x0 + 4f, y + 14f, paint)
            // total value right-aligned in last column
            val lastColW = headers.last().first
            val lastX = x0 + width - lastColW
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText(totalValue, x0 + width - 4f, y + 14f, paint)
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.DEFAULT
        }

        val workedRows = att.mapIndexed { i, a ->
            val ot = overtime.find { it.date == a.date }
            val wageText = if (ot != null && ot.amount > 0) "${worker.dailyWage.toInt()}+${ot.amount.toInt()}" else "${worker.dailyWage.toInt()}"
            listOf("${i + 1}", a.date, dayAbbr(a.date), wageText)
        }
        val takenRows = pays.mapIndexed { i, pay ->
            listOf("${i + 1}", pay.date, trunc(pay.note, 14), "${pay.amount.toInt()}")
        }
        drawTable(20f, 272f, "WORKED DAYS (${att.size})",
            listOf(28f to "#", 90f to "Date", 70f to "Day", 84f to "Wage"),
            workedRows, "Total", "${haziraEarned.toInt()}")
        drawTable(303f, 272f, "MONEY TAKEN (${pays.size})",
            listOf(28f to "#", 90f to "Date", 82f to "Details", 72f to "Amount"),
            takenRows, "Total", "${totalTaken.toInt()}")

        paint.color = Color.parseColor("#94A3B8")
        paint.textSize = 8f
        paint.typeface = Typeface.DEFAULT
        canvas.drawText("SUJON MASTER App \u2014 Confidential Ledger Statement \u2014 Page 1 of 1", 160f, 825f, paint)
        document.finishPage(page)
        val outputFile = File(context.cacheDir, "Worker_${worker.name}_Statement.pdf")
        document.writeTo(FileOutputStream(outputFile))
        document.close()
        return outputFile
    }

    /** Site PDF: Bengali, received-only, boxed table, paginated. */
    fun generateSitePdf(
        context: Context,
        site: SiteEntity,
        payments: List<SitePaymentEntity>
    ): File {
        val document = PdfDocument()
        val rowsPerPage = 24
        val sorted = payments.sortedBy { it.date }
        val chunks = if (sorted.isEmpty()) listOf(emptyList()) else sorted.chunked(rowsPerPage)
        val totalPages = chunks.size
        val totalReceived = sorted.sumOf { it.amount }
        chunks.forEachIndexed { pageIndex, chunk ->
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageIndex + 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply { isAntiAlias = true }
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#009E8F")
            canvas.drawRect(20f, 20f, 575f, 85f, paint)
            paint.color = Color.WHITE
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 16f
            canvas.drawText("SUJON MASTER \u2014 \u09b8\u09be\u0987\u099f \u099c\u09ae\u09be\u09b0 \u09b0\u09b6\u09bf\u09a6", 35f, 48f, paint)
            paint.textSize = 11f
            paint.typeface = Typeface.DEFAULT
            canvas.drawText("\u09b8\u09be\u0987\u099f\u09c7\u09b0 \u09a8\u09be\u09ae: ${site.name}  |  \u0995\u09be\u099c\u09c7\u09b0 \u09a7\u09b0\u09a8: ${site.type}", 35f, 70f, paint)
            // Table header
            val tableTop = 105f
            val headerH = 20f
            val rowH = 22f
            paint.color = Color.parseColor("#0F172A")
            canvas.drawRect(20f, tableTop, 575f, tableTop + headerH, paint)
            paint.color = Color.WHITE
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 9f
            canvas.drawText("#", 24f, tableTop + 14f, paint)
            canvas.drawText("\u09a4\u09be\u09b0\u09bf\u0996", 54f, tableTop + 14f, paint)
            canvas.drawText("\u09ac\u09bf\u09ac\u09b0\u09a3", 174f, tableTop + 14f, paint)
            canvas.drawText("\u099f\u09be\u0995\u09be", 480f, tableTop + 14f, paint)
            var y = tableTop + headerH
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
            chunk.forEachIndexed { i, pay ->
                val num = pageIndex * rowsPerPage + i + 1
                if (i % 2 == 1) {
                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#F8FAFC")
                    canvas.drawRect(20f, y, 575f, y + rowH, paint)
                }
                paint.style = Paint.Style.STROKE
                paint.color = Color.parseColor("#CBD5E1")
                paint.strokeWidth = 0.7f
                canvas.drawRect(20f, y, 575f, y + rowH, paint)
                canvas.drawLine(50f, y, 50f, y + rowH, paint)
                canvas.drawLine(170f, y, 170f, y + rowH, paint)
                canvas.drawLine(470f, y, 470f, y + rowH, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.BLACK
                canvas.drawText("$num", 24f, y + 15f, paint)
                canvas.drawText(pay.date, 54f, y + 15f, paint)
                canvas.drawText(trunc(pay.details, 32), 174f, y + 15f, paint)
                canvas.drawText("BDT ${pay.amount.toInt()}", 474f, y + 15f, paint)
                y += rowH
            }
            if (pageIndex == totalPages - 1) {
                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor("#E0F2FE")
                canvas.drawRect(20f, y, 575f, y + 24f, paint)
                paint.style = Paint.Style.STROKE
                paint.color = Color.parseColor("#009E8F")
                paint.strokeWidth = 1.2f
                canvas.drawRect(20f, y, 575f, y + 24f, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor("#009E8F")
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textSize = 13f
                canvas.drawText("\u09ae\u09cb\u099f \u09aa\u09c7\u09af\u09bc\u09c7\u099b\u09bf: BDT ${totalReceived.toInt()}", 35f, y + 17f, paint)
                y += 24f
            }
            paint.color = Color.GRAY
            paint.textSize = 9f
            paint.typeface = Typeface.DEFAULT
            canvas.drawText("\u09aa\u09c3\u09b7\u09cd\u09a0\u09be ${pageIndex + 1} / $totalPages", 250f, 825f, paint)
            document.finishPage(page)
        }
        val outputFile = File(context.cacheDir, "Site_${site.name}_Received.pdf")
        document.writeTo(FileOutputStream(outputFile))
        document.close()
        return outputFile
    }

    /**
     * Share PDF helper using FileProvider
     */
    fun sharePdf(context: Context, pdfFile: File, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "com.worksledger.app.fileprovider",
            pdfFile
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
