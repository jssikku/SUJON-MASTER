package com.worksledger.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Daily Entries
    @Query("SELECT * FROM daily_entries ORDER BY date DESC, createdAt DESC")
    fun getAllDailyEntries(): Flow<List<DailyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyEntry(entry: DailyEntity)

    @Delete
    suspend fun deleteDailyEntry(entry: DailyEntity)

    @Query("DELETE FROM daily_entries WHERE id = :id")
    suspend fun deleteDailyEntryById(id: String)

    // Workers
    @Query("SELECT * FROM workers ORDER BY createdAt ASC")
    fun getAllWorkers(): Flow<List<WorkerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorker(worker: WorkerEntity)

    @Query("DELETE FROM workers WHERE id = :id")
    suspend fun deleteWorkerById(id: String)

    // Rule 8: Delete worker also deletes their attendance, OT, and payments
    @Transaction
    suspend fun deleteWorkerAndRelations(workerId: String) {
        deleteWorkerById(workerId)
        deleteAttendanceByWorker(workerId)
        deleteOvertimeByWorker(workerId)
        deletePaymentsByWorker(workerId)
    }

    // Attendance
    @Query("SELECT * FROM attendance")
    fun getAllAttendance(): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE workerId = :workerId AND date = :date LIMIT 1")
    suspend fun getAttendance(workerId: String, date: String): AttendanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: AttendanceEntity)

    @Query("DELETE FROM attendance WHERE workerId = :workerId AND date = :date")
    suspend fun deleteAttendance(workerId: String, date: String)

    @Query("DELETE FROM attendance WHERE workerId = :workerId")
    suspend fun deleteAttendanceByWorker(workerId: String)

    // Overtime (Rule 6: Manual OT amount only)
    @Query("SELECT * FROM overtime")
    fun getAllOvertime(): Flow<List<OvertimeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOvertime(ot: OvertimeEntity)

    @Query("DELETE FROM overtime WHERE workerId = :workerId AND date = :date")
    suspend fun deleteOvertime(workerId: String, date: String)

    @Query("DELETE FROM overtime WHERE workerId = :workerId")
    suspend fun deleteOvertimeByWorker(workerId: String)

    // Worker Payments
    @Query("SELECT * FROM worker_payments ORDER BY date DESC")
    fun getAllWorkerPayments(): Flow<List<WorkerPaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkerPayment(payment: WorkerPaymentEntity)

    @Query("DELETE FROM worker_payments WHERE id = :id")
    suspend fun deleteWorkerPaymentById(id: String)

    @Query("DELETE FROM worker_payments WHERE workerId = :workerId")
    suspend fun deletePaymentsByWorker(workerId: String)

    // Sites
    @Query("SELECT * FROM sites ORDER BY createdAt DESC")
    fun getAllSites(): Flow<List<SiteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSite(site: SiteEntity)

    @Query("DELETE FROM sites WHERE id = :id")
    suspend fun deleteSiteById(id: String)

    @Transaction
    suspend fun deleteSiteAndRelations(siteId: String) {
        deleteSiteById(siteId)
        deletePaymentsBySite(siteId)
        deleteExpensesBySite(siteId)
    }

    // Site Payments
    @Query("SELECT * FROM site_payments ORDER BY date DESC")
    fun getAllSitePayments(): Flow<List<SitePaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSitePayment(payment: SitePaymentEntity)

    @Query("DELETE FROM site_payments WHERE id = :id")
    suspend fun deleteSitePaymentById(id: String)

    @Query("DELETE FROM site_payments WHERE siteId = :siteId")
    suspend fun deletePaymentsBySite(siteId: String)

    // Site Expenses
    @Query("SELECT * FROM site_expenses ORDER BY date DESC")
    fun getAllSiteExpenses(): Flow<List<SiteExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSiteExpense(expense: SiteExpenseEntity)

    @Query("DELETE FROM site_expenses WHERE id = :id")
    suspend fun deleteSiteExpenseById(id: String)

    @Query("DELETE FROM site_expenses WHERE siteId = :siteId")
    suspend fun deleteExpensesBySite(siteId: String)

    // Notes
    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: String)

    // Prices
    @Query("SELECT * FROM prices ORDER BY createdAt ASC")
    fun getAllPrices(): Flow<List<PriceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrice(price: PriceEntity)

    @Query("DELETE FROM prices WHERE id = :id")
    suspend fun deletePriceById(id: String)

    // Settings
    @Query("SELECT * FROM settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<SettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateSettings(settings: SettingsEntity)
}
