# SUJON ⚡ MASTER — Android & Web Ledger App

A complete, 100% offline-first native Android app and web ledger designed for electric, plumbing, and sanitary contractors in Bangladesh.

- **Package**: `com.worksledger.app`
- **Native Architecture**: Kotlin + Jetpack Compose + Room Database
- **Offline First**: All attendance, hazira, daily income/expenses, sites, notes, and prices remain stored locally on the phone in Room / local storage.
- **Optional Cloud Sync**: Google Sign-In with private Google Drive `appDataFolder` (`drive.appdata`) for seamless backup and device transfer.

---

## ☁️ Google Cloud Setup (One-time Setup Guide)

Google Sign-In and Google Drive `appDataFolder` sync require a standard Google Cloud project configuration to authenticate the Android app (`com.worksledger.app`). Follow these 5 steps:

### Step 1: Create Google Cloud Project & Enable Google Drive API
1. Open [Google Cloud Console](https://console.cloud.google.com/).
2. Click **Select a project** > **New Project**, name it `SUJON-MASTER-APP`, and click **Create**.
3. In the search bar at the top, search for **Google Drive API** and click **Enable**.

### Step 2: Configure OAuth Consent Screen
1. Go to **APIs & Services** > **OAuth consent screen**.
2. Select **External** and click **Create**.
3. Fill in:
   - **App name**: `SUJON MASTER`
   - **User support email**: your Gmail address
   - **Developer contact information**: your Gmail address
4. Under **Scopes**, click **Add or Remove Scopes** and select:
   - `.../auth/drive.appdata` (*See, create, and delete its own configuration data in your Google Drive*)
   - `userinfo.email` and `userinfo.profile`
5. Under **Test users**, add your own Gmail address (or publish the app if distributing). Click **Save and Continue**.

### Step 3: Create Android OAuth Client ID
1. Go to **APIs & Services** > **Credentials** > **Create Credentials** > **OAuth client ID**.
2. Set **Application type** to `Android`.
3. Set **Package name** to:
   ```
   com.worksledger.app
   ```
4. Obtain and enter your **SHA-1 certificate fingerprint**:
   - **In Android Studio**: Open the Gradle tab on the right > `app` > `Tasks` > `android` > double-click `signingReport`. Look for the `SHA1:` line in the console.
   - **In Terminal / Keystore**:
     ```bash
     keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
     ```
   - **In AI Studio / Cloud Builder**: The signing certificate SHA-1 is located in the builder's Project Settings / Deployment Keys section. Copy that SHA-1.
5. Click **Create**.

### Step 4: Add Configuration File
1. If using Firebase Auth / Google Services plugin, download `google-services.json` from the Firebase Console (linked to the same Google Cloud Project).
2. Place `google-services.json` in the `android/app/` directory:
   ```
   android/app/google-services.json
   ```

### Step 5: Test & Verify
1. Build and install the APK on your phone.
2. Open the app (works 100% offline).
3. Navigate to **Settings (গিয়ার বোতাম)** > **Google Backup / Sync**.
4. Tap **Google দিয়ে সাইন-ইন করুন** and choose your Gmail.
5. Tap **এখনই ব্যাকআপ নিন** (Upload now).
6. On a second phone or fresh install: sign in with the same Gmail, tap **ক্লাউড থেকে ফিরিয়ে আনুন** (Restore from cloud), confirm the prompt, and all records restore instantly!

---

## 🔒 Privacy & Permissions (Smallest Scope Rule)
- Uses strictly `drive.appdata` (`https://www.googleapis.com/auth/drive.appdata`).
- Does **NOT** request full Drive access, Gmail read/send, Contacts, or Calendar access.
- `appDataFolder` is completely isolated to SUJON MASTER. It is hidden from standard Google Drive browser views and cannot be read by other apps.
- **PIN and PIN Lock state are NEVER synced or exported** to cloud or backup files.

---

## 📁 Project Structure

```
├── android/                             # Complete Android Studio project (Kotlin + Compose + Room)
│   ├── app/
│   │   ├── build.gradle.kts             # Dependencies (Compose, Room, Play Services Auth, Drive REST API)
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       └── java/com/worksledger/app/
│   │           ├── data/                # Room Database, DAOs, and Entities
│   │           ├── sync/                # GoogleDriveSyncManager (appDataFolder)
│   │           └── ui/                  # Jetpack Compose Screens (Overview, Daily, Team, Sites, Notes, Prices, Settings, Lock)
│   ├── build.gradle.kts
│   └── settings.gradle.kts
├── src/                                 # Web Application / Interactive Preview
│   ├── components/                      # React SPA Components matching mobile design
│   ├── context/AppContext.tsx           # Live state, auto-sync (30s debounce), calculations
│   ├── utils/                           # Offline storage, Bengali formatting, PDF generators
│   └── types/                           # TypeScript interfaces
└── README.md
```

---

## 🇧🇩 বাংলা নির্দেশিকা (Google Cloud ব্যাকআপ চালু করার নিয়ম)

১. [Google Cloud Console](https://console.cloud.google.com/)-এ গিয়ে একটি নতুন প্রজেক্ট তৈরি করুন এবং **Google Drive API** চালু (Enable) করুন।  
২. **OAuth consent screen**-এ অ্যাপের নাম দিন `SUJON MASTER` এবং শুধু `drive.appdata` স্কোপ যুক্ত করুন।  
৩. **Credentials**-এ গিয়ে **Android OAuth Client ID** তৈরি করুন। প্যাকেজ নাম দিন `com.worksledger.app` এবং আপনার signing key-এর **SHA-1** দিন।  
৪. `google-services.json` ফাইলটি নামিয়ে `android/app/` ফোল্ডারে রাখুন।  
৫. অ্যাপের সেটিংসে গিয়ে **Google দিয়ে সাইন-ইন করুন**-এ চাপ দিন। এরপর যেকোনো সময় **এখনই ব্যাকআপ নিন** বা **ক্লাউড থেকে ফিরিয়ে আনুন** ব্যবহার করতে পারবেন।
