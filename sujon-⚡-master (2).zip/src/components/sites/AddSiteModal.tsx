import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getTodayDateString, toEnglishNumber } from '../../utils/bengali';

interface AddSiteModalProps {
  onClose: () => void;
}

export const AddSiteModal: React.FC<AddSiteModalProps> = ({ onClose }) => {
  const { addSite, themeStyles } = useApp();
  const [name, setName] = useState('');
  const [type, setType] = useState('ইলেক্ট্রিক + প্লাম্বিং');
  const [billStr, setBillStr] = useState('');
  const [startDate, setStartDate] = useState(getTodayDateString());
  const [firstPayStr, setFirstPayStr] = useState('');
  const [error, setError] = useState('');

  const siteTypes = [
    'ইলেক্ট্রিক + প্লাম্বিং',
    'ইলেক্ট্রিক কাজ',
    'প্লাম্বিং ও স্যানিটারি',
    'বাড়ি ওয়্যারিং',
    'ফ্ল্যাট রেনোভেশন',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      setError('সাইটের নাম লিখুন');
      return;
    }
    const bill = billStr ? parseFloat(toEnglishNumber(billStr.trim())) : 0;
    const firstPay = firstPayStr ? parseFloat(toEnglishNumber(firstPayStr.trim())) : 0;

    const res = addSite(cleanName, type, bill, startDate, firstPay);
    if (!res.success) {
      setError(res.message || 'ত্রুটি ঘটেছে');
      return;
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[28px] sm:rounded-[28px] p-5 pb-8 sm:pb-6 shadow-2xl border border-[#F0DDD2] animate-in slide-in-from-bottom duration-200">
        <div className="w-12 h-1.5 bg-[#E6DACF] rounded-full mx-auto mb-3" />

        <h3 className="text-xl font-bold text-[#1D1A18] mb-4">
          + নতুন সাইট হিসাব খুলুন
        </h3>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              সাইটের নাম
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              placeholder="যেমন: ধানমন্ডি ফ্ল্যাট / উত্তরা বাড়ি"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              কাজের ধরন
            </label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            >
              {siteTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
                মোট চুক্তি বিল (৳)
              </label>
              <input
                type="text"
                inputMode="numeric"
                value={billStr}
                onChange={(e) => setBillStr(e.target.value)}
                placeholder="যেমন: ১২০০০০"
                className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
                কাজ শুরুর তারিখ
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-xs font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              ১ম কিস্তি অগ্রিম পাওয়া (৳) (ঐচ্ছিক)
            </label>
            <input
              type="text"
              inputMode="numeric"
              value={firstPayStr}
              onChange={(e) => setFirstPayStr(e.target.value)}
              placeholder="যেমন: ৫০,০০০"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          {error && <p className="text-xs font-bold text-[#E5484D]">{error}</p>}

          <div className="flex gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-[16px] bg-[#F4EBE3] text-[#1D1A18] font-bold text-sm hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className={`flex-1 py-3 px-4 rounded-[16px] text-white font-bold text-sm shadow-md active:scale-[0.98] transition-all ${themeStyles.primaryBtn}`}
            >
              সাইট খুলুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
