import React, { useState, useMemo } from 'react';
import { ArrowLeft, FileDown, Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  formatTaka,
  formatBengaliDate,
  getTodayDateString,
  toEnglishNumber,
  toBengaliNumber,
} from '../../utils/bengali';
import { SwipeToDelete } from '../common/SwipeToDelete';
import { generateSitePdf } from '../../utils/pdf';

interface SiteDetailScreenProps {
  siteId: string;
}

export const SiteDetailScreen: React.FC<SiteDetailScreenProps> = ({ siteId }) => {
  const {
    sites,
    sitePayments,
    siteExpenses,
    addSitePayment,
    deleteSitePayment,
    addSiteExpense,
    deleteSiteExpense,
    goBack,
    themeStyles,
  } = useApp();

  const site = sites.find((s) => s.id === siteId);

  // Add Payment form state
  const [payAmountStr, setPayAmountStr] = useState('');
  const [payDetails, setPayDetails] = useState('');
  const [payDate, setPayDate] = useState(getTodayDateString());
  const [payError, setPayError] = useState('');

  // Add Expense form state
  const [expDate, setExpDate] = useState(getTodayDateString());
  const [expCategory, setExpCategory] = useState<'কর্মী খরচ' | 'অন্যান্য খরচ'>('কর্মী খরচ');
  const [expWorkerCount, setExpWorkerCount] = useState('');
  const [expDetails, setExpDetails] = useState('');
  const [expAmountStr, setExpAmountStr] = useState('');
  const [expError, setExpError] = useState('');

  if (!site) {
    return (
      <div className="p-6 text-center">
        <p className="text-sm text-[#7A6F68]">সাইট পাওয়া যায়নি।</p>
        <button
          type="button"
          onClick={goBack}
          className="mt-4 px-4 py-2 rounded-xl bg-[#F0DDD2] text-[#1D1A18] font-bold text-sm"
        >
          ফিরে যান
        </button>
      </div>
    );
  }

  // Filtered site data
  const currentPayments = useMemo(() => {
    return sitePayments
      .filter((p) => p.siteId === site.id)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [sitePayments, site.id]);

  const currentExpenses = useMemo(() => {
    return siteExpenses
      .filter((e) => e.siteId === site.id)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [siteExpenses, site.id]);

  // Calculations
  const totalReceived = currentPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalExpense = currentExpenses.reduce((sum, e) => sum + e.amount, 0);
  const netAmount = totalReceived - totalExpense;
  const billDue = site.totalBill > 0 ? site.totalBill - totalReceived : null;

  const handleAddPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(toEnglishNumber(payAmountStr.trim()));
    if (isNaN(amount) || amount <= 0) {
      setPayError('সঠিক টাকার অঙ্ক দিন');
      return;
    }
    addSitePayment(site.id, payDate, amount, payDetails.trim() || 'নগদ গ্রহণ / কিস্তি');
    setPayAmountStr('');
    setPayDetails('');
    setPayError('');
  };

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(toEnglishNumber(expAmountStr.trim()));
    if (isNaN(amount) || amount <= 0) {
      setExpError('সঠিক খরচের টাকার অঙ্ক দিন');
      return;
    }
    const count = expWorkerCount ? parseInt(toEnglishNumber(expWorkerCount.trim()), 10) : undefined;
    const details = expDetails.trim() || (expCategory === 'কর্মী খরচ' ? 'মিস্ত্রি মজুরি' : 'সাইট খরচ');

    addSiteExpense(site.id, expDate, expCategory, details, amount, count);
    setExpAmountStr('');
    setExpDetails('');
    setExpWorkerCount('');
    setExpError('');
  };

  const handleDownloadPdf = async () => {
    await generateSitePdf(site, sitePayments);
  };

  return (
    <div className="pb-28 animate-in fade-in duration-200">
      {/* Top Banner */}
      <header className={`w-full ${themeStyles.headerGradient} text-white pt-5 pb-5 px-4 sm:px-5 rounded-b-[28px] shadow-md`}>
        <button
          type="button"
          onClick={goBack}
          className="flex items-center gap-1.5 text-white/95 hover:text-white font-bold text-sm active:scale-95 transition-all mb-3"
        >
          <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          <span>← সাইটে ফিরুন</span>
        </button>

        <h2 className="text-2xl font-extrabold text-white tracking-tight">
          {site.name} — {site.type}
        </h2>
        <p className="text-xs text-white/90 font-medium mt-1">
          কাজ শুরু: {formatBengaliDate(site.startDate)}
        </p>
      </header>

      {/* Main Container */}
      <main className="px-4 sm:px-5 mt-4 space-y-5">
        {/* 4 Stat Boxes (Screenshot 9) */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">পেয়েছি</span>
            <p className="text-lg font-extrabold text-[#1D1A18] mt-0.5">
              {formatTaka(totalReceived)}
            </p>
          </div>

          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">মোট খরচ</span>
            <p className="text-lg font-extrabold text-[#E5484D] mt-0.5">
              {formatTaka(totalExpense)}
            </p>
          </div>

          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">নেট (পেয়েছি – খরচ)</span>
            <p className={`text-lg font-extrabold mt-0.5 ${netAmount >= 0 ? 'text-[#0A9D6B]' : 'text-[#E5484D]'}`}>
              {formatTaka(netAmount)}
            </p>
          </div>

          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">বাকি (বিল থেকে)</span>
            <p className="text-lg font-extrabold text-[#1D1A18] mt-0.5">
              {billDue !== null ? formatTaka(billDue) : '—'}
            </p>
          </div>
        </div>

        {/* Section 1: পাওয়া টাকা */}
        <section className="bg-white rounded-[22px] border border-[#F0DDD2] p-4 shadow-xs">
          <h3 className="text-base font-bold text-[#1D1A18] mb-3">
            পাওয়া টাকা
          </h3>

          {/* List of received entries */}
          <div className="space-y-1.5 mb-4">
            {currentPayments.length === 0 ? (
              <p className="text-xs text-[#7A6F68] py-2 italic text-center">
                এখনও কোনো টাকা পাওয়ার হিসাব জমা হয়নি।
              </p>
            ) : (
              currentPayments.map((p) => (
                <SwipeToDelete
                  key={p.id}
                  onDelete={() => deleteSitePayment(p.id)}
                  confirmTitle="পেমেন্ট মুছে ফেলতে চান?"
                  confirmMessage={`${formatBengaliDate(p.date)}-এর ${formatTaka(p.amount)} পেমেন্ট মুছে ফেলা হবে।`}
                >
                  <div className="p-3.5 bg-white border border-[#F0DDD2] rounded-[18px] flex items-center justify-between shadow-xs">
                    <div>
                      <p className="text-sm font-bold text-[#1D1A18]">
                        {formatBengaliDate(p.date)} — {p.details || 'কিস্তি'}
                      </p>
                    </div>
                    <span className="text-base font-extrabold text-[#009E8F]">
                      {formatTaka(p.amount)}
                    </span>
                  </div>
                </SwipeToDelete>
              ))
            )}
          </div>

          {/* Add Received Money Form (Screenshot 9) */}
          <form onSubmit={handleAddPayment} className="space-y-2.5 pt-2 border-t border-[#F0DDD2]">
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                inputMode="numeric"
                value={payAmountStr}
                onChange={(e) => {
                  setPayAmountStr(e.target.value);
                  if (payError) setPayError('');
                }}
                placeholder="টাকা (৳)"
                className="w-full px-3 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
              />
              <input
                type="date"
                value={payDate}
                onChange={(e) => setPayDate(e.target.value)}
                className="w-full px-2 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-xs font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
              />
            </div>
            <input
              type="text"
              value={payDetails}
              onChange={(e) => setPayDetails(e.target.value)}
              placeholder="বিবরণ: অগ্রিম / ২য় কিস্তি"
              className="w-full px-3 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-xs text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
            />
            {payError && <p className="text-xs font-bold text-[#E5484D]">{payError}</p>}

            <button
              type="submit"
              className="w-full py-3 rounded-[15px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-bold text-sm shadow-sm active:scale-[0.98] transition-all"
            >
              যোগ করুন
            </button>
          </form>
        </section>

        {/* Section 2: সাইটের খরচ (Rule 12: does NOT go into PDF) */}
        <section className="bg-white rounded-[22px] border border-[#F0DDD2] p-4 shadow-xs">
          <h3 className="text-base font-bold text-[#1D1A18]">
            সাইটের খরচ
          </h3>
          <p className="text-xs text-[#7A6F68] mt-1 mb-3 leading-relaxed">
            এই খরচ শুধু এই সাইটের হিসাবের জন্য — PDF-এ যাবে না। কতজন কর্মী কাজ করেছে আর তাদের পেছনে কত টাকা গেছে, এখানে লিখে রাখুন।
          </p>

          {/* List of expense rows */}
          <div className="space-y-1.5 mb-4">
            {currentExpenses.length === 0 ? (
              <p className="text-xs text-[#7A6F68] py-2 italic text-center">
                এই সাইটে এখনও কোনো খরচ জমা নেই।
              </p>
            ) : (
              currentExpenses.map((exp) => (
                <SwipeToDelete
                  key={exp.id}
                  onDelete={() => deleteSiteExpense(exp.id)}
                  confirmTitle="খরচ মুছে ফেলতে চান?"
                  confirmMessage={`${formatBengaliDate(exp.date)}-এর ${formatTaka(exp.amount)} খরচ মুছে ফেলা হবে।`}
                >
                  <div className="p-3.5 bg-white border border-[#F0DDD2] rounded-[18px] flex items-center justify-between shadow-xs">
                    <div>
                      <p className="text-sm font-bold text-[#1D1A18]">
                        {formatBengaliDate(exp.date)} — {exp.details}
                      </p>
                      <p className="text-xs text-[#7A6F68] mt-0.5">
                        {exp.category} {exp.workerCount ? `• ${toBengaliNumber(exp.workerCount)} জন কর্মী` : ''}
                      </p>
                    </div>
                    <span className="text-base font-extrabold text-[#E5484D]">
                      - {formatTaka(exp.amount)}
                    </span>
                  </div>
                </SwipeToDelete>
              ))
            )}
          </div>

          {/* Add Expense Form (Screenshot 1) */}
          <form onSubmit={handleAddExpense} className="space-y-2.5 pt-2 border-t border-[#F0DDD2]">
            <div className="grid grid-cols-2 gap-2">
              <input
                type="date"
                value={expDate}
                onChange={(e) => setExpDate(e.target.value)}
                className="w-full px-2 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-xs font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
              />
              <select
                value={expCategory}
                onChange={(e) => setExpCategory(e.target.value as any)}
                className="w-full px-2 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-xs font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
              >
                <option value="কর্মী খরচ">কর্মী খরচ</option>
                <option value="অন্যান্য খরচ">অন্যান্য খরচ</option>
              </select>
            </div>

            {expCategory === 'কর্মী খরচ' && (
              <input
                type="text"
                inputMode="numeric"
                value={expWorkerCount}
                onChange={(e) => setExpWorkerCount(e.target.value)}
                placeholder="কতজন কর্মী"
                className="w-full px-3 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-xs text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
              />
            )}

            <input
              type="text"
              value={expDetails}
              onChange={(e) => setExpDetails(e.target.value)}
              placeholder="বিবরণ: যেমন মিস্ত্রি হাজিরা / গাড়ি ভাড়া"
              className="w-full px-3 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-xs text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
            />

            <input
              type="text"
              inputMode="numeric"
              value={expAmountStr}
              onChange={(e) => {
                setExpAmountStr(e.target.value);
                if (expError) setExpError('');
              }}
              placeholder="টাকা (৳)"
              className="w-full px-3 py-2.5 rounded-[14px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F]"
            />

            {expError && <p className="text-xs font-bold text-[#E5484D]">{expError}</p>}

            <button
              type="submit"
              className="w-full py-3 rounded-[15px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-bold text-sm shadow-sm active:scale-[0.98] transition-all"
            >
              খরচ যোগ করুন
            </button>
          </form>
        </section>

        {/* Bottom CTA Buttons (Screenshot 1) */}
        <div className="space-y-2 pt-2">
          <button
            type="button"
            onClick={handleDownloadPdf}
            className="w-full py-3.5 rounded-[18px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-md active:scale-[0.98] transition-all"
          >
            <FileDown className="w-5 h-5" />
            <span>PDF শেয়ার</span>
          </button>

          <button
            type="button"
            onClick={goBack}
            className="w-full py-3.5 rounded-[18px] bg-white border border-[#F0DDD2] text-[#1D1A18] font-bold text-sm flex items-center justify-center gap-2 hover:bg-[#FAF5F0] active:scale-[0.98] transition-all shadow-xs"
          >
            <span>← সাইটে ফিরুন</span>
          </button>

          <p className="text-[11px] text-[#7A6F68] text-center px-4 pt-1 leading-normal">
            PDF-এ শুধু পাওয়া টাকার তালিকা বাংলায় যাবে — খরচ, মোট বিল বা বাকি যাবে না।
          </p>
        </div>
      </main>
    </div>
  );
};
