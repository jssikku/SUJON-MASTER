import React, { useState } from 'react';
import { Plus, FileDown } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatTaka, formatBengaliDate } from '../../utils/bengali';
import { Site } from '../../types';
import { AddSiteModal } from './AddSiteModal';
import { SwipeToDelete } from '../common/SwipeToDelete';
import { generateSitePdf } from '../../utils/pdf';

export const SitesScreen: React.FC = () => {
  const { sites, sitePayments, deleteSite, setScreen, language } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);

  const handleDownloadPdf = async (site: Site) => {
    await generateSitePdf(site, sitePayments);
  };

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Top Header */}
      <header className="px-4 sm:px-5 pt-5 pb-3">
        <h2 className="text-2xl font-extrabold text-[#1D1A18] tracking-tight">
          {language === 'en' ? 'Site accounts' : 'সাইট হিসাব'}
        </h2>
        <p className="text-xs font-semibold text-[#7A6F68] mt-1">
          {language === 'en'
            ? 'Money received and due stay separate for each site.'
            : 'প্রতিটি সাইটের জন্য পাওয়া টাকা ও বকেয়া আলাদা থাকে।'}
        </p>

        {/* Top + New Site Button (Screenshot 5) */}
        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="w-full py-3.5 mt-4 rounded-[18px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-md active:scale-[0.98] transition-all"
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>+ নতুন সাইট হিসাব খুলুন</span>
        </button>
      </header>

      {/* Sites List */}
      <main className="px-4 sm:px-5 mt-2 space-y-3">
        {sites.length === 0 ? (
          <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-8 text-center text-[#7A6F68] text-sm my-4">
            {language === 'en'
              ? 'No sites yet. Open a new site account above.'
              : 'কোনো সাইট নেই। উপরে নতুন সাইট হিসাব খুলুন।'}
          </div>
        ) : (
          sites.map((site) => {
            const payments = sitePayments.filter((p) => p.siteId === site.id);
            const totalReceived = payments.reduce((sum, p) => sum + p.amount, 0);
            const due = site.totalBill > 0 ? site.totalBill - totalReceived : null;
            const progressPercent =
              site.totalBill > 0
                ? Math.min(100, Math.round((totalReceived / site.totalBill) * 100))
                : 100;

            return (
              <SwipeToDelete
                key={site.id}
                onDelete={() => deleteSite(site.id)}
                confirmTitle="সাইট মুছে ফেলতে চান?"
                confirmMessage={`"${site.name}" সাইটের সমস্ত পাওয়া টাকা ও খরচের হিসাব মুছে ফেলা হবে।`}
              >
                <div className="bg-white rounded-[22px] border border-[#F0DDD2] shadow-xs overflow-hidden">
                  {/* Top subtle gradient highlight bar */}
                  <div className="h-1.5 w-full bg-gradient-to-r from-[#009E8F] via-[#2563EB] to-[#00C2D1]" />

                  <div className="p-4 sm:p-5">
                    <h3 className="text-base sm:text-lg font-extrabold text-[#1D1A18] leading-snug">
                      {site.name} — {site.type}
                    </h3>
                    <p className="text-xs text-[#7A6F68] mt-1 font-medium">
                      কাজ শুরু: {formatBengaliDate(site.startDate)}
                    </p>

                    {/* Progress Bar */}
                    <div className="w-full bg-[#FAF5F0] rounded-full h-2 mt-3.5 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-[#009E8F] to-[#00C2D1] h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>

                    {/* Received and Due Stats */}
                    <div className="flex items-center justify-between mt-3 text-xs sm:text-sm">
                      <div>
                        <span className="text-[#7A6F68] font-medium">পেয়েছি </span>
                        <span className="font-extrabold text-[#1D1A18]">
                          {formatTaka(totalReceived)}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#7A6F68] font-medium">বাকি </span>
                        <span className="font-extrabold text-[#E5484D]">
                          {due !== null ? formatTaka(due) : '—'}
                        </span>
                      </div>
                    </div>

                    {/* Buttons: হিসাব দেখুন & PDF শেয়ার (Screenshot 5) */}
                    <div className="grid grid-cols-2 gap-2.5 mt-4">
                      <button
                        type="button"
                        onClick={() =>
                          setScreen({ type: 'site-detail', siteId: site.id })
                        }
                        className="py-3 px-3 rounded-[16px] bg-white border border-[#E9DACD] text-[#1D1A18] font-bold text-xs hover:bg-[#FAF5F0] active:scale-[0.98] transition-all text-center shadow-xs"
                      >
                        হিসাব দেখুন
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownloadPdf(site)}
                        className="py-3 px-3 rounded-[16px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-bold text-xs active:scale-[0.98] transition-all text-center shadow-xs flex items-center justify-center gap-1.5"
                      >
                        <FileDown className="w-4 h-4" />
                        <span>PDF শেয়ার</span>
                      </button>
                    </div>
                  </div>
                </div>
              </SwipeToDelete>
            );
          })
        )}

        {/* Bottom + New Site Button (Screenshot 5) */}
        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="w-full py-4 rounded-[20px] bg-white border border-[#F0DDD2] hover:border-[#009E8F] text-[#1D1A18] font-extrabold text-sm flex items-center justify-center gap-2 shadow-xs active:scale-[0.99] transition-all my-2"
        >
          <Plus className="w-5 h-5 text-[#009E8F] stroke-[2.5]" />
          <span>+ নতুন সাইট হিসাব খুলুন</span>
        </button>

        {/* Footer Note (Screenshot 5) */}
        <p className="text-[11px] text-[#7A6F68] text-center px-4 pt-2 leading-relaxed">
          PDF শেয়ার বোতামে শুধু তারিখ অনুযায়ী কত টাকা পেয়েছেন, সেই তালিকাটাই বাংলায় যাবে — আর কিছু যাবে না।
        </p>
      </main>

      {/* Add Site Modal */}
      {showAddModal && <AddSiteModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
};
