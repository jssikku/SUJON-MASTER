import React, { useState, useRef } from 'react';
import {
  ArrowLeft,
  Download,
  Upload,
  Shield,
  Lock,
  Palette,
  Globe,
  Eye,
  Cloud,
  UploadCloud,
  DownloadCloud,
  LogOut,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ThemeMode, Language } from '../../types';
import { toEnglishNumber } from '../../utils/bengali';

export const SettingsScreen: React.FC = () => {
  const {
    settings,
    updateSettings,
    theme,
    setTheme,
    language,
    setLanguage,
    hideMoney,
    toggleHideMoney,
    lockNow,
    exportBackupData,
    restoreBackupData,
    goBack,
    themeStyles,
    googleAccount,
    isSyncing,
    cloudMetadata,
    cloudConflict,
    signInWithGoogle,
    signOutGoogle,
    uploadToCloud,
    restoreFromCloud,
    toggleAutoSync,
    ignoreConflict,
  } = useApp();

  // PIN setup state
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [pinSuccess, setPinSuccess] = useState('');

  // Google Cloud state
  const [googleEmailInput, setGoogleEmailInput] = useState('sumusikku@gmail.com');
  const [showBackupOverwriteConfirm, setShowBackupOverwriteConfirm] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleGoogleSignIn = async () => {
    await signInWithGoogle(googleEmailInput);
  };

  const handleBackupNowClick = () => {
    // If cloud backup already exists: prompt confirmation before overwriting
    if (cloudMetadata) {
      setShowBackupOverwriteConfirm(true);
    } else {
      uploadToCloud();
    }
  };

  const confirmBackupOverwrite = async () => {
    setShowBackupOverwriteConfirm(false);
    await uploadToCloud();
  };

  const handleRestoreCloudClick = () => {
    setShowRestoreConfirm(true);
  };

  const confirmRestoreCloud = async () => {
    setShowRestoreConfirm(false);
    await restoreFromCloud();
  };

  const handleTogglePinLock = () => {
    if (settings.pinLockEnabled) {
      // Turn off
      updateSettings({ pinLockEnabled: false });
      setPinSuccess('লক বন্ধ করা হয়েছে');
    } else {
      if (settings.pinCode && settings.pinCode.length === 4) {
        updateSettings({ pinLockEnabled: true });
        setPinSuccess('লক চালু করা হয়েছে');
      } else {
        setPinError('লক চালু করতে প্রথমে ৪ সংখ্যার PIN সেট করুন');
      }
    }
  };

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNew = toEnglishNumber(newPin.trim());
    const cleanConfirm = toEnglishNumber(confirmPin.trim());

    if (cleanNew.length !== 4 || !/^\d{4}$/.test(cleanNew)) {
      setPinError('PIN অবশ্যই ঠিক ৪ সংখ্যার হতে হবে');
      setPinSuccess('');
      return;
    }

    if (cleanNew !== cleanConfirm) {
      setPinError('দুটো PIN মেলেনি! আবার লিখুন');
      setPinSuccess('');
      return;
    }

    updateSettings({
      pinCode: cleanNew,
      pinLockEnabled: true,
    });
    setNewPin('');
    setConfirmPin('');
    setPinError('');
    setPinSuccess('নতুন ৪ সংখ্যার PIN সফলভাবে সেট ও লক চালু করা হয়েছে');
  };

  const handleExportBackup = () => {
    const jsonStr = exportBackupData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SujonMaster_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const ok = restoreBackupData(content);
      if (ok) {
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="pb-28 animate-in fade-in duration-200">
      {/* Top Header */}
      <header className={`w-full ${themeStyles.headerGradient} text-white pt-5 pb-5 px-4 sm:px-5 rounded-b-[28px] shadow-md`}>
        <button
          type="button"
          onClick={goBack}
          className="flex items-center gap-1.5 text-white/95 hover:text-white font-bold text-sm active:scale-95 transition-all mb-2"
        >
          <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          <span>ফিরে যান</span>
        </button>

        <h2 className="text-2xl font-extrabold text-white tracking-tight">
          সেটিংস ও নিরাপত্তা
        </h2>
        <p className="text-xs text-white/90 font-medium mt-0.5">
          অ্যাপের থিম, ৪ সংখ্যার পিন লক ও অফলাইন ব্যাকআপ
        </p>
      </header>

      {/* Main Container */}
      <main className="px-4 sm:px-5 mt-4 space-y-4">
        {/* Card 1: 4 সংখ্যার PIN লক (Screenshot 8) */}
        <section className="bg-white rounded-[24px] border border-[#F0DDD2] p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-base font-extrabold text-[#1D1A18]">
                ৪ সংখ্যার PIN লক
              </h3>
              <p className="text-xs text-[#7A6F68] mt-0.5 font-medium">
                {settings.pinLockEnabled
                  ? 'লক চালু আছে। অ্যাপে ঢুকতে PIN লাগবে।'
                  : 'লক বন্ধ আছে। PIN সেট করলে লক চালু হবে।'}
              </p>
            </div>

            {/* Custom Toggle Switch */}
            <button
              type="button"
              onClick={handleTogglePinLock}
              className={`w-14 h-8 rounded-full transition-colors p-1 relative flex items-center select-none ${
                settings.pinLockEnabled ? 'bg-[#00B4B4]' : 'bg-[#D5C2B4]'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                  settings.pinLockEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* PIN Setup Form */}
          <form onSubmit={handleSavePin} className="space-y-3.5 mt-4 pt-3 border-t border-[#F0DDD2]">
            <div>
              <label className="block text-xs font-bold text-[#1D1A18] mb-1">
                নতুন ৪ সংখ্যার PIN
              </label>
              <input
                type="password"
                maxLength={4}
                inputMode="numeric"
                value={newPin}
                onChange={(e) => {
                  setNewPin(e.target.value);
                  if (pinError) setPinError('');
                }}
                placeholder="• • • •"
                className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-center text-xl tracking-widest font-extrabold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1D1A18] mb-1">
                আবার PIN লিখুন
              </label>
              <input
                type="password"
                maxLength={4}
                inputMode="numeric"
                value={confirmPin}
                onChange={(e) => {
                  setConfirmPin(e.target.value);
                  if (pinError) setPinError('');
                }}
                placeholder="• • • •"
                className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-center text-xl tracking-widest font-extrabold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
              />
            </div>

            {pinError && <p className="text-xs font-bold text-[#E5484D] text-center">{pinError}</p>}
            {pinSuccess && <p className="text-xs font-bold text-[#0A9D6B] text-center">{pinSuccess}</p>}

            {/* Buttons (Screenshot 8) */}
            <div className="space-y-2 pt-1">
              <button
                type="submit"
                className="w-full py-3.5 rounded-[18px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-extrabold text-sm shadow-md active:scale-[0.98] transition-all text-center"
              >
                PIN সেট করুন ও লক চালু করুন
              </button>

              {settings.pinLockEnabled && settings.pinCode && (
                <button
                  type="button"
                  onClick={lockNow}
                  className="w-full py-3.5 rounded-[18px] bg-white border border-[#F0DDD2] text-[#1D1A18] font-bold text-sm hover:bg-[#FAF5F0] active:scale-[0.98] transition-all shadow-xs"
                >
                  এখনই লক করুন
                </button>
              )}
            </div>

            <p className="text-[11px] text-[#7A6F68] leading-relaxed pt-2">
              PIN এই ফোনে সংরক্ষিত থাকবে — অ্যাপ বন্ধ করে আবার খুললেও PIN আবার সেট করতে হবে না। PIN ব্যাকআপ ফাইলে যাবে না।
            </p>
          </form>
        </section>

        {/* Card 2: Google Backup / Sync (Vibrant Flow style, optional cloud sync) */}
        <section className="bg-white rounded-[24px] border border-[#F0DDD2] p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-extrabold text-[#1D1A18] flex items-center gap-2">
                <Cloud className="w-5 h-5 text-[#009E8F]" />
                <span>Google Backup / Sync</span>
              </h3>
              <p className="text-xs text-[#7A6F68] mt-0.5 font-medium">
                {googleAccount
                  ? 'গুগল ড্রাইভ অ্যাপ ফোল্ডারে (appDataFolder) ব্যাকআপ সংযুক্ত।'
                  : 'ঐচ্ছিক: আপনার জিমেইল দিয়ে ক্লাউড ব্যাকআপ রাখুন।'}
              </p>
            </div>

            {googleAccount && (
              <span className="w-2.5 h-2.5 rounded-full bg-[#0A9D6B] animate-pulse" title="Connected" />
            )}
          </div>

          {/* Cloud Conflict Notice (Rule 7: Never auto-overwrite local work) */}
          {cloudConflict && (
            <div className="p-3.5 bg-[#FFF4E5] border border-[#FFD8A8] rounded-[18px] space-y-2 animate-in fade-in duration-200">
              <div className="flex items-start gap-2 text-xs font-bold text-[#D97706]">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>ক্লাউডে নতুন ডেটা আছে — ফিরিয়ে আনতে চান?</span>
              </div>
              <p className="text-[11px] text-[#7A6F68] leading-relaxed pl-6">
                ক্লাউড ব্যাকআপের সময়: {new Date(cloudConflict.modifiedTime).toLocaleString('bn-BD')} ({Math.round(cloudConflict.sizeBytes / 1024)} KB)।
              </p>
              <div className="flex gap-2 pl-6 pt-1">
                <button
                  type="button"
                  onClick={() => setShowRestoreConfirm(true)}
                  className="px-3 py-1.5 rounded-xl bg-[#D97706] text-white text-xs font-bold hover:bg-[#B45309] active:scale-95 transition-all shadow-xs"
                >
                  ফিরিয়ে আনুন
                </button>
                <button
                  type="button"
                  onClick={ignoreConflict}
                  className="px-3 py-1.5 rounded-xl bg-white border border-[#FFD8A8] text-[#7A6F68] text-xs font-bold hover:bg-[#FFFBF5] active:scale-95 transition-all"
                >
                  উপেক্ষা করুন
                </button>
              </div>
            </div>
          )}

          {!googleAccount ? (
            /* First Time: Google Sign-in flow */
            <div className="space-y-3 pt-1">
              <div>
                <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
                  আপনার Gmail ঠিকানা
                </label>
                <input
                  type="email"
                  value={googleEmailInput}
                  onChange={(e) => setGoogleEmailInput(e.target.value)}
                  placeholder="যেমন: contractor.sujon@gmail.com"
                  className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
                />
              </div>

              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isSyncing}
                className="w-full py-3.5 rounded-[18px] bg-white border border-[#E9DACD] hover:border-[#009E8F] text-[#1D1A18] font-extrabold text-sm flex items-center justify-center gap-2.5 shadow-xs active:scale-[0.98] transition-all"
              >
                {/* Official Google G icon */}
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
                <span>{isSyncing ? 'সংযোগ হচ্ছে...' : 'Google দিয়ে সাইন-ইন করুন'}</span>
              </button>

              <p className="text-[11px] text-[#7A6F68] leading-relaxed pt-1">
                গুগল ড্রাইভের শুধুমাত্র ব্যক্তিগত ফোল্ডারে (appDataFolder) সুরক্ষিত হিসাব রাখা হয়। অ্যাপ কখনোই আপনার পাসওয়ার্ড দেখে না।
              </p>
            </div>
          ) : (
            /* Signed In View */
            <div className="space-y-3.5 pt-1">
              {/* Account Box */}
              <div className="p-3.5 bg-[#FAF5F0] rounded-[18px] border border-[#E9DACD]">
                <div className="flex items-center justify-between">
                  <div className="min-w-0 pr-2">
                    <span className="text-[11px] font-bold text-[#7A6F68] block">সংযুক্ত অ্যাকাউন্ট</span>
                    <p className="text-sm font-extrabold text-[#1D1A18] truncate">
                      {googleAccount.email}
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-[#E0F7F6] text-[#009E8F] text-[10px] font-bold shrink-0">
                    Drive Sync
                  </span>
                </div>
                <div className="mt-2 pt-2 border-t border-[#E9DACD]/60 flex items-center justify-between text-xs text-[#7A6F68]">
                  <span>সর্বশেষ ব্যাকআপ:</span>
                  <span className="font-bold text-[#1D1A18]">
                    {googleAccount.lastSyncTime
                      ? new Date(googleAccount.lastSyncTime).toLocaleString('bn-BD', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : 'এখনও ব্যাকআপ নেওয়া হয়নি'}
                  </span>
                </div>
              </div>

              {/* Action Buttons: এখনই ব্যাকআপ নিন & ক্লাউড থেকে ফিরিয়ে আনুন */}
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleBackupNowClick}
                  disabled={isSyncing}
                  className="w-full py-3.5 rounded-[18px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-extrabold text-sm shadow-md active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-75"
                >
                  <UploadCloud className="w-5 h-5" />
                  <span>{isSyncing ? 'ব্যাকআপ আপলোড হচ্ছে...' : 'এখনই ব্যাকআপ নিন'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleRestoreCloudClick}
                  disabled={isSyncing}
                  className="w-full py-3.5 rounded-[18px] bg-white border border-[#F0DDD2] text-[#1D1A18] font-bold text-sm hover:bg-[#FAF5F0] active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-xs"
                >
                  <DownloadCloud className="w-5 h-5 text-[#009E8F]" />
                  <span>ক্লাউড থেকে ফিরিয়ে আনুন</span>
                </button>
              </div>

              {/* Auto-Sync Switch (Default OFF) */}
              <div className="p-3.5 bg-white rounded-[18px] border border-[#F0DDD2] flex items-center justify-between shadow-xs">
                <div>
                  <span className="text-xs font-bold text-[#1D1A18] block">অটো সিঙ্ক (Auto Sync)</span>
                  <span className="text-[11px] text-[#7A6F68]">
                    হিসাব বদলালে ৩০ সেকেন্ড পর স্বয়ংক্রিয় ব্যাকআপ
                  </span>
                </div>
                <button
                  type="button"
                  onClick={toggleAutoSync}
                  className={`w-12 h-7 rounded-full transition-colors p-1 relative flex items-center select-none ${
                    googleAccount.autoSyncEnabled ? 'bg-[#00B4B4]' : 'bg-[#D5C2B4]'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                      googleAccount.autoSyncEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Sign out button */}
              <button
                type="button"
                onClick={signOutGoogle}
                className="w-full py-2.5 rounded-[16px] text-xs font-bold text-[#E5484D] hover:bg-red-50 active:scale-98 transition-all flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>সাইন-আউট করুন</span>
              </button>
            </div>
          )}
        </section>

        {/* Card 3: অফলাইন ব্যাকআপ (Screenshot 8) */}
        <section className="bg-white rounded-[24px] border border-[#F0DDD2] p-5 shadow-xs">
          <h3 className="text-base font-extrabold text-[#1D1A18] mb-1">
            অফলাইন ব্যাকআপ
          </h3>
          <p className="text-xs text-[#7A6F68] leading-relaxed mb-4">
            ইন্টারনেট ছাড়াই হিসাবের একটি কপি ফাইলে নামিয়ে রাখুন। পরে সেই ফাইল দিয়েই হিসাব ফিরিয়ে আনা যাবে। ফাইলটি আপনার ফোনেই থাকবে।
          </p>

          <input
            type="file"
            ref={fileInputRef}
            accept=".json"
            onChange={handleRestoreFile}
            className="hidden"
          />

          <div className="space-y-2.5">
            <button
              type="button"
              onClick={handleExportBackup}
              className="w-full py-3.5 rounded-[18px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-extrabold text-sm shadow-md active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              <span>ব্যাকআপ ডাউনলোড করুন</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-3.5 rounded-[18px] bg-white border border-[#F0DDD2] text-[#1D1A18] font-bold text-sm hover:bg-[#FAF5F0] active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-xs"
            >
              <Upload className="w-5 h-5 text-[#009E8F]" />
              <span>ব্যাকআপ থেকে ফিরিয়ে আনুন (Restore)</span>
            </button>

            <a
              href="/sujon-master-android.zip"
              download="sujon-master-android.zip"
              className="w-full py-3.5 rounded-[18px] bg-gradient-to-r from-[#009E8F] to-[#00C2D1] text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-md active:scale-[0.98] transition-all"
            >
              <Download className="w-5 h-5" />
              <span>📦 নেটিভ Android Studio প্রজেক্ট ডাউনলোড (ZIP)</span>
            </a>
          </div>

          <p className="text-[11px] text-[#7A6F68] mt-3 leading-relaxed">
            WebView অ্যাপের ব্যাকআপ এখানে আনা যাবে না; এই নেটিভ অ্যাপ সম্পূর্ণ নতুনভাবে শুরু হয়েছে।
          </p>
        </section>

        {/* Card 3: থিম ও ভাষা নির্বাচন */}
        <section className="bg-white rounded-[24px] border border-[#F0DDD2] p-5 shadow-xs space-y-4">
          <div>
            <h3 className="text-sm font-bold text-[#1D1A18] mb-2 flex items-center gap-2">
              <Palette className="w-4 h-4 text-[#009E8F]" />
              <span>কালার থিম</span>
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'sunset' as ThemeMode, name: 'Sunset', gradient: 'from-[#FF5A3C] to-[#FF3D8A]' },
                { id: 'ocean' as ThemeMode, name: 'Ocean', gradient: 'from-[#009E8F] to-[#00C2D1]' },
                { id: 'leaf' as ThemeMode, name: 'Leaf', gradient: 'from-[#16A34A] to-[#84CC16]' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTheme(item.id)}
                  className={`py-3 rounded-2xl flex flex-col items-center justify-center gap-1.5 border transition-all ${
                    theme === item.id
                      ? 'border-[#009E8F] ring-2 ring-[#009E8F]/20 bg-[#FAF5F0]'
                      : 'border-[#E9DACD] bg-white'
                  }`}
                >
                  <div className={`w-6 h-6 rounded-full bg-gradient-to-r ${item.gradient} shadow-xs`} />
                  <span className="text-xs font-bold text-[#1D1A18]">{item.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-[#F0DDD2]">
            <h3 className="text-sm font-bold text-[#1D1A18] mb-2 flex items-center gap-2">
              <Globe className="w-4 h-4 text-[#009E8F]" />
              <span>ভাষা (Language)</span>
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLanguage('bn')}
                className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                  language === 'bn'
                    ? 'bg-[#1D1A18] text-white border-[#1D1A18]'
                    : 'bg-white text-[#1D1A18] border-[#E9DACD]'
                }`}
              >
                বাংলা (Bengali)
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                  language === 'en'
                    ? 'bg-[#1D1A18] text-white border-[#1D1A18]'
                    : 'bg-white text-[#1D1A18] border-[#E9DACD]'
                }`}
              >
                English (Labels only)
              </button>
            </div>
          </div>

          <div className="pt-2 border-t border-[#F0DDD2]">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-bold text-[#1D1A18] block">টাকার পরিমাণ লুকান</span>
                <span className="text-[11px] text-[#7A6F68]">ব্যালেন্স ও দৈনিক হিসাব ৳ •••• দেখাবে</span>
              </div>
              <button
                type="button"
                onClick={toggleHideMoney}
                className={`w-14 h-8 rounded-full transition-colors p-1 relative flex items-center select-none ${
                  hideMoney ? 'bg-[#00B4B4]' : 'bg-[#D5C2B4]'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                    hideMoney ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Confirmation Modal: Backup Overwrite (Conflict Rule) */}
      {showBackupOverwriteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] max-w-sm w-full p-5 shadow-2xl border border-[#F0DDD2] animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-[#D97706] flex items-center justify-center mx-auto mb-3">
              <UploadCloud className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#1D1A18] text-center mb-1.5">
              ক্লাউডের পুরনো ব্যাকআপ মুছে যাবে, ঠিক আছে?
            </h3>
            <p className="text-xs text-[#7A6F68] text-center mb-5 leading-relaxed">
              আপনার গুগল ড্রাইভের বিদ্যমান ব্যাকআপটি বর্তমান ফোনের নতুন হিসাব দিয়ে প্রতিস্থাপিত হবে।
            </p>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => setShowBackupOverwriteConfirm(false)}
                className="flex-1 py-2.5 px-3 rounded-[14px] bg-[#F4EBE3] text-[#1D1A18] font-semibold text-xs hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={confirmBackupOverwrite}
                className="flex-1 py-2.5 px-3 rounded-[14px] bg-[#00B4B4] text-white font-semibold text-xs shadow-md hover:bg-[#009E9E] active:scale-[0.98] transition-all"
              >
                হ্যাঁ, ব্যাকআপ নিন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal: Restore from Cloud */}
      {showRestoreConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] max-w-sm w-full p-5 shadow-2xl border border-[#F0DDD2] animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-blue-100 text-[#2563EB] flex items-center justify-center mx-auto mb-3">
              <DownloadCloud className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#1D1A18] text-center mb-1.5">
              ক্লাউড থেকে হিসাব ফিরিয়ে আনতে চান?
            </h3>
            <div className="bg-[#FAF5F0] p-3 rounded-[16px] border border-[#E9DACD] my-3 text-xs text-[#1D1A18] space-y-1">
              <div className="flex justify-between">
                <span className="text-[#7A6F68]">ব্যাকআপের সময়:</span>
                <span className="font-bold">
                  {cloudMetadata
                    ? new Date(cloudMetadata.modifiedTime).toLocaleString('bn-BD', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })
                    : 'উপলব্ধ'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A6F68]">ফাইলের আকার:</span>
                <span className="font-bold">
                  {cloudMetadata ? `${Math.round(cloudMetadata.sizeBytes / 1024)} KB` : 'স্বাভাবিক'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A6F68]">লোকেশন:</span>
                <span className="font-bold">Drive (appDataFolder)</span>
              </div>
            </div>
            <p className="text-[11px] text-[#E5484D] text-center mb-5 leading-relaxed font-medium">
              সতর্কতা: এটি বর্তমান ফোনের হিসাব মুছে দিয়ে ক্লাউডের হিসাব দিয়ে প্রতিস্থাপন করবে।
            </p>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => setShowRestoreConfirm(false)}
                className="flex-1 py-2.5 px-3 rounded-[14px] bg-[#F4EBE3] text-[#1D1A18] font-semibold text-xs hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={confirmRestoreCloud}
                className="flex-1 py-2.5 px-3 rounded-[14px] bg-[#2563EB] text-white font-semibold text-xs shadow-md hover:bg-[#1D4ED8] active:scale-[0.98] transition-all"
              >
                হ্যাঁ, ফিরিয়ে আনুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
