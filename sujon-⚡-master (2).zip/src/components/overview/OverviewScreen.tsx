import React, { useState } from 'react';
import {
  Zap,
  Settings as SettingsIcon,
  Eye,
  EyeOff,
  Plus,
  Users,
  House,
  Tag,
  ArrowRight,
  CalendarDays,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatTaka, formatBengaliDate } from '../../utils/bengali';
import { NewEntryModal } from '../daily/NewEntryModal';
import { ThemeMode } from '../../types';

export const OverviewScreen: React.FC = () => {
  const {
    totalBalance,
    todayIncome,
    todayExpense,
    dailyEntries,
    theme,
    setTheme,
    language,
    setLanguage,
    hideMoney,
    toggleHideMoney,
    setScreen,
    themeStyles,
  } = useApp();

  const [showNewEntryModal, setShowNewEntryModal] = useState(false);

  // Latest 3 daily rows for recent transactions
  const recentEntries = dailyEntries.slice(0, 3);

  const toggleLanguage = () => {
    setLanguage(language === 'bn' ? 'en' : 'bn');
  };

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Overview Hero Header (Rule 4: ONLY on Overview!) */}
      <header
        className={`w-full ${themeStyles.heroGradient} text-white pt-6 pb-6 px-4 sm:px-5 rounded-b-[32px] shadow-lg`}
      >
        {/* Brand row */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center shadow-inner shrink-0">
              <Zap className="w-5 h-5 text-white fill-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-extrabold tracking-tight text-white whitespace-nowrap">
                SUJON ⚡ MASTER
              </h1>
              <p className="text-[11px] text-white/85 font-medium whitespace-nowrap truncate">
                Electric • Plumbing • Sanitary
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setScreen({ type: 'settings' })}
              aria-label="Settings"
              className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center hover:bg-white/30 active:scale-95 transition-all text-white"
            >
              <SettingsIcon className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={toggleLanguage}
              className="h-9 px-3 rounded-full bg-white/25 hover:bg-white/35 active:scale-95 transition-all text-white text-xs font-bold tracking-wide flex items-center justify-center backdrop-blur-xs"
            >
              {language === 'bn' ? 'English' : 'বাংলা'}
            </button>
          </div>
        </div>

        {/* Greeting & Date Info */}
        <div className="mt-2 mb-4">
          <h2 className="text-2xl sm:text-[26px] font-extrabold text-white tracking-tight">
            Assalamu Alaikum, Sujon
          </h2>
          <p className="text-xs sm:text-sm text-white/90 mt-1 font-medium">
            মঙ্গলবার, ৩ নভেম্বর ২০২৬ • Work at 3 sites today
          </p>
        </div>

        {/* Theme Pills */}
        <div className="flex items-center gap-2.5 pt-1">
          {[
            { id: 'sunset' as ThemeMode, name: 'Sunset', dot: 'bg-[#FF5A3C]' },
            { id: 'ocean' as ThemeMode, name: 'Ocean', dot: 'bg-[#009E8F]' },
            { id: 'leaf' as ThemeMode, name: 'Leaf', dot: 'bg-[#16A34A]' },
          ].map((item) => {
            const isActive = theme === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTheme(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-white text-[#1D1A18] shadow-md scale-105'
                    : 'bg-white/20 text-white hover:bg-white/30 border border-white/20'
                }`}
              >
                <span className={`w-2.5 h-2.5 rounded-full ${item.dot} shrink-0`} />
                <span>{item.name}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="px-4 sm:px-5 -mt-2 space-y-5">
        {/* Balance Card (#1D1A18 Dark Card, ~26dp radius) */}
        <div className="relative overflow-hidden bg-[#1D1A18] text-white rounded-[26px] p-5 shadow-xl border border-white/5">
          {/* Decorative subtle ambient circle */}
          <div className="absolute -top-10 -right-10 w-44 h-44 rounded-full bg-[#009E8F]/25 blur-2xl pointer-events-none" />

          <div className="flex items-start justify-between relative z-10">
            <div>
              <p className="text-xs sm:text-sm font-semibold text-white/70">
                {language === 'en' ? 'Total balance' : 'মোট ব্যালেন্স'}
              </p>
              <h3 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
                {formatTaka(totalBalance, hideMoney)}
              </h3>
            </div>
            <button
              type="button"
              onClick={toggleHideMoney}
              aria-label="Toggle amount visibility"
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 transition-all flex items-center justify-center text-white/90"
            >
              {hideMoney ? <EyeOff className="w-5 h-5 text-white/80" /> : <Eye className="w-5 h-5 text-white/80" />}
            </button>
          </div>

          {/* Mini sub-cards: Today's Income & Expense */}
          <div className="grid grid-cols-2 gap-3 mt-5 relative z-10">
            <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
              <p className="text-[11px] font-semibold text-white/70">
                {language === 'en' ? "Today's income" : 'আজকের আয়'}
              </p>
              <p className="text-lg sm:text-xl font-bold text-[#7DFFC4] mt-0.5">
                {formatTaka(todayIncome, hideMoney)}
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
              <p className="text-[11px] font-semibold text-white/70">
                {language === 'en' ? "Today's expense" : 'আজকের খরচ'}
              </p>
              <p className="text-lg sm:text-xl font-bold text-[#FFC9A8] mt-0.5">
                {formatTaka(todayExpense, hideMoney)}
              </p>
            </div>
          </div>
        </div>

        {/* Quick Actions (Exactly 4 cards wired to existing features) */}
        <section>
          <h4 className="text-base font-bold text-[#1D1A18] mb-3">
            {language === 'en' ? 'Quick actions' : 'কুইক অ্যাকশন'}
          </h4>
          <div className="grid grid-cols-4 gap-2.5">
            {/* 1. New Entry */}
            <button
              type="button"
              onClick={() => setShowNewEntryModal(true)}
              className="flex flex-col items-center justify-center p-2.5 bg-white rounded-[20px] border border-[#F0DDD2] shadow-xs hover:border-[#009E8F] active:scale-95 transition-all text-center"
            >
              <div className="w-11 h-11 rounded-2xl bg-[#E0F7F6] text-[#009E8F] flex items-center justify-center mb-1.5 shadow-xs">
                <Plus className="w-6 h-6 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold text-[#1D1A18] leading-tight">
                {language === 'en' ? 'New entry' : 'নতুন এন্ট্রি'}
              </span>
            </button>

            {/* 2. Attendance */}
            <button
              type="button"
              onClick={() => setScreen({ type: 'main', tab: 'team' })}
              className="flex flex-col items-center justify-center p-2.5 bg-white rounded-[20px] border border-[#F0DDD2] shadow-xs hover:border-[#009E8F] active:scale-95 transition-all text-center"
            >
              <div className="w-11 h-11 rounded-2xl bg-[#E0F7F6] text-[#009E8F] flex items-center justify-center mb-1.5 shadow-xs">
                <Users className="w-5 h-5 stroke-[2.2]" />
              </div>
              <span className="text-[11px] font-bold text-[#1D1A18] leading-tight">
                {language === 'en' ? 'Attendance' : 'হাজিরা'}
              </span>
            </button>

            {/* 3. Site accounts */}
            <button
              type="button"
              onClick={() => setScreen({ type: 'main', tab: 'sites' })}
              className="flex flex-col items-center justify-center p-2.5 bg-white rounded-[20px] border border-[#F0DDD2] shadow-xs hover:border-[#009E8F] active:scale-95 transition-all text-center"
            >
              <div className="w-11 h-11 rounded-2xl bg-[#E6F0FF] text-[#2563EB] flex items-center justify-center mb-1.5 shadow-xs">
                <House className="w-5 h-5 stroke-[2.2]" />
              </div>
              <span className="text-[11px] font-bold text-[#1D1A18] leading-tight">
                {language === 'en' ? 'Site accounts' : 'সাইট হিসাব'}
              </span>
            </button>

            {/* 4. Price list */}
            <button
              type="button"
              onClick={() => setScreen({ type: 'main', tab: 'prices' })}
              className="flex flex-col items-center justify-center p-2.5 bg-white rounded-[20px] border border-[#F0DDD2] shadow-xs hover:border-[#009E8F] active:scale-95 transition-all text-center"
            >
              <div className="w-11 h-11 rounded-2xl bg-[#E0F9FB] text-[#00A8B5] flex items-center justify-center mb-1.5 shadow-xs">
                <Tag className="w-5 h-5 stroke-[2.2]" />
              </div>
              <span className="text-[11px] font-bold text-[#1D1A18] leading-tight">
                {language === 'en' ? 'Price list' : 'প্রাইস লিস্ট'}
              </span>
            </button>
          </div>
        </section>

        {/* Recent Transactions Section */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-base font-bold text-[#1D1A18]">
              {language === 'en' ? 'Recent transactions' : 'সাম্প্রতিক লেনদেন'}
            </h4>
            <button
              type="button"
              onClick={() => setScreen({ type: 'main', tab: 'daily' })}
              className="text-xs font-bold text-[#009E8F] hover:underline flex items-center gap-1"
            >
              {language === 'en' ? 'See all' : 'সব দেখুন'}
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {recentEntries.length === 0 ? (
              <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-5 text-center text-[#7A6F68] text-sm">
                {language === 'en'
                  ? 'No transactions yet — add a new entry to get started.'
                  : 'এখনও কোনো লেনদেন নেই — নতুন এন্ট্রি যোগ করুন।'}
              </div>
            ) : (
              recentEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 flex items-center justify-between shadow-xs"
                >
                  <div className="min-w-0 pr-3">
                    <p className="text-sm font-bold text-[#1D1A18] truncate">{entry.details}</p>
                    <p className="text-xs text-[#7A6F68] mt-0.5">{formatBengaliDate(entry.date)}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span
                      className={`text-base font-extrabold ${
                        entry.type === 'income' ? 'text-[#0A9D6B]' : 'text-[#E5484D]'
                      }`}
                    >
                      {entry.type === 'income' ? '+ ' : '- '}
                      {formatTaka(entry.amount, hideMoney)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>

        {/* Monthly Hisab Card BELOW Recent (Rule 1) */}
        <section className="pt-1">
          <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-4.5 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-[#FFF1EB] text-[#FF5A3C] flex items-center justify-center shrink-0">
                <CalendarDays className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div>
                <h5 className="text-sm font-bold text-[#1D1A18]">
                  {language === 'en' ? 'Monthly Account Overview' : 'মাসিক হিসাব ও তালিকা'}
                </h5>
                <p className="text-xs text-[#7A6F68]">
                  {language === 'en' ? 'View month-by-month income, expense and net' : 'প্রতি মাসের মোট আয়, খরচ ও লাভ-ক্ষতি'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setScreen({ type: 'monthly-hisab' })}
              className={`w-full py-3 rounded-[16px] text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2 ${themeStyles.primaryBtn}`}
            >
              <span>{language === 'en' ? 'View Monthly Accounts' : 'মাসিক হিসাব দেখুন'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      </main>

      {/* New Entry Modal */}
      {showNewEntryModal && <NewEntryModal onClose={() => setShowNewEntryModal(false)} />}
    </div>
  );
};
