import React, { useState } from 'react';
import { Zap, Delete } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const LockScreen: React.FC = () => {
  const { unlockWithPin, themeStyles } = useApp();
  const [enteredPin, setEnteredPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isShaking, setIsShaking] = useState(false);

  const keys = [
    { label: '১', val: '1' },
    { label: '২', val: '2' },
    { label: '৩', val: '3' },
    { label: '৪', val: '4' },
    { label: '৫', val: '5' },
    { label: '৬', val: '6' },
    { label: '৭', val: '7' },
    { label: '৮', val: '8' },
    { label: '৯', val: '9' },
    { label: '', val: 'empty' },
    { label: '০', val: '0' },
    { label: 'del', val: 'backspace' },
  ];

  const handleKeyPress = (val: string) => {
    if (val === 'empty') return;
    if (val === 'backspace') {
      setEnteredPin((prev) => prev.slice(0, -1));
      setErrorMsg('');
      return;
    }

    if (enteredPin.length >= 4) return;

    const nextPin = enteredPin + val;
    setEnteredPin(nextPin);
    setErrorMsg('');

    if (nextPin.length === 4) {
      setTimeout(() => {
        const ok = unlockWithPin(nextPin);
        if (!ok) {
          setIsShaking(true);
          setErrorMsg('ভুল PIN! আবার চেষ্টা করুন');
          setTimeout(() => {
            setEnteredPin('');
            setIsShaking(false);
          }, 450);
        }
      }, 150);
    }
  };

  return (
    <div
      className={`fixed inset-0 z-50 ${themeStyles.heroGradient} flex flex-col justify-between items-center py-10 px-6 select-none animate-in fade-in duration-200`}
    >
      {/* Brand Header */}
      <div className="flex flex-col items-center mt-6 text-white text-center">
        <div className="w-16 h-16 rounded-3xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-lg mb-3">
          <Zap className="w-8 h-8 text-white fill-white" />
        </div>
        <h1 className="text-2xl font-extrabold tracking-tight">SUJON ⚡ MASTER</h1>
        <p className="text-xs text-white/80 font-medium mt-0.5">
          Electric • Plumbing • Sanitary
        </p>

        <h2 className="text-lg font-bold text-white mt-8 mb-4">
          ৪ সংখ্যার PIN দিন
        </h2>

        {/* 4 PIN Dots */}
        <div
          className={`flex items-center gap-4 transition-transform ${
            isShaking ? 'translate-x-[-12px] animate-pulse duration-75' : ''
          }`}
        >
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = idx < enteredPin.length;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  isFilled
                    ? 'bg-white scale-110 shadow-md ring-4 ring-white/30'
                    : 'bg-white/25 border border-white/40'
                }`}
              />
            );
          })}
        </div>

        {errorMsg && (
          <p className="text-xs font-bold text-white bg-red-600/60 px-3 py-1 rounded-full mt-4 backdrop-blur-xs">
            {errorMsg}
          </p>
        )}
      </div>

      {/* Numeric Keypad (Rule 9: Solid translucent pills, bold white Bengali digits) */}
      <div className="w-full max-w-xs grid grid-cols-3 gap-3.5 mb-6">
        {keys.map((k, idx) => {
          if (k.val === 'empty') {
            return <div key={idx} />;
          }

          if (k.val === 'backspace') {
            return (
              <button
                key={idx}
                type="button"
                onClick={() => handleKeyPress('backspace')}
                className="h-16 rounded-2xl bg-white/15 hover:bg-white/25 active:scale-95 transition-all flex items-center justify-center text-white backdrop-blur-xs"
              >
                <Delete className="w-6 h-6 stroke-[2.2]" />
              </button>
            );
          }

          return (
            <button
              key={idx}
              type="button"
              onClick={() => handleKeyPress(k.val)}
              className="h-16 rounded-2xl bg-white/20 hover:bg-white/30 active:scale-95 transition-all flex items-center justify-center text-white text-2xl font-extrabold backdrop-blur-xs shadow-xs"
            >
              {k.label}
            </button>
          );
        })}
      </div>

      {/* Privacy Notice (Rule 9: NO bypass button) */}
      <p className="text-[11px] text-white/70 text-center font-medium max-w-xs">
        নিরাপত্তার জন্য PIN লক চালু করা আছে।
      </p>
    </div>
  );
};
