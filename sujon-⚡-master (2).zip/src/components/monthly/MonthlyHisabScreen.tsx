import React, { useState, useMemo } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Eye, EyeOff } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  formatTaka,
  formatBengaliDate,
  getDayOfWeekBengali,
  BENGALI_MONTHS,
  toBengaliNumber,
} from '../../utils/bengali';
import { DailyEntry } from '../../types';

export const MonthlyHisabScreen: React.FC = () => {
  const { dailyEntries, hideMoney, toggleHideMoney, goBack, themeStyles } = useApp();

  const now = new Date();
  const [currentYear, setCurrentYear] = useState<number>(now.getFullYear());
  const [currentMonth, setCurrentMonth] = useState<number>(now.getMonth());

  const monthPrefix = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}`;

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  // Monthly daily entries
  const monthlyEntries = useMemo(() => {
    return dailyEntries
      .filter((e) => e.date.startsWith(monthPrefix))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [dailyEntries, monthPrefix]);

  // Monthly totals
  const { monthIncome, monthExpense, monthNet } = useMemo(() => {
    let inc = 0;
    let exp = 0;
    monthlyEntries.forEach((e) => {
      if (e.type === 'income') inc += e.amount;
      else exp += e.amount;
    });
    return { monthIncome: inc, monthExpense: exp, monthNet: inc - exp };
  }, [monthlyEntries]);

  // Group entries by date
  const groupedByDate = useMemo(() => {
    const map = new Map<string, DailyEntry[]>();
    monthlyEntries.forEach((entry) => {
      const list = map.get(entry.date) || [];
      list.push(entry);
      map.set(entry.date, list);
    });
    return Array.from(map.entries());
  }, [monthlyEntries]);

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Detail Header */}
      <header className={`w-full ${themeStyles.headerGradient} text-white pt-6 pb-6 px-4 sm:px-5 rounded-b-[28px] shadow-md`}>
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={goBack}
            className="flex items-center gap-1.5 text-white/95 hover:text-white font-bold text-sm active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
            <span>ওভারভিউতে ফিরুন</span>
          </button>

          <button
            type="button"
            onClick={toggleHideMoney}
            aria-label="Toggle money"
            className="w-9 h-9 rounded-full bg-black/20 hover:bg-black/30 flex items-center justify-center text-white"
          >
            {hideMoney ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>

        <h2 className="text-2xl font-extrabold text-white mt-3 tracking-tight">
          মাসিক আয়-ব্যয় হিসাব
        </h2>
        <p className="text-xs text-white/85 font-medium mt-0.5">
          সকল সাইট ও কাজের দৈনিক আয়-খরচের সারসংক্ষেপ
        </p>
      </header>

      {/* Main Container */}
      <main className="px-4 sm:px-5 mt-4 space-y-4">
        {/* Month Navigation */}
        <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3 flex items-center justify-between shadow-xs">
          <button
            type="button"
            onClick={handlePrevMonth}
            className="w-9 h-9 rounded-full bg-[#FAF5F0] hover:bg-[#F0E4D8] flex items-center justify-center text-[#1D1A18] active:scale-95 transition-all"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-base font-extrabold text-[#1D1A18]">
            {BENGALI_MONTHS[currentMonth]} {toBengaliNumber(currentYear)}
          </span>
          <button
            type="button"
            onClick={handleNextMonth}
            className="w-9 h-9 rounded-full bg-[#FAF5F0] hover:bg-[#F0E4D8] flex items-center justify-center text-[#1D1A18] active:scale-95 transition-all"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* 3 Monthly Stats */}
        <div className="grid grid-cols-3 gap-2.5">
          <div className="bg-white rounded-[20px] p-3 border border-[#F0DDD2] text-center shadow-xs">
            <span className="text-[11px] font-semibold text-[#7A6F68]">মোট আয়</span>
            <p className="text-sm sm:text-base font-extrabold text-[#0A9D6B] mt-1 truncate">
              {formatTaka(monthIncome, hideMoney)}
            </p>
          </div>
          <div className="bg-white rounded-[20px] p-3 border border-[#F0DDD2] text-center shadow-xs">
            <span className="text-[11px] font-semibold text-[#7A6F68]">মোট খরচ</span>
            <p className="text-sm sm:text-base font-extrabold text-[#E5484D] mt-1 truncate">
              {formatTaka(monthExpense, hideMoney)}
            </p>
          </div>
          <div className="bg-white rounded-[20px] p-3 border border-[#F0DDD2] text-center shadow-xs">
            <span className="text-[11px] font-semibold text-[#7A6F68]">নেট লাভ/জমা</span>
            <p className={`text-sm sm:text-base font-extrabold mt-1 truncate ${monthNet >= 0 ? 'text-[#1D1A18]' : 'text-[#E5484D]'}`}>
              {formatTaka(monthNet, hideMoney)}
            </p>
          </div>
        </div>

        {/* Day-by-Day Grouped List */}
        <div className="space-y-4 pt-1">
          {groupedByDate.length === 0 ? (
            <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-8 text-center text-[#7A6F68] text-sm">
              এই মাসে কোনো লেনদেন রেকর্ড করা হয়নি।
            </div>
          ) : (
            groupedByDate.map(([dateStr, entries]) => (
              <div key={dateStr} className="bg-white rounded-[22px] border border-[#F0DDD2] p-4 shadow-xs">
                {/* Date header */}
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#F0DDD2]">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-extrabold text-[#1D1A18]">
                      {formatBengaliDate(dateStr)}
                    </span>
                    <span className="text-xs font-semibold text-[#7A6F68]">
                      ({getDayOfWeekBengali(dateStr)})
                    </span>
                  </div>
                </div>

                <div className="divide-y divide-[#FAF0E6]">
                  {entries.map((entry) => (
                    <div key={entry.id} className="py-2.5 flex items-center justify-between text-xs sm:text-sm">
                      <span className="font-bold text-[#1D1A18] truncate pr-2">
                        {entry.details}
                      </span>
                      <span
                        className={`font-extrabold shrink-0 ${
                          entry.type === 'income' ? 'text-[#0A9D6B]' : 'text-[#E5484D]'
                        }`}
                      >
                        {entry.type === 'income' ? '+ ' : '- '}
                        {formatTaka(entry.amount, hideMoney)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
};
