import React, { useState, useMemo } from 'react';
import { Search, Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatTaka } from '../../utils/bengali';
import { PriceCategory } from '../../types';
import { AddPriceModal } from './AddPriceModal';
import { SwipeToDelete } from '../common/SwipeToDelete';

export const PricesScreen: React.FC = () => {
  const { prices, deletePriceItem, language } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | PriceCategory>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredPrices = useMemo(() => {
    return prices.filter((p) => {
      const matchCat = selectedCategory === 'all' || p.category === selectedCategory;
      const matchSearch =
        !searchQuery.trim() ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.unit.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [prices, selectedCategory, searchQuery]);

  const getBadgeCode = (cat: PriceCategory) => {
    if (cat === 'ইলেক্ট্রিক') return 'ELE';
    if (cat === 'প্লাম্বিং') return 'PLU';
    return 'SAN';
  };

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Top Header */}
      <header className="px-4 sm:px-5 pt-4 pb-2">
        <p className="text-xs text-[#7A6F68] font-medium mb-3">
          {language === 'en'
            ? 'Sample prices — check the real price at work time.'
            : 'নমুনা বাজার দর — কাজের সময়ে প্রকৃত দর যাচাই করে নিন।'}
        </p>

        {/* Search Bar (Screenshot 3) */}
        <div className="relative mb-3">
          <div className="absolute inset-y-0 left-3.5 flex items-center pointer-events-none text-[#7A6F68]">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="খুঁজুন: কেবল, পাইপ, সুইচ..."
            className="w-full pl-10 pr-4 py-3 rounded-[20px] bg-white border border-[#F0DDD2] text-sm text-[#1D1A18] placeholder-[#7A6F68] focus:outline-hidden focus:border-[#009E8F] shadow-xs"
          />
        </div>

        {/* Category Pills (Screenshot 3) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {[
            { id: 'all' as const, label: 'সব' },
            { id: 'ইলেক্ট্রিক' as PriceCategory, label: 'ইলেক্ট্রিক' },
            { id: 'প্লাম্বিং' as PriceCategory, label: 'প্লাম্বিং' },
            { id: 'স্যানিটারি' as PriceCategory, label: 'স্যানিটারি' },
          ].map((pill) => {
            const isActive = selectedCategory === pill.id;
            return (
              <button
                key={pill.id}
                type="button"
                onClick={() => setSelectedCategory(pill.id)}
                className={`px-4 py-2 rounded-full text-xs font-bold shrink-0 transition-all ${
                  isActive
                    ? 'bg-[#1D1A18] text-white shadow-xs'
                    : 'bg-white text-[#1D1A18] border border-[#F0DDD2] hover:bg-[#FAF4EE]'
                }`}
              >
                {pill.label}
              </button>
            );
          })}
        </div>

        {/* + নতুন পণ্য যোগ করুন (Screenshot 3) */}
        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="w-full py-3.5 mt-3 rounded-[20px] bg-white border border-[#F0DDD2] hover:border-[#009E8F] text-[#1D1A18] font-extrabold text-sm flex items-center justify-center gap-2 shadow-xs active:scale-[0.99] transition-all"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>+ নতুন পণ্য যোগ করুন</span>
        </button>
      </header>

      {/* Product Rows List */}
      <main className="px-4 sm:px-5 mt-2 space-y-2">
        {filteredPrices.length === 0 ? (
          <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-8 text-center text-[#7A6F68] text-sm my-4">
            কোনো পণ্য পাওয়া যায়নি।
          </div>
        ) : (
          filteredPrices.map((item) => (
            <SwipeToDelete
              key={item.id}
              onDelete={() => deletePriceItem(item.id)}
              confirmTitle="পণ্য মুছে ফেলতে চান?"
              confirmMessage={`"${item.name}" প্রাইস তালিকা থেকে মুছে ফেলা হবে।`}
            >
              <div className="p-4 bg-white rounded-[22px] border border-[#F0DDD2] flex items-center justify-between shadow-xs">
                <div className="flex items-center gap-3 min-w-0 pr-2">
                  <div className="w-11 h-11 rounded-2xl bg-[#009E8F] text-white flex items-center justify-center font-extrabold text-xs shrink-0 shadow-xs">
                    {getBadgeCode(item.category)}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm sm:text-base font-extrabold text-[#1D1A18] leading-tight truncate">
                      {item.name}
                    </h3>
                    <p className="text-xs text-[#7A6F68] mt-0.5 font-medium">
                      {item.unit}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-base sm:text-lg font-extrabold text-[#1D1A18]">
                    {formatTaka(item.price)}
                  </span>
                </div>
              </div>
            </SwipeToDelete>
          ))
        )}
      </main>

      {/* Add Price Modal */}
      {showAddModal && <AddPriceModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
};
