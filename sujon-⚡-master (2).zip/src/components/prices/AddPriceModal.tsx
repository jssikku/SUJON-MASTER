import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { toEnglishNumber } from '../../utils/bengali';
import { PriceCategory } from '../../types';

interface AddPriceModalProps {
  onClose: () => void;
}

export const AddPriceModal: React.FC<AddPriceModalProps> = ({ onClose }) => {
  const { addPriceItem, themeStyles } = useApp();
  const [name, setName] = useState('');
  const [category, setCategory] = useState<PriceCategory>('ইলেক্ট্রিক');
  const [unit, setUnit] = useState('প্রতি পিস');
  const [priceStr, setPriceStr] = useState('');
  const [error, setError] = useState('');

  const commonUnits = ['প্রতি পিস', 'প্রতি কয়েল', 'প্রতি সেট', 'প্রতি ফুট', 'প্রতি মিটার'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      setError('পণ্যের নাম লিখুন');
      return;
    }
    const price = parseFloat(toEnglishNumber(priceStr.trim()));
    if (isNaN(price) || price < 0) {
      setError('সঠিক দামের অঙ্ক লিখুন');
      return;
    }

    const res = addPriceItem(cleanName, category, unit, price);
    if (!res.success) {
      setError(res.message || 'ত্রুটি ঘটেছে');
      return;
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[28px] sm:rounded-[28px] p-5 pb-8 sm:pb-6 shadow-2xl border border-[#F0DDD2] animate-in slide-in-from-bottom duration-200">
        <div className="w-12 h-1.5 bg-[#E6DACF] rounded-full mx-auto mb-3" />

        <h3 className="text-xl font-bold text-[#1D1A18] mb-4">
          + নতুন পণ্য যোগ করুন
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              পণ্যের নাম
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              placeholder="যেমন: কেবল ২.৫ মিমি"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              ক্যাটাগরি
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as PriceCategory)}
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            >
              <option value="ইলেক্ট্রিক">ইলেক্ট্রিক</option>
              <option value="প্লাম্বিং">প্লাম্বিং</option>
              <option value="স্যানিটারি">স্যানিটারি</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              একক / ইউনিট
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {commonUnits.map((u) => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setUnit(u)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                    unit === u
                      ? 'bg-[#1D1A18] text-white shadow-xs'
                      : 'bg-[#FBF5F0] text-[#7A6F68] border border-[#E9DACD]'
                  }`}
                >
                  {u}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="w-full px-4 py-2.5 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-xs font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              দাম (৳)
            </label>
            <input
              type="text"
              inputMode="numeric"
              value={priceStr}
              onChange={(e) => {
                setPriceStr(e.target.value);
                if (error) setError('');
              }}
              placeholder="যেমন: ৩২০০"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-base font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          {error && <p className="text-xs font-bold text-[#E5484D]">{error}</p>}

          <div className="flex gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-[16px] bg-[#F4EBE3] text-[#1D1A18] font-bold text-sm hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className={`flex-1 py-3 px-4 rounded-[16px] text-white font-bold text-sm shadow-md active:scale-[0.98] transition-all ${themeStyles.primaryBtn}`}
            >
              পণ্য যোগ করুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
