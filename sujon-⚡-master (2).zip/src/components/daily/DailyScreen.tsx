import React, { useState, useMemo } from 'react';
import { Eye, EyeOff, Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  formatTaka,
  formatFullBengaliDateWithDay,
  formatBengaliDate,
  getTodayDateString,
} from '../../utils/bengali';
import { SwipeToDelete } from '../common/SwipeToDelete';
import { NewEntryModal } from './NewEntryModal';

export const DailyScreen: React.FC = () => {
  const {
    dailyEntries,
    deleteDailyEntry,
    todayIncome,
    todayExpense,
    hideMoney,
    toggleHideMoney,
    language,
    themeStyles,
  } = useApp();

  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const todayStr = getTodayDateString();
  const todayNet = todayIncome - todayExpense;

  // Filtered daily entries sorted by date descending, then createdAt descending
  const filteredEntries = useMemo(() => {
    let list = [...dailyEntries];
    if (filterType !== 'all') {
      list = list.filter((e) => e.type === filterType);
    }
    return list.sort((a, b) => {
      const dateCmp = b.date.localeCompare(a.date);
      if (dateCmp !== 0) return dateCmp;
      return b.createdAt - a.createdAt;
    });
  }, [dailyEntries, filterType]);

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Top Header */}
      <header className="px-4 sm:px-5 pt-5 pb-3">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-[#1D1A18] tracking-tight">
              {language === 'en' ? 'Daily accounts' : 'দৈনিক হিসাব'}
            </h2>
            <p className="text-xs font-semibold text-[#7A6F68] mt-1">
              {formatFullBengaliDateWithDay(todayStr)}
            </p>
          </div>
          <button
            type="button"
            onClick={toggleHideMoney}
            aria-label="Toggle amount visibility"
            className="w-10 h-10 rounded-full bg-white border border-[#F0DDD2] hover:border-[#009E8F] flex items-center justify-center text-[#1D1A18] shadow-xs active:scale-95 transition-all"
          >
            {hideMoney ? <EyeOff className="w-5 h-5 text-[#7A6F68]" /> : <Eye className="w-5 h-5 text-[#1D1A18]" />}
          </button>
        </div>

        {/* 3 Summary Cards: Income, Expense, In Hand */}
        <div className="grid grid-cols-3 gap-2.5 mt-4">
          <div className="bg-white rounded-[20px] p-3 border border-[#F0DDD2] text-center shadow-xs">
            <p className="text-[11px] font-semibold text-[#7A6F68]">
              {language === 'en' ? 'Income' : 'আজকের আয়'}
            </p>
            <p className="text-sm sm:text-base font-extrabold text-[#0A9D6B] mt-1 truncate">
              {formatTaka(todayIncome, hideMoney)}
            </p>
          </div>
          <div className="bg-white rounded-[20px] p-3 border border-[#F0DDD2] text-center shadow-xs">
            <p className="text-[11px] font-semibold text-[#7A6F68]">
              {language === 'en' ? 'Expense' : 'আজকের খরচ'}
            </p>
            <p className="text-sm sm:text-base font-extrabold text-[#E5484D] mt-1 truncate">
              {formatTaka(todayExpense, hideMoney)}
            </p>
          </div>
          <div className="bg-white rounded-[20px] p-3 border border-[#F0DDD2] text-center shadow-xs">
            <p className="text-[11px] font-semibold text-[#7A6F68]">
              {language === 'en' ? 'In hand' : 'হাতে জমা'}
            </p>
            <p className="text-sm sm:text-base font-extrabold text-[#1D1A18] mt-1 truncate">
              {formatTaka(todayNet, hideMoney)}
            </p>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 mt-4">
          {[
            { id: 'all' as const, labelBn: 'সব', labelEn: 'All' },
            { id: 'income' as const, labelBn: 'আয়', labelEn: 'Income' },
            { id: 'expense' as const, labelBn: 'খরচ', labelEn: 'Expense' },
          ].map((chip) => {
            const isActive = filterType === chip.id;
            const label = language === 'en' ? chip.labelEn : chip.labelBn;
            return (
              <button
                key={chip.id}
                type="button"
                onClick={() => setFilterType(chip.id)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-[#1D1A18] text-white shadow-xs'
                    : 'bg-white text-[#1D1A18] border border-[#F0DDD2] hover:bg-[#FAF4EE]'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* + New Entry Button */}
        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className={`w-full py-3.5 mt-4 rounded-[18px] text-white font-extrabold text-sm flex items-center justify-center gap-2 ${themeStyles.primaryBtn}`}
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>{language === 'en' ? '+ New entry' : '+ নতুন এন্ট্রি'}</span>
        </button>
      </header>

      {/* Transaction List */}
      <main className="px-4 sm:px-5 mt-2">
        {filteredEntries.length === 0 ? (
          <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-8 text-center text-[#7A6F68] text-sm my-4">
            {language === 'en' ? 'No entries found in this list' : 'এই তালিকায় কোনো হিসাব পাওয়া যায়নি'}
          </div>
        ) : (
          <div className="space-y-1">
            {filteredEntries.map((entry) => (
              <SwipeToDelete
                key={entry.id}
                onDelete={() => deleteDailyEntry(entry.id)}
                confirmTitle="এন্ট্রি মুছে ফেলতে চান?"
                confirmMessage={`"${entry.details}" হিসাবটি মুছে ফেলা হবে।`}
              >
                <div className="p-4 flex items-center justify-between border border-[#F0DDD2] rounded-[20px] shadow-xs hover:border-[#E2D0C5] transition-colors">
                  <div className="min-w-0 pr-3">
                    <p className="text-sm sm:text-base font-bold text-[#1D1A18] truncate">
                      {entry.details}
                    </p>
                    <p className="text-xs text-[#7A6F68] mt-0.5">
                      {formatBengaliDate(entry.date)}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span
                      className={`text-base sm:text-lg font-extrabold ${
                        entry.type === 'income' ? 'text-[#0A9D6B]' : 'text-[#E5484D]'
                      }`}
                    >
                      {entry.type === 'income' ? '+ ' : '- '}
                      {formatTaka(entry.amount, hideMoney)}
                    </span>
                  </div>
                </div>
              </SwipeToDelete>
            ))}
          </div>
        )}
      </main>

      {showAddModal && <NewEntryModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
};
