import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getTodayDateString, toEnglishNumber } from '../../utils/bengali';

interface NewEntryModalProps {
  onClose: () => void;
}

export const NewEntryModal: React.FC<NewEntryModalProps> = ({ onClose }) => {
  const { addDailyEntry, language, themeStyles } = useApp();

  const [type, setType] = useState<'income' | 'expense'>('income');
  const [details, setDetails] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [date, setDate] = useState(getTodayDateString());
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rawNumber = parseFloat(toEnglishNumber(amountStr.trim()));
    if (isNaN(rawNumber) || rawNumber <= 0) {
      setError('সঠিক টাকার অঙ্ক লিখুন');
      return;
    }
    const cleanDetails = details.trim() || (type === 'income' ? 'নগদ আয়' : 'নগদ খরচ');

    addDailyEntry({
      type,
      details: cleanDetails,
      amount: rawNumber,
      date: date || getTodayDateString(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[28px] sm:rounded-[28px] p-5 pb-8 sm:pb-6 shadow-2xl border border-[#F0DDD2] animate-in slide-in-from-bottom duration-200">
        {/* Grab bar */}
        <div className="w-12 h-1.5 bg-[#E6DACF] rounded-full mx-auto mb-3" />

        <h3 className="text-xl font-bold text-[#1D1A18]">
          {language === 'en' ? 'New entry' : 'নতুন এন্ট্রি'}
        </h3>
        <p className="text-xs text-[#7A6F68] mt-1 mb-4">
          বেছে নেওয়া তারিখের হিসাবে যোগ হবে এবং সংরক্ষিত থাকবে।
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Income / Expense Toggle Pills */}
          <div className="grid grid-cols-2 gap-2.5 p-1 bg-[#FBF5F0] rounded-[18px] border border-[#F0DDD2]">
            <button
              type="button"
              onClick={() => setType('income')}
              className={`py-3 rounded-[15px] font-bold text-sm transition-all ${
                type === 'income'
                  ? 'bg-white text-[#0A9D6B] shadow-sm'
                  : 'text-[#7A6F68] hover:text-[#1D1A18]'
              }`}
            >
              + আয়
            </button>
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`py-3 rounded-[15px] font-bold text-sm transition-all ${
                type === 'expense'
                  ? 'bg-white text-[#E5484D] shadow-sm'
                  : 'text-[#7A6F68] hover:text-[#1D1A18]'
              }`}
            >
              – খরচ
            </button>
          </div>

          {/* Details Input */}
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              বিবরণ
            </label>
            <input
              type="text"
              value={details}
              onChange={(e) => {
                setDetails(e.target.value);
                if (error) setError('');
              }}
              placeholder={type === 'income' ? 'যেমন: সাইট পেমেন্ট / ফ্যান ফিটিং' : 'যেমন: তার ও সুইচ ক্রয় / গাড়ি ভাড়া'}
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          {/* Amount Input */}
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              টাকা (৳)
            </label>
            <input
              type="text"
              inputMode="numeric"
              value={amountStr}
              onChange={(e) => {
                setAmountStr(e.target.value);
                if (error) setError('');
              }}
              placeholder="যেমন: ৮০০০"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-base font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              তারিখ
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          {error && <p className="text-xs font-bold text-[#E5484D]">{error}</p>}

          {/* Action Buttons */}
          <div className="flex gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-[16px] bg-[#F4EBE3] text-[#1D1A18] font-bold text-sm hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className={`flex-1 py-3 px-4 rounded-[16px] text-white font-bold text-sm shadow-md active:scale-[0.98] transition-all ${
                type === 'income'
                  ? 'bg-gradient-to-r from-[#0A9D6B] to-[#10B981]'
                  : 'bg-gradient-to-r from-[#FF5A3C] to-[#E5484D]'
              }`}
            >
              যোগ করুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
