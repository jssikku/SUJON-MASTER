import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowLeft,
  Move,
  Pencil,
  Minus,
  Type,
  Dot,
  Eraser,
  Undo2,
  Redo2,
  Save,
  Download,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface PhotoEditorProps {
  noteId: string;
}

type ToolMode = 'move' | 'draw' | 'line' | 'text' | 'point' | 'erase';

interface DrawingAction {
  tool: ToolMode;
  color: string;
  size: number;
  points?: { x: number; y: number }[];
  startPoint?: { x: number; y: number };
  endPoint?: { x: number; y: number };
  text?: string;
  textPos?: { x: number; y: number };
  fontSize?: number;
}

export const PhotoEditor: React.FC<PhotoEditorProps> = ({ noteId }) => {
  const { notes, updateNotePhoto, goBack } = useApp();
  const note = notes.find((n) => n.id === noteId);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [activeTool, setActiveTool] = useState<ToolMode>('draw');
  const [activeColor, setActiveColor] = useState<string>('#E5484D');
  const [brushSize, setBrushSize] = useState<number>(4);

  // Text tool panel state
  const [showTextPanel, setShowTextPanel] = useState<boolean>(false);
  const [textContent, setTextContent] = useState<string>('');
  const [textFontSize, setTextFontSize] = useState<number>(36);

  // Undo / Redo history
  const [actions, setActions] = useState<DrawingAction[]>([]);
  const [redoList, setRedoList] = useState<DrawingAction[]>([]);

  // Current drawing state
  const isInteractingRef = useRef<boolean>(false);
  const currentActionRef = useRef<DrawingAction | null>(null);
  const imageObjRef = useRef<HTMLImageElement | null>(null);

  // Pan / Zoom for 'move' mode
  const [scale, setScale] = useState<number>(1);
  const [offset, setOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const panStartRef = useRef<{ x: number; y: number } | null>(null);

  const colors = [
    '#E5484D', // Red (electric)
    '#009E8F', // Teal
    '#2563EB', // Blue
    '#FFB020', // Yellow
    '#FFFFFF', // White
    '#1D1A18', // Black
  ];

  // Load image onto canvas
  useEffect(() => {
    if (!note?.photoUrl) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = note.photoUrl;
    img.onload = () => {
      imageObjRef.current = img;
      redrawAll();
    };
  }, [note?.photoUrl]);

  // Redraw full canvas with image and all actions
  const redrawAll = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = imageObjRef.current;
    if (img) {
      if (canvas.width !== img.naturalWidth || canvas.height !== img.naturalHeight) {
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
      }
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    } else {
      if (canvas.width === 0) {
        canvas.width = 800;
        canvas.height = 600;
      }
      ctx.fillStyle = '#FAF5F0';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    // Render actions
    actions.forEach((action) => {
      renderAction(ctx, action);
    });

    // Render current active action in progress
    if (currentActionRef.current) {
      renderAction(ctx, currentActionRef.current);
    }
  };

  useEffect(() => {
    redrawAll();
  }, [actions]);

  const renderAction = (ctx: CanvasRenderingContext2D, action: DrawingAction) => {
    ctx.save();
    if (action.tool === 'erase') {
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = action.size * 3;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    } else {
      ctx.strokeStyle = action.color;
      ctx.fillStyle = action.color;
      ctx.lineWidth = action.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }

    if (action.tool === 'draw' || action.tool === 'erase') {
      if (action.points && action.points.length > 0) {
        ctx.beginPath();
        ctx.moveTo(action.points[0].x, action.points[0].y);
        for (let i = 1; i < action.points.length; i++) {
          ctx.lineTo(action.points[i].x, action.points[i].y);
        }
        ctx.stroke();
      }
    } else if (action.tool === 'line') {
      // Snapped straight line ONLY (Rule 6: NO measurement/boxes)
      if (action.startPoint && action.endPoint) {
        ctx.beginPath();
        ctx.moveTo(action.startPoint.x, action.startPoint.y);
        ctx.lineTo(action.endPoint.x, action.endPoint.y);
        ctx.stroke();
      }
    } else if (action.tool === 'point') {
      if (action.startPoint) {
        ctx.beginPath();
        ctx.arc(action.startPoint.x, action.startPoint.y, action.size * 2, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (action.tool === 'text') {
      if (action.text && action.textPos) {
        ctx.font = `bold ${action.fontSize ?? 36}px "Hind Siliguri", "Plus Jakarta Sans", sans-serif`;
        // Draw background pill for high contrast readability on dark/light photos
        ctx.shadowColor = 'rgba(0,0,0,0.4)';
        ctx.shadowBlur = 4;
        ctx.fillText(action.text, action.textPos.x, action.textPos.y);
      }
    }
    ctx.restore();
  };

  // Convert client coordinates to canvas pixel coordinates
  const getCanvasCoords = (clientX: number, clientY: number): { x: number; y: number } | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  };

  const handlePointerDown = (clientX: number, clientY: number) => {
    if (activeTool === 'move') {
      panStartRef.current = { x: clientX - offset.x, y: clientY - offset.y };
      return;
    }

    const coords = getCanvasCoords(clientX, clientY);
    if (!coords) return;

    isInteractingRef.current = true;

    if (activeTool === 'text') {
      // If user clicks on canvas while text tool is active and we have text ready:
      if (textContent.trim()) {
        const newAction: DrawingAction = {
          tool: 'text',
          color: activeColor,
          size: brushSize,
          text: textContent.trim(),
          textPos: coords,
          fontSize: textFontSize,
        };
        setActions((prev) => [...prev, newAction]);
        setRedoList([]);
        // Rule 6: After text is placed, the text panel MUST CLOSE and must NOT reopen on image touch!
        setShowTextPanel(false);
        setTextContent('');
        setActiveTool('move'); // Switch back to neutral
      } else {
        // Open text panel to type text
        setShowTextPanel(true);
      }
      isInteractingRef.current = false;
      return;
    }

    if (activeTool === 'draw' || activeTool === 'erase') {
      currentActionRef.current = {
        tool: activeTool,
        color: activeColor,
        size: brushSize,
        points: [coords],
      };
    } else if (activeTool === 'line') {
      currentActionRef.current = {
        tool: 'line',
        color: activeColor,
        size: brushSize,
        startPoint: coords,
        endPoint: coords,
      };
    } else if (activeTool === 'point') {
      const newAction: DrawingAction = {
        tool: 'point',
        color: activeColor,
        size: brushSize,
        startPoint: coords,
      };
      setActions((prev) => [...prev, newAction]);
      setRedoList([]);
      isInteractingRef.current = false;
    }
  };

  const handlePointerMove = (clientX: number, clientY: number) => {
    if (activeTool === 'move' && panStartRef.current) {
      setOffset({
        x: clientX - panStartRef.current.x,
        y: clientY - panStartRef.current.y,
      });
      return;
    }

    if (!isInteractingRef.current || !currentActionRef.current) return;
    const coords = getCanvasCoords(clientX, clientY);
    if (!coords) return;

    if (activeTool === 'draw' || activeTool === 'erase') {
      currentActionRef.current.points?.push(coords);
      redrawAll();
    } else if (activeTool === 'line') {
      currentActionRef.current.endPoint = coords;
      redrawAll();
    }
  };

  const handlePointerUp = () => {
    if (activeTool === 'move') {
      panStartRef.current = null;
      return;
    }

    if (isInteractingRef.current && currentActionRef.current) {
      setActions((prev) => [...prev, currentActionRef.current!]);
      setRedoList([]);
      currentActionRef.current = null;
      redrawAll();
    }
    isInteractingRef.current = false;
  };

  const handleUndo = () => {
    if (actions.length === 0) return;
    const last = actions[actions.length - 1];
    setActions((prev) => prev.slice(0, prev.length - 1));
    setRedoList((prev) => [last, ...prev]);
  };

  const handleRedo = () => {
    if (redoList.length === 0) return;
    const next = redoList[0];
    setRedoList((prev) => prev.slice(1));
    setActions((prev) => [...prev, next]);
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas || !note) return;
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    updateNotePhoto(note.id, dataUrl);
    goBack();
  };

  const handleDownloadPng = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `SujonMaster_Note_${note?.title || 'Photo'}.jpg`;
    link.href = canvas.toDataURL('image/jpeg', 0.95);
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#1D1A18] text-white flex flex-col select-none overflow-hidden animate-in fade-in duration-200">
      {/* Top Header */}
      <header className="h-14 px-4 bg-[#141211] border-b border-white/10 flex items-center justify-between shrink-0">
        <button
          type="button"
          onClick={goBack}
          className="flex items-center gap-1.5 text-white/90 hover:text-white font-bold text-xs active:scale-95 transition-all"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>নোট বিবরণীতে ফিরুন</span>
        </button>

        <span className="text-sm font-bold text-white truncate max-w-[160px]">
          {note?.title || 'ফটো এডিটর'}
        </span>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleUndo}
            disabled={actions.length === 0}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-30 flex items-center justify-center text-white"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleRedo}
            disabled={redoList.length === 0}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-30 flex items-center justify-center text-white"
          >
            <Redo2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Photo Canvas Area (Rule 6: FULL view, tools strictly below, never covered) */}
      <div
        ref={containerRef}
        className="flex-1 relative overflow-hidden flex items-center justify-center bg-[#111] touch-none p-2"
        onTouchStart={(e) => handlePointerDown(e.touches[0].clientX, e.touches[0].clientY)}
        onTouchMove={(e) => handlePointerMove(e.touches[0].clientX, e.touches[0].clientY)}
        onTouchEnd={handlePointerUp}
        onMouseDown={(e) => handlePointerDown(e.clientX, e.clientY)}
        onMouseMove={(e) => handlePointerMove(e.clientX, e.clientY)}
        onMouseUp={handlePointerUp}
      >
        <div
          style={{
            transform: `translate(${offset.x}px, ${offset.y}px) scale(${scale})`,
            transformOrigin: 'center center',
            transition: panStartRef.current ? 'none' : 'transform 0.05s ease-out',
          }}
          className="relative max-h-full max-w-full flex items-center justify-center"
        >
          <canvas
            ref={canvasRef}
            className="max-h-[58vh] max-w-[95vw] object-contain rounded-lg shadow-2xl bg-[#222]"
          />
        </div>
      </div>

      {/* Editing Controls - Strictly BELOW the photo (Rule 6) */}
      <div className="bg-[#181615] border-t border-white/10 p-3 shrink-0 space-y-2.5">
        {/* Color Palette + Brush Size */}
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            {colors.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setActiveColor(c)}
                style={{ backgroundColor: c }}
                className={`w-6 h-6 rounded-full border-2 transition-all ${
                  activeColor === c ? 'border-white scale-125 shadow-md' : 'border-transparent opacity-80'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-white/70">আকার:</span>
            {[2, 4, 8, 14].map((size) => (
              <button
                key={size}
                type="button"
                onClick={() => setBrushSize(size)}
                className={`w-6 h-6 rounded-lg text-[11px] font-bold flex items-center justify-center transition-all ${
                  brushSize === size ? 'bg-white text-black' : 'bg-white/10 text-white/80'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* Tool Bar: Move, Draw, Straight Line ONLY, Text, Point, Erase */}
        <div className="grid grid-cols-6 gap-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveTool('move');
              setShowTextPanel(false);
            }}
            className={`py-2 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-all ${
              activeTool === 'move' ? 'bg-[#009E8F] text-white shadow-xs' : 'bg-white/10 text-white/80'
            }`}
          >
            <Move className="w-4 h-4" />
            <span>মুভ</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTool('draw');
              setShowTextPanel(false);
            }}
            className={`py-2 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-all ${
              activeTool === 'draw' ? 'bg-[#009E8F] text-white shadow-xs' : 'bg-white/10 text-white/80'
            }`}
          >
            <Pencil className="w-4 h-4" />
            <span>আঁকা</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTool('line');
              setShowTextPanel(false);
            }}
            className={`py-2 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-all ${
              activeTool === 'line' ? 'bg-[#009E8F] text-white shadow-xs' : 'bg-white/10 text-white/80'
            }`}
          >
            <Minus className="w-4 h-4 stroke-[3]" />
            <span>লাইন</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTool('text');
              setShowTextPanel(true);
            }}
            className={`py-2 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-all ${
              activeTool === 'text' ? 'bg-[#009E8F] text-white shadow-xs' : 'bg-white/10 text-white/80'
            }`}
          >
            <Type className="w-4 h-4" />
            <span>লেখা</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTool('point');
              setShowTextPanel(false);
            }}
            className={`py-2 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-all ${
              activeTool === 'point' ? 'bg-[#009E8F] text-white shadow-xs' : 'bg-white/10 text-white/80'
            }`}
          >
            <Dot className="w-5 h-5" />
            <span>পয়েন্ট</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTool('erase');
              setShowTextPanel(false);
            }}
            className={`py-2 rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-all ${
              activeTool === 'erase' ? 'bg-[#E5484D] text-white shadow-xs' : 'bg-white/10 text-white/80'
            }`}
          >
            <Eraser className="w-4 h-4" />
            <span>ইরেজ</span>
          </button>
        </div>

        {/* Text tool entry panel - Closes upon placement (Rule 6) */}
        {showTextPanel && (
          <div className="p-3 bg-[#242120] rounded-xl border border-white/15 space-y-2 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">লেখা যোগ করুন (মাপ বা নোট)</span>
              <button
                type="button"
                onClick={() => setShowTextPanel(false)}
                className="text-white/60 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <input
              type="text"
              autoFocus
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              placeholder="যেমন: 12 ft, Board-1, 2.5mm"
              className="w-full px-3 py-2 rounded-lg bg-black/40 border border-white/20 text-sm text-white focus:outline-hidden focus:border-[#009E8F]"
            />
            <div className="flex items-center justify-between text-xs text-white/70">
              <span>ফন্ট সাইজ: {textFontSize}px</span>
              <input
                type="range"
                min="18"
                max="220"
                value={textFontSize}
                onChange={(e) => setTextFontSize(parseInt(e.target.value, 10))}
                className="w-36 accent-[#009E8F]"
              />
            </div>
            <p className="text-[10px] text-[#00C2D1]">
              লেখা টাইপ করে ছবির উপর যে স্থানে বসাতে চান সেখানে চাপুন।
            </p>
          </div>
        )}

        {/* Bottom Save & Download Footer */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            type="button"
            onClick={handleDownloadPng}
            className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>ডাউনলোড</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="py-2.5 px-3 rounded-xl bg-[#00B4B4] hover:bg-[#009E9E] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>নোটে সংরক্ষণ করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
