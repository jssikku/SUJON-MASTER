import React, { useState, useRef } from 'react';
import { Folder, Image as ImageIcon, X, Edit3, Trash2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { NoteItem } from '../../types';
import { SwipeToDelete } from '../common/SwipeToDelete';

export const NotesScreen: React.FC = () => {
  const { notes, addNote, deleteNote, setScreen, language } = useApp();

  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [photoUrl, setPhotoUrl] = useState<string | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Selected note for viewing in full detail sheet
  const [activeNote, setActiveNote] = useState<NoteItem | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setPhotoUrl(result);
    };
    reader.readAsDataURL(file);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() && !title.trim() && !photoUrl) return;

    addNote(title, text, photoUrl);
    setTitle('');
    setText('');
    setPhotoUrl(undefined);
  };

  const handleOpenPhotoEditor = (noteId: string) => {
    setActiveNote(null);
    setScreen({ type: 'photo-editor', noteId });
  };

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Top Header */}
      <header className="px-4 sm:px-5 pt-5 pb-3">
        <h2 className="text-2xl font-extrabold text-[#1D1A18] tracking-tight">
          {language === 'en' ? 'Notes' : 'নোট'}
        </h2>
        <p className="text-xs font-semibold text-[#7A6F68] mt-1">
          {language === 'en'
            ? 'Work notes, measurements and reminders — keep them here.'
            : 'কাজের হিসাব, সাইটের মাপ ও জরুরি তথ্য লিখে রাখুন।'}
        </p>
      </header>

      {/* Add Note Form (Screenshot 4) */}
      <div className="px-4 sm:px-5">
        <div className="bg-white rounded-[24px] border border-[#F0DDD2] p-5 shadow-xs">
          <form onSubmit={handleAddNote} className="space-y-4">
            {/* Note Name */}
            <div>
              <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
                নোটের নাম
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="যেমন: সাইটের মাপ"
                className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
              />
              <p className="text-[11px] text-[#7A6F68] mt-1.5 leading-relaxed">
                নাম না দিলে নোট ১, নোট ২... হিসেবে দেখাবে। নিচে নামে চাপ দিলেই পুরো নোট খুলবে।
              </p>
            </div>

            {/* Note Text */}
            <div>
              <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
                নোট
              </label>
              <textarea
                rows={3}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="এখানে লিখুন..."
                className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all resize-none"
              />
            </div>

            {/* Photo Attachment (Screenshot 4) */}
            <div>
              <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
                ছবি (ইচ্ছা হলে)
              </label>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />

              {photoUrl ? (
                <div className="relative rounded-[18px] overflow-hidden border border-[#009E8F] bg-[#FAF5F0] p-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img
                      src={photoUrl}
                      alt="Preview"
                      className="w-12 h-12 object-cover rounded-xl"
                    />
                    <span className="text-xs font-bold text-[#009E8F]">ছবি যুক্ত হয়েছে</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPhotoUrl(undefined)}
                    className="p-1 rounded-full bg-red-100 text-[#E5484D] hover:bg-red-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full py-4 px-3 rounded-[18px] border-2 border-dashed border-[#009E8F]/40 hover:border-[#009E8F] bg-[#FAF5F0] flex items-center justify-center gap-2 text-xs font-bold text-[#1D1A18] active:scale-[0.99] transition-all"
                >
                  <Folder className="w-5 h-5 text-[#FFB020] fill-[#FFB020]/20" />
                  <span>ছবি যোগ করুন — ফোন থেকে বেছে নিন</span>
                </button>
              )}

              <p className="text-[11px] text-[#7A6F68] mt-1.5 leading-relaxed">
                ছবি ছাড়াও নোট রাখা যাবে। নোট জমা হলে নিচে এক লাইনে শুধু নাম দেখাবে — নামে চাপ দিলে পুরো নোট ও ছবি খুলবে, আর ছবিতে চাপ দিলেই এডিট, লেখা ও আঁকা খুলবে।
              </p>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-[18px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-extrabold text-sm shadow-md active:scale-[0.98] transition-all"
            >
              + নোট যোগ করুন
            </button>
          </form>
        </div>

        {/* Section info */}
        <p className="text-xs text-[#7A6F68] mt-4 mb-2">
          নিচে এক লাইনে শুধু নোটের নাম দেখাবে — নামে চাপ দিলেই পুরো নোট খুলবে।
        </p>

        {/* Notes List (Rule 6: SINGLE-LINE row only: "নোট ১ — [note name]") */}
        <div className="space-y-1.5">
          {notes.length === 0 ? (
            <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-6 text-center text-[#7A6F68] text-xs">
              কোনো নোট নেই। উপরে নতুন নোট লিখুন।
            </div>
          ) : (
            notes.map((note, index) => (
              <SwipeToDelete
                key={note.id}
                onDelete={() => deleteNote(note.id)}
                confirmTitle="নোট মুছে ফেলতে চান?"
                confirmMessage={`"${note.title}" মুছে ফেলা হবে।`}
              >
                <div
                  onClick={() => setActiveNote(note)}
                  className="p-4 bg-white rounded-[20px] border border-[#F0DDD2] flex items-center justify-between cursor-pointer hover:border-[#009E8F] active:bg-[#FAF5F0] transition-all shadow-xs"
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span className="w-2 h-2 rounded-full bg-[#009E8F] shrink-0" />
                    <span className="text-sm font-bold text-[#1D1A18] truncate">
                      নোট {index + 1} — {note.title}
                    </span>
                  </div>
                  {note.photoUrl && (
                    <span className="text-[10px] font-bold text-[#009E8F] bg-[#E0F7F6] px-2 py-0.5 rounded-full shrink-0">
                      ছবি সহ
                    </span>
                  )}
                </div>
              </SwipeToDelete>
            ))
          )}
        </div>
      </div>

      {/* Full Note Detail Modal */}
      {activeNote && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-t-[28px] sm:rounded-[28px] p-5 pb-8 sm:pb-6 shadow-2xl border border-[#F0DDD2] max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between border-b border-[#F0DDD2] pb-3 mb-3">
              <h3 className="text-lg font-bold text-[#1D1A18]">{activeNote.title}</h3>
              <button
                type="button"
                onClick={() => setActiveNote(null)}
                className="w-8 h-8 rounded-full bg-[#FAF5F0] text-[#1D1A18] flex items-center justify-center hover:bg-[#F0E4D8]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Note text */}
            {activeNote.text ? (
              <p className="text-sm text-[#1D1A18] whitespace-pre-wrap leading-relaxed mb-4 bg-[#FAF5F0] p-3.5 rounded-2xl border border-[#E9DACD]">
                {activeNote.text}
              </p>
            ) : (
              <p className="text-xs text-[#7A6F68] italic mb-4">কোনো বিবরণ লেখা নেই।</p>
            )}

            {/* Attached Photo */}
            {activeNote.photoUrl && (
              <div className="space-y-2 mb-4">
                <p className="text-xs font-bold text-[#1D1A18]">
                  সংযুক্ত ছবি (ছবিতে চাপলে ড্রয়িং ও এডিটর খুলবে):
                </p>
                <div
                  onClick={() => handleOpenPhotoEditor(activeNote.id)}
                  className="relative group rounded-2xl overflow-hidden border border-[#009E8F] cursor-pointer shadow-sm hover:opacity-95 transition-opacity"
                >
                  <img
                    src={activeNote.photoUrl}
                    alt={activeNote.title}
                    className="w-full max-h-64 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white font-bold text-xs gap-1.5">
                    <Edit3 className="w-4 h-4" />
                    <span>এডিট ও পরিমাপ ড্রয়িং করুন</span>
                  </div>
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-2">
              {activeNote.photoUrl && (
                <button
                  type="button"
                  onClick={() => handleOpenPhotoEditor(activeNote.id)}
                  className="flex-1 py-3 rounded-[16px] bg-[#00B4B4] hover:bg-[#009E9E] text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-xs"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>ছবি এডিট করুন</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setActiveNote(null)}
                className="flex-1 py-3 rounded-[16px] bg-[#F4EBE3] text-[#1D1A18] font-bold text-xs hover:bg-[#EAE0D7] active:scale-95 transition-all"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
