import React from 'react';
import { Home, Calendar, Users, House, FileText, Tag } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const BottomNav: React.FC = () => {
  const { screen, setScreen, language } = useApp();

  if (screen.type !== 'main') {
    return null; // Detail pages must NOT show bottom nav
  }

  const currentTab = screen.tab;

  const tabs = [
    {
      id: 'overview' as const,
      labelBn: 'ওভারভিউ',
      labelEn: 'Overview',
      icon: Home,
    },
    {
      id: 'daily' as const,
      labelBn: 'ডেইলি',
      labelEn: 'Daily',
      icon: Calendar,
    },
    {
      id: 'team' as const,
      labelBn: 'টিম',
      labelEn: 'Team',
      icon: Users,
    },
    {
      id: 'sites' as const,
      labelBn: 'সাইট',
      labelEn: 'Sites',
      icon: House,
    },
    {
      id: 'notes' as const,
      labelBn: 'নোট',
      labelEn: 'Notes',
      icon: FileText,
    },
    {
      id: 'prices' as const,
      labelBn: 'প্রাইস',
      labelEn: 'Prices',
      icon: Tag,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/95 backdrop-blur-md border-t border-[#F0DDD2] z-30 shadow-[0_-4px_16px_rgba(0,0,0,0.04)] pb-[max(env(safe-area-inset-bottom),8px)] pt-1.5">
      <div className="grid grid-cols-6 items-center px-1">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          const Icon = tab.icon;
          const label = language === 'en' ? tab.labelEn : tab.labelBn;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setScreen({ type: 'main', tab: tab.id })}
              className="flex flex-col items-center justify-center py-1 px-0.5 w-full min-w-0 transition-all select-none"
            >
              <div
                className={`p-1 rounded-full transition-colors ${
                  isActive ? 'text-[#009E8F] bg-[#E0F7F6]' : 'text-[#7A6F68] hover:text-[#1D1A18]'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
              </div>
              <span
                className={`text-[10px] sm:text-[11px] leading-tight truncate w-full text-center mt-0.5 tracking-tight ${
                  isActive ? 'text-[#009E8F] font-bold' : 'text-[#7A6F68] font-medium'
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
