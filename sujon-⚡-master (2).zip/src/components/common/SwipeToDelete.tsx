import React, { useState, useRef } from 'react';
import { Trash2 } from 'lucide-react';

interface SwipeToDeleteProps {
  children: React.ReactNode;
  onDelete: () => void;
  confirmTitle?: string;
  confirmMessage?: string;
  disabled?: boolean;
}

export const SwipeToDelete: React.FC<SwipeToDeleteProps> = ({
  children,
  onDelete,
  confirmTitle = 'মুছে ফেলতে চান?',
  confirmMessage = 'এই তথ্যটি মুছে ফেললে আর পুনরুদ্ধার করা যাবে না। আপনি কি নিশ্চিত?',
  disabled = false,
}) => {
  const [translateX, setTranslateX] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const startXRef = useRef<number | null>(null);
  const currentXRef = useRef<number>(0);
  const isDraggingRef = useRef(false);

  const ACTION_WIDTH = 80;

  const handleTouchStart = (clientX: number) => {
    if (disabled) return;
    startXRef.current = clientX;
    currentXRef.current = translateX;
    isDraggingRef.current = true;
  };

  const handleTouchMove = (clientX: number) => {
    if (!isDraggingRef.current || startXRef.current === null || disabled) return;
    const diff = clientX - startXRef.current;
    
    // Only allow swiping to the left (negative translateX)
    if (isOpen) {
      const newX = Math.min(0, Math.max(-ACTION_WIDTH - 20, -ACTION_WIDTH + diff));
      setTranslateX(newX);
    } else {
      if (diff < 0) {
        const newX = Math.max(-ACTION_WIDTH - 20, diff);
        setTranslateX(newX);
      }
    }
  };

  const handleTouchEnd = () => {
    if (!isDraggingRef.current || disabled) return;
    isDraggingRef.current = false;
    startXRef.current = null;

    if (translateX < -45) {
      setTranslateX(-ACTION_WIDTH);
      setIsOpen(true);
    } else {
      setTranslateX(0);
      setIsOpen(false);
    }
  };

  const handleCancel = () => {
    setShowConfirmModal(false);
    setTranslateX(0);
    setIsOpen(false);
  };

  const handleConfirmDelete = () => {
    setShowConfirmModal(false);
    setTranslateX(0);
    setIsOpen(false);
    onDelete();
  };

  return (
    <div className="relative overflow-hidden rounded-[20px] select-none my-2.5">
      {/* Background Delete Button Container (Revealed ONLY during/after right-to-left swipe) */}
      <div
        className="absolute inset-y-0 right-0 w-[80px] bg-[#E5484D] flex flex-col items-center justify-center text-white cursor-pointer transition-colors active:bg-[#C93B40] z-0"
        onClick={() => setShowConfirmModal(true)}
      >
        <Trash2 className="w-5 h-5 mb-1" />
        <span className="text-[11px] font-bold">মুছুন</span>
      </div>

      {/* Foreground Content Card that slides left */}
      <div
        className="relative z-10 transition-transform duration-150 ease-out bg-white rounded-[20px]"
        style={{
          transform: `translateX(${translateX}px)`,
        }}
        onTouchStart={(e) => handleTouchStart(e.touches[0].clientX)}
        onTouchMove={(e) => handleTouchMove(e.touches[0].clientX)}
        onTouchEnd={handleTouchEnd}
        onMouseDown={(e) => handleTouchStart(e.clientX)}
        onMouseMove={(e) => {
          if (isDraggingRef.current) handleTouchMove(e.clientX);
        }}
        onMouseUp={handleTouchEnd}
        onMouseLeave={handleTouchEnd}
      >
        {children}
      </div>

      {/* Confirmation Dialog */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-[22px] max-w-sm w-full p-5 shadow-2xl border border-[#F0DDD2] animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-red-100 text-[#E5484D] flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#1D1A18] text-center mb-1.5">
              {confirmTitle}
            </h3>
            <p className="text-sm text-[#7A6F68] text-center mb-5 leading-relaxed">
              {confirmMessage}
            </p>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={handleCancel}
                className="flex-1 py-2.5 px-3 rounded-[14px] bg-[#F4EBE3] text-[#1D1A18] font-semibold text-sm hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 px-3 rounded-[14px] bg-[#E5484D] text-white font-semibold text-sm shadow-md hover:bg-[#D4373C] active:scale-[0.98] transition-all"
              >
                হ্যাঁ, মুছুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
