import React, { useState, useMemo } from 'react';
import { Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  toBengaliNumber,
  formatTaka,
  getTodayDateString,
  ENGLISH_MONTHS,
} from '../../utils/bengali';
import { Worker } from '../../types';
import { AddWorkerModal } from './AddWorkerModal';
import { WorkerPaymentModal } from './WorkerPaymentModal';
import { OvertimeModal } from './OvertimeModal';
import { SwipeToDelete } from '../common/SwipeToDelete';
import { generateWorkerPdf } from '../../utils/pdf';

export const TeamScreen: React.FC = () => {
  const {
    workers,
    attendance,
    overtime,
    workerPayments,
    toggleAttendance,
    deleteWorker,
    setScreen,
    language,
    themeStyles,
  } = useApp();

  const [showAddWorkerModal, setShowAddWorkerModal] = useState(false);
  const [paymentWorker, setPaymentWorker] = useState<Worker | null>(null);
  const [otWorker, setOtWorker] = useState<Worker | null>(null);

  const todayStr = getTodayDateString();
  const currentMonthPrefix = todayStr.slice(0, 7);
  const currentYear = parseInt(todayStr.split('-')[0], 10);
  const currentMonthIndex = parseInt(todayStr.split('-')[1], 10) - 1;

  // Present workers today count
  const todayPresentCount = useMemo(() => {
    return attendance.filter((a) => a.date === todayStr).length;
  }, [attendance, todayStr]);

  // Worker statistics helper for this month
  const workerStats = useMemo(() => {
    const statsMap: Record<
      string,
      {
        daysWorkedThisMonth: number;
        takenThisMonth: number;
        otThisMonth: number;
        dueThisMonth: number;
        isPresentToday: boolean;
      }
    > = {};

    workers.forEach((w) => {
      // Days worked this month
      const daysWorked = attendance.filter(
        (a) => a.workerId === w.id && a.date.startsWith(currentMonthPrefix)
      ).length;

      // Taken this month
      const taken = workerPayments
        .filter((p) => p.workerId === w.id && p.date.startsWith(currentMonthPrefix))
        .reduce((sum, p) => sum + p.amount, 0);

      // OT this month
      const ot = overtime
        .filter((o) => o.workerId === w.id && o.date.startsWith(currentMonthPrefix))
        .reduce((sum, o) => sum + o.amount, 0);

      // Due = Earned - Taken
      const earned = daysWorked * w.dailyWage + ot;
      const due = earned - taken;

      const isPresentToday = attendance.some(
        (a) => a.workerId === w.id && a.date === todayStr
      );

      statsMap[w.id] = {
        daysWorkedThisMonth: daysWorked,
        takenThisMonth: taken,
        otThisMonth: ot,
        dueThisMonth: due,
        isPresentToday,
      };
    });

    return statsMap;
  }, [workers, attendance, workerPayments, overtime, currentMonthPrefix, todayStr]);

  const handleDownloadPdf = async (worker: Worker) => {
    await generateWorkerPdf(
      worker,
      currentYear,
      currentMonthIndex,
      attendance,
      overtime,
      workerPayments
    );
  };

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Top Header */}
      <header className="px-4 sm:px-5 pt-5 pb-3">
        <h2 className="text-2xl font-extrabold text-[#1D1A18] tracking-tight">
          {language === 'en' ? 'Team & attendance' : 'টিম ও হাজিরা'}
        </h2>
        <p className="text-xs font-semibold text-[#7A6F68] mt-1">
          উপস্থিত {toBengaliNumber(todayPresentCount)} / {toBengaliNumber(workers.length)} জন • Today,{' '}
          {new Date().getDate()} {ENGLISH_MONTHS[new Date().getMonth()]}
        </p>
      </header>

      {/* Worker Cards List */}
      <main className="px-4 sm:px-5 mt-2 space-y-3">
        {workers.length === 0 ? (
          <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-8 text-center text-[#7A6F68] text-sm my-4">
            {language === 'en'
              ? 'No workers in list. Add a new worker below.'
              : 'কোনো কর্মী নেই। নিচে নতুন কর্মী যোগ করুন।'}
          </div>
        ) : (
          workers.map((worker) => {
            const stats = workerStats[worker.id] || {
              daysWorkedThisMonth: 0,
              takenThisMonth: 0,
              otThisMonth: 0,
              dueThisMonth: 0,
              isPresentToday: false,
            };

            return (
              <SwipeToDelete
                key={worker.id}
                onDelete={() => deleteWorker(worker.id)}
                confirmTitle="কর্মী মুছে ফেলতে চান?"
                confirmMessage={`"${worker.name}" কর্মীর যাবতীয় হাজিরা ও লেনদেনের হিসাব পুরোপুরি মুছে ফেলা হবে।`}
              >
                <div className="p-4 bg-white rounded-[22px] border border-[#F0DDD2] shadow-xs">
                  {/* Top row: Avatar + Name + Due */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-[#009E8F] text-white flex items-center justify-center font-extrabold text-lg shadow-sm">
                        {worker.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="text-base font-extrabold text-[#1D1A18] leading-snug">
                          {worker.name}
                        </h3>
                        <p className="text-xs text-[#7A6F68] font-medium">
                          {worker.role} • হাজিরা {formatTaka(worker.dailyWage)}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[11px] font-bold text-[#7A6F68]">বাকি</span>
                      <p className={`text-base font-extrabold ${stats.dueThisMonth >= 0 ? 'text-[#E5484D]' : 'text-[#0A9D6B]'}`}>
                        {formatTaka(stats.dueThisMonth)}
                      </p>
                    </div>
                  </div>

                  {/* Badges / Pill Tags */}
                  <div className="flex flex-wrap items-center gap-2 mt-3.5">
                    <span className="px-3 py-1 rounded-full bg-[#FAF5F0] border border-[#F0DDD2] text-xs font-bold text-[#1D1A18]">
                      এই মাসে {toBengaliNumber(stats.daysWorkedThisMonth)} দিন
                    </span>
                    <span className="px-3 py-1 rounded-full bg-[#FAF5F0] border border-[#F0DDD2] text-xs font-bold text-[#1D1A18]">
                      নিয়েছে {formatTaka(stats.takenThisMonth)}
                    </span>
                    <span className="px-3 py-1 rounded-full bg-[#FAF5F0] border border-[#F0DDD2] text-xs font-bold text-[#1D1A18]">
                      {stats.otThisMonth > 0 ? `OT: ${formatTaka(stats.otThisMonth)}` : 'OT: ০ ঘন্টা'}
                    </span>
                  </div>

                  {/* Buttons in EXACT specified order (Screenshot 2):
                      1. উপস্থিত (green, tap toggles present for today)
                      2. ৳ টাকা দিন (dark)
                      3. + OT (outline)
                      4. মাসিক হিসাব দেখুন (gradient)
                      5. PDF শেয়ার (dark)
                  */}
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    <button
                      type="button"
                      onClick={() => toggleAttendance(worker.id, todayStr)}
                      className={`py-2.5 px-1 rounded-[14px] text-xs font-bold transition-all flex items-center justify-center ${
                        stats.isPresentToday
                          ? 'bg-[#0A9D6B] text-white shadow-xs scale-102 ring-2 ring-[#0A9D6B]/30'
                          : 'bg-[#E6F8F0] text-[#0A9D6B] border border-[#A7E8CD] hover:bg-[#D5F4E5]'
                      }`}
                    >
                      {stats.isPresentToday ? '✓ উপস্থিত' : 'উপস্থিত'}
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentWorker(worker)}
                      className="py-2.5 px-1 rounded-[14px] bg-[#1D1A18] text-white text-xs font-bold hover:bg-[#2C2825] active:scale-95 transition-all text-center"
                    >
                      ৳ টাকা দিন
                    </button>

                    <button
                      type="button"
                      onClick={() => setOtWorker(worker)}
                      className="py-2.5 px-1 rounded-[14px] bg-white text-[#1D1A18] border border-[#D5C2B4] hover:bg-[#FAF5F0] text-xs font-bold active:scale-95 transition-all text-center"
                    >
                      + OT
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <button
                      type="button"
                      onClick={() =>
                        setScreen({
                          type: 'worker-statement',
                          workerId: worker.id,
                          initialDate: todayStr,
                        })
                      }
                      className={`py-2.5 px-2 rounded-[14px] text-xs font-bold text-center ${themeStyles.primaryBtn}`}
                    >
                      মাসিক হিসাব দেখুন
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDownloadPdf(worker)}
                      className="py-2.5 px-2 rounded-[14px] bg-[#1D1A18] text-white text-xs font-bold hover:bg-[#2C2825] active:scale-95 transition-all text-center"
                    >
                      PDF শেয়ার
                    </button>
                  </div>
                </div>
              </SwipeToDelete>
            );
          })
        )}

        {/* + নতুন কর্মী যোগ করুন Button */}
        <button
          type="button"
          onClick={() => setShowAddWorkerModal(true)}
          className="w-full py-4 rounded-[20px] bg-white border border-[#F0DDD2] hover:border-[#009E8F] text-[#1D1A18] font-extrabold text-sm flex items-center justify-center gap-2 shadow-xs active:scale-[0.99] transition-all my-3"
        >
          <Plus className="w-5 h-5 text-[#009E8F] stroke-[2.5]" />
          <span>+ নতুন কর্মী যোগ করুন</span>
        </button>
      </main>

      {/* Add Worker Modal */}
      {showAddWorkerModal && <AddWorkerModal onClose={() => setShowAddWorkerModal(false)} />}

      {/* Worker Payment Modal */}
      {paymentWorker && (
        <WorkerPaymentModal
          worker={paymentWorker}
          onClose={() => setPaymentWorker(null)}
        />
      )}

      {/* OT Modal */}
      {otWorker && (
        <OvertimeModal
          worker={otWorker}
          date={todayStr}
          currentAmount={
            overtime.find((o) => o.workerId === otWorker.id && o.date === todayStr)?.amount ?? 0
          }
          onClose={() => setOtWorker(null)}
        />
      )}
    </div>
  );
};
