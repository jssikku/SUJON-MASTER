import React, { useState, useRef, useMemo } from 'react';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  FileDown,
  Plus,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  toBengaliNumber,
  formatTaka,
  formatBengaliDate,
  getDayOfWeekBengali,
  BENGALI_MONTHS,
  getDaysInMonth,
  getFirstDayOfMonth,
  getTodayDateString,
} from '../../utils/bengali';
import { generateWorkerPdf } from '../../utils/pdf';
import { WorkerPaymentModal } from './WorkerPaymentModal';
import { OvertimeModal } from './OvertimeModal';
import { SwipeToDelete } from '../common/SwipeToDelete';

interface WorkerStatementScreenProps {
  workerId: string;
  initialDate?: string;
}

export const WorkerStatementScreen: React.FC<WorkerStatementScreenProps> = ({
  workerId,
  initialDate,
}) => {
  const {
    workers,
    attendance,
    overtime,
    workerPayments,
    toggleAttendance,
    deleteWorkerPayment,
    goBack,
    themeStyles,
  } = useApp();

  const worker = workers.find((w) => w.id === workerId);

  // Month & Year state
  const initialYear = initialDate ? parseInt(initialDate.split('-')[0], 10) : new Date().getFullYear();
  const initialMonth = initialDate ? parseInt(initialDate.split('-')[1], 10) - 1 : new Date().getMonth();

  const [currentYear, setCurrentYear] = useState<number>(initialYear);
  const [currentMonth, setCurrentMonth] = useState<number>(initialMonth);

  // Modals
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [otModalDate, setOtModalDate] = useState<string | null>(null);

  // Double-tap tracker for calendar dates (Rule 4: ~300ms double tap opens OT)
  const lastTapRef = useRef<{ date: string; time: number } | null>(null);
  const singleTapTimerRef = useRef<NodeJS.Timeout | null>(null);

  if (!worker) {
    return (
      <div className="p-6 text-center">
        <p className="text-sm text-[#7A6F68]">কর্মী পাওয়া যায়নি।</p>
        <button
          type="button"
          onClick={goBack}
          className="mt-4 px-4 py-2 rounded-xl bg-[#F0DDD2] text-[#1D1A18] font-bold text-sm"
        >
          ফিরে যান
        </button>
      </div>
    );
  }

  const monthPrefix = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}`;

  // Monthly Attendance
  const monthlyAttendance = useMemo(() => {
    return attendance
      .filter((a) => a.workerId === worker.id && a.date.startsWith(monthPrefix))
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [attendance, worker.id, monthPrefix]);

  const workedDaysCount = monthlyAttendance.length;
  const haziraEarnings = workedDaysCount * worker.dailyWage;

  // Monthly Overtime
  const monthlyOvertime = useMemo(() => {
    return overtime.filter((o) => o.workerId === worker.id && o.date.startsWith(monthPrefix));
  }, [overtime, worker.id, monthPrefix]);

  const totalOtAmount = useMemo(() => {
    return monthlyOvertime.reduce((sum, o) => sum + o.amount, 0);
  }, [monthlyOvertime]);

  // Monthly Payments
  const monthlyPayments = useMemo(() => {
    return workerPayments
      .filter((p) => p.workerId === worker.id && p.date.startsWith(monthPrefix))
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [workerPayments, worker.id, monthPrefix]);

  const totalTaken = useMemo(() => {
    return monthlyPayments.reduce((sum, p) => sum + p.amount, 0);
  }, [monthlyPayments]);

  const totalEarned = haziraEarnings + totalOtAmount;
  const balanceDue = totalEarned - totalTaken;

  // Calendar setup
  const totalDays = getDaysInMonth(currentYear, currentMonth);
  const firstDayOfWeek = getFirstDayOfMonth(currentYear, currentMonth); // 0 = Sunday
  const todayStr = getTodayDateString();

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  // Calendar Click / Double Click Handler (Rule 5 & Rule 6)
  const handleDateClick = (day: number) => {
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const now = Date.now();

    if (lastTapRef.current && lastTapRef.current.date === dateStr && now - lastTapRef.current.time < 350) {
      // Double tap detected! Clear single tap timer and open OT sheet
      if (singleTapTimerRef.current) {
        clearTimeout(singleTapTimerRef.current);
        singleTapTimerRef.current = null;
      }
      lastTapRef.current = null;
      setOtModalDate(dateStr);
    } else {
      // Single tap: set timer for toggle attendance
      lastTapRef.current = { date: dateStr, time: now };
      if (singleTapTimerRef.current) clearTimeout(singleTapTimerRef.current);
      singleTapTimerRef.current = setTimeout(() => {
        toggleAttendance(worker.id, dateStr);
        lastTapRef.current = null;
      }, 350);
    }
  };

  const handleDownloadPdf = async () => {
    await generateWorkerPdf(worker, currentYear, currentMonth, attendance, overtime, workerPayments);
  };

  return (
    <div className="pb-24 animate-in fade-in duration-200">
      {/* Detail Page Header (Rule 4: Full-width theme-gradient header, NO Overview hero, NO second bottom nav) */}
      <header className={`w-full ${themeStyles.headerGradient} text-white pt-6 pb-6 px-4 sm:px-5 rounded-b-[28px] shadow-md`}>
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={goBack}
            className="flex items-center gap-1.5 text-white/95 hover:text-white font-bold text-sm active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
            <span>টিমে ফিরুন</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPdf}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-black/30 hover:bg-black/40 text-white font-bold text-xs active:scale-95 transition-all border border-white/20"
          >
            <FileDown className="w-4 h-4" />
            <span>PDF ডাউনলোড</span>
          </button>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-white tracking-tight">{worker.name}</h2>
            <p className="text-xs text-white/90 font-medium mt-0.5">
              {worker.role} • দৈনিক হাজিরা {formatTaka(worker.dailyWage)}
            </p>
          </div>
          <div className="text-right">
            <span className="text-[11px] font-semibold text-white/80 block">মোট বাকি</span>
            <span className="text-xl font-extrabold text-[#7DFFC4]">
              {formatTaka(balanceDue)}
            </span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="px-4 sm:px-5 mt-4 space-y-4">
        {/* Month Navigation */}
        <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3 flex items-center justify-between shadow-xs">
          <button
            type="button"
            onClick={handlePrevMonth}
            className="w-9 h-9 rounded-full bg-[#FAF5F0] hover:bg-[#F0E4D8] flex items-center justify-center text-[#1D1A18] active:scale-95 transition-all"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-base font-extrabold text-[#1D1A18]">
            {BENGALI_MONTHS[currentMonth]} {toBengaliNumber(currentYear)}
          </span>
          <button
            type="button"
            onClick={handleNextMonth}
            className="w-9 h-9 rounded-full bg-[#FAF5F0] hover:bg-[#F0E4D8] flex items-center justify-center text-[#1D1A18] active:scale-95 transition-all"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Worked Days Calendar (Rule 5: Present = Dark Box ONLY, NO checkmarks. White = Absent. Double tap = OT) */}
        <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-4 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold text-[#1D1A18]">হাজিরা ক্যালেন্ডার</h4>
            <span className="text-xs font-semibold text-[#0A9D6B]">
              মোট উপস্থিত: {toBengaliNumber(workedDaysCount)} দিন
            </span>
          </div>

          <div className="grid grid-cols-7 gap-1 text-center mb-1.5">
            {['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'].map((d) => (
              <span key={d} className="text-[11px] font-bold text-[#7A6F68] py-1">
                {d}
              </span>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1.5">
            {/* Blank leading days */}
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} className="h-9 sm:h-10 rounded-xl bg-transparent" />
            ))}

            {/* Days of month */}
            {Array.from({ length: totalDays }).map((_, i) => {
              const day = i + 1;
              const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const isPresent = monthlyAttendance.some((a) => a.date === dateStr);
              const dayOt = monthlyOvertime.find((o) => o.date === dateStr);
              const isToday = dateStr === todayStr;

              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => handleDateClick(day)}
                  className={`h-9 sm:h-10 rounded-xl flex flex-col items-center justify-center font-bold text-xs transition-all relative select-none ${
                    isPresent
                      ? 'bg-[#1D1A18] text-white shadow-xs'
                      : 'bg-white border border-[#E9DACD] text-[#1D1A18] hover:bg-[#FAF4EE]'
                  } ${isToday && !isPresent ? 'ring-2 ring-[#009E8F]' : ''}`}
                >
                  <span>{toBengaliNumber(day)}</span>
                  {dayOt && (
                    <span className="text-[8px] font-extrabold text-[#FFB020] leading-none mt-0.5">
                      OT
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-[#7A6F68] mt-3 text-center">
            এক চাপ দিলে হাজিরা (কালো বক্স), দুই চাপ (ডাবল-ট্যাপ) দিলে OT যোগ হবে।
          </p>
        </div>

        {/* Summary Metrics */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">হাজিরা আয়</span>
            <p className="text-base font-extrabold text-[#1D1A18] mt-0.5">
              {formatTaka(haziraEarnings)}
            </p>
            <span className="text-[11px] text-[#7A6F68]">
              {toBengaliNumber(workedDaysCount)} দিন × {formatTaka(worker.dailyWage)}
            </span>
          </div>

          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">ওভারটাইম (OT)</span>
            <p className="text-base font-extrabold text-[#854D0E] mt-0.5">
              {totalOtAmount > 0 ? formatTaka(totalOtAmount) : 'কোনো OT নেই'}
            </p>
            <span className="text-[11px] text-[#7A6F68]">
              {totalOtAmount > 0 ? 'ম্যানুয়াল OT হিসাব' : 'এই মাসে কোনো OT নেই'}
            </span>
          </div>

          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">মোট নিয়েছে</span>
            <p className="text-base font-extrabold text-[#E5484D] mt-0.5">
              {formatTaka(totalTaken)}
            </p>
            <span className="text-[11px] text-[#7A6F68]">
              {toBengaliNumber(monthlyPayments.length)} টি পেমেন্ট
            </span>
          </div>

          <div className="bg-white rounded-[20px] border border-[#F0DDD2] p-3.5 shadow-xs">
            <span className="text-xs font-semibold text-[#7A6F68]">বর্তমান বাকি</span>
            <p className={`text-base font-extrabold mt-0.5 ${balanceDue >= 0 ? 'text-[#0A9D6B]' : 'text-[#E5484D]'}`}>
              {formatTaka(balanceDue)}
            </p>
            <span className="text-[11px] text-[#7A6F68]">
              মোট আয় - মোট নিয়েছে
            </span>
          </div>
        </div>

        {/* Payments List (টাকা নিয়েছে) */}
        <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-4 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold text-[#1D1A18]">টাকা নিয়েছে</h4>
            <button
              type="button"
              onClick={() => setShowPaymentModal(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#1D1A18] text-white text-xs font-bold active:scale-95 transition-all shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>৳ টাকা দিন</span>
            </button>
          </div>

          {monthlyPayments.length === 0 ? (
            <p className="text-xs text-[#7A6F68] text-center py-4 italic">
              এই মাসে কোনো টাকা দেওয়া হয়নি।
            </p>
          ) : (
            <div className="space-y-1">
              {monthlyPayments.map((p) => (
                <SwipeToDelete
                  key={p.id}
                  onDelete={() => deleteWorkerPayment(p.id)}
                  confirmTitle="পেমেন্ট মুছে ফেলতে চান?"
                  confirmMessage={`${formatBengaliDate(p.date)}-এর ${formatTaka(p.amount)} পেমেন্ট মুছে ফেলা হবে।`}
                >
                  <div className="p-3 flex items-center justify-between border border-[#F0DDD2] rounded-xl hover:bg-[#FAF5F0] transition-colors">
                    <div>
                      <p className="text-xs font-bold text-[#1D1A18]">{p.note || 'নগদ গ্রহণ'}</p>
                      <p className="text-[11px] text-[#7A6F68]">{formatBengaliDate(p.date)}</p>
                    </div>
                    <span className="text-sm font-bold text-[#E5484D]">
                      - {formatTaka(p.amount)}
                    </span>
                  </div>
                </SwipeToDelete>
              ))}
            </div>
          )}
        </div>

        {/* Day-by-day Worked Days List */}
        <div className="bg-white rounded-[22px] border border-[#F0DDD2] p-4 shadow-xs">
          <h4 className="text-sm font-bold text-[#1D1A18] mb-3">কাজের দিনসমূহ</h4>
          {monthlyAttendance.length === 0 ? (
            <p className="text-xs text-[#7A6F68] text-center py-4 italic">
              এই মাসে এখনও কোনো কাজের দিন যোগ করা হয়নি।
            </p>
          ) : (
            <div className="divide-y divide-[#F0DDD2] max-h-60 overflow-y-auto pr-1">
              {monthlyAttendance.map((att, idx) => (
                <div key={att.id} className="py-2 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-5 text-[#7A6F68] font-bold text-[11px]">
                      {toBengaliNumber(idx + 1)}.
                    </span>
                    <div>
                      <span className="font-bold text-[#1D1A18]">{formatBengaliDate(att.date)}</span>
                      <span className="text-[#7A6F68] ml-2">({getDayOfWeekBengali(att.date)})</span>
                    </div>
                  </div>
                  <span className="font-bold text-[#0A9D6B]">{formatTaka(worker.dailyWage)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Payment Sheet */}
      {showPaymentModal && (
        <WorkerPaymentModal
          worker={worker}
          initialDate={monthPrefix + '-01'}
          onClose={() => setShowPaymentModal(false)}
        />
      )}

      {/* OT Sheet (Rule 6: manual OT amount only) */}
      {otModalDate && (
        <OvertimeModal
          worker={worker}
          date={otModalDate}
          currentAmount={overtime.find((o) => o.workerId === worker.id && o.date === otModalDate)?.amount ?? 0}
          onClose={() => setOtModalDate(null)}
        />
      )}
    </div>
  );
};
