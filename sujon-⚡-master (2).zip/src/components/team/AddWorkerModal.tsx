import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { toEnglishNumber } from '../../utils/bengali';

interface AddWorkerModalProps {
  onClose: () => void;
}

export const AddWorkerModal: React.FC<AddWorkerModalProps> = ({ onClose }) => {
  const { addWorker, themeStyles } = useApp();
  const [name, setName] = useState('');
  const [role, setRole] = useState<'মিস্ত্রি' | 'হেলপার'>('মিস্ত্রি');
  const [wageStr, setWageStr] = useState('৮০০');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) {
      setError('কর্মীর নাম লিখুন');
      return;
    }
    const wage = parseFloat(toEnglishNumber(wageStr.trim()));
    if (isNaN(wage) || wage <= 0) {
      setError('সঠিক দৈনিক হাজিরা লিখুন');
      return;
    }

    const res = addWorker(cleanName, role, wage);
    if (!res.success) {
      setError(res.message || 'ত্রুটি ঘটেছে');
      return;
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[28px] sm:rounded-[28px] p-5 pb-8 sm:pb-6 shadow-2xl border border-[#F0DDD2] animate-in slide-in-from-bottom duration-200">
        <div className="w-12 h-1.5 bg-[#E6DACF] rounded-full mx-auto mb-3" />

        <h3 className="text-xl font-bold text-[#1D1A18] mb-4">
          + নতুন কর্মী যোগ করুন
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              নাম
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              placeholder="যেমন: আলমগীর / সালাম"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              ধরন
            </label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as 'মিস্ত্রি' | 'হেলপার')}
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            >
              <option value="মিস্ত্রি">মিস্ত্রি</option>
              <option value="হেলপার">হেলপার</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              দৈনিক হাজিরা (৳)
            </label>
            <input
              type="text"
              inputMode="numeric"
              value={wageStr}
              onChange={(e) => {
                setWageStr(e.target.value);
                if (error) setError('');
              }}
              placeholder="যেমন: ৮০০"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-base font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          {error && <p className="text-xs font-bold text-[#E5484D]">{error}</p>}

          <div className="flex gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-[16px] bg-[#F4EBE3] text-[#1D1A18] font-bold text-sm hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className={`flex-1 py-3 px-4 rounded-[16px] text-white font-bold text-sm shadow-md active:scale-[0.98] transition-all ${themeStyles.primaryBtn}`}
            >
              যোগ করুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
