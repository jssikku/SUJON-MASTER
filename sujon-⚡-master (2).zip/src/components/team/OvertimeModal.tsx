import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Worker } from '../../types';
import { formatBengaliDate, toEnglishNumber } from '../../utils/bengali';

interface OvertimeModalProps {
  worker: Worker;
  date: string;
  currentAmount?: number;
  onClose: () => void;
}

export const OvertimeModal: React.FC<OvertimeModalProps> = ({
  worker,
  date,
  currentAmount = 0,
  onClose,
}) => {
  const { setWorkerOvertime, deleteWorkerOvertime, themeStyles } = useApp();
  // ONLY a blank manual OT amount box (Rule 6: NO hours/rate/total)
  const [amountStr, setAmountStr] = useState(currentAmount > 0 ? String(currentAmount) : '');
  const [error, setError] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanStr = amountStr.trim();
    if (!cleanStr) {
      // If blank, remove OT
      deleteWorkerOvertime(worker.id, date);
      onClose();
      return;
    }
    const amount = parseFloat(toEnglishNumber(cleanStr));
    if (isNaN(amount) || amount < 0) {
      setError('সঠিক টাকার অঙ্ক লিখুন');
      return;
    }

    if (amount === 0) {
      deleteWorkerOvertime(worker.id, date);
    } else {
      setWorkerOvertime(worker.id, date, amount);
    }
    onClose();
  };

  const handleDelete = () => {
    deleteWorkerOvertime(worker.id, date);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[28px] sm:rounded-[28px] p-5 pb-8 sm:pb-6 shadow-2xl border border-[#F0DDD2] animate-in slide-in-from-bottom duration-200">
        <div className="w-12 h-1.5 bg-[#E6DACF] rounded-full mx-auto mb-3" />

        <div className="mb-4">
          <h3 className="text-xl font-bold text-[#1D1A18]">
            তারিখের OT হিসাব — {worker.name}
          </h3>
          <p className="text-xs text-[#7A6F68] mt-0.5 font-medium">
            তারিখ: {formatBengaliDate(date)}
          </p>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              ওভারটাইম টাকা (৳)
            </label>
            <input
              type="text"
              inputMode="numeric"
              autoFocus
              value={amountStr}
              onChange={(e) => {
                setAmountStr(e.target.value);
                if (error) setError('');
              }}
              placeholder="সরাসরি টাকার অঙ্ক লিখুন (যেমন: ৫০০)"
              className="w-full px-4 py-3.5 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-lg font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
            <p className="text-[11px] text-[#7A6F68] mt-1.5 leading-normal">
              শুধু ম্যানুয়াল টাকার অঙ্ক লিখুন। কোনো রেট বা ঘণ্টার হিসাব হবে না।
            </p>
          </div>

          {error && <p className="text-xs font-bold text-[#E5484D]">{error}</p>}

          <div className="flex gap-2.5 pt-2">
            {currentAmount > 0 ? (
              <button
                type="button"
                onClick={handleDelete}
                className="py-3 px-4 rounded-[16px] bg-red-50 text-[#E5484D] font-bold text-sm hover:bg-red-100 active:scale-[0.98] transition-all"
              >
                OT মুছুন
              </button>
            ) : (
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 px-4 rounded-[16px] bg-[#F4EBE3] text-[#1D1A18] font-bold text-sm hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
              >
                বাতিল
              </button>
            )}

            <button
              type="submit"
              className={`flex-1 py-3 px-4 rounded-[16px] text-white font-bold text-sm shadow-md active:scale-[0.98] transition-all ${themeStyles.primaryBtn}`}
            >
              সংরক্ষণ করুন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
