import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Worker } from '../../types';
import { getTodayDateString, toEnglishNumber } from '../../utils/bengali';

interface WorkerPaymentModalProps {
  worker: Worker;
  initialDate?: string;
  onClose: () => void;
}

export const WorkerPaymentModal: React.FC<WorkerPaymentModalProps> = ({
  worker,
  initialDate,
  onClose,
}) => {
  const { addWorkerPayment, themeStyles } = useApp();
  const [date, setDate] = useState(initialDate || getTodayDateString());
  const [amountStr, setAmountStr] = useState('');
  const [note, setNote] = useState('সাপ্তাহিক');
  const [error, setError] = useState('');

  const quickNotes = ['অগ্রিম', 'সাপ্তাহিক', 'ধার', 'হিসাব পরিশোধ', 'নাস্তা/যাতায়াত'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rawAmount = parseFloat(toEnglishNumber(amountStr.trim()));
    if (isNaN(rawAmount) || rawAmount <= 0) {
      setError('সঠিক টাকার অঙ্ক লিখুন');
      return;
    }

    addWorkerPayment(worker.id, date, rawAmount, note.trim() || 'নগদ গ্রহণ');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[28px] sm:rounded-[28px] p-5 pb-8 sm:pb-6 shadow-2xl border border-[#F0DDD2] animate-in slide-in-from-bottom duration-200">
        <div className="w-12 h-1.5 bg-[#E6DACF] rounded-full mx-auto mb-3" />

        <div className="mb-4">
          <h3 className="text-xl font-bold text-[#1D1A18]">
            টাকা দিন — {worker.name}
          </h3>
          <p className="text-xs text-[#7A6F68] mt-0.5">
            তারিখ অনুযায়ী কর্মীর মাসিক হিসেবে টাকা জমা হবে।
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              তারিখ (যে কোনো অতীতের বা ভবিষ্যতের তারিখ)
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm font-semibold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              টাকা (৳)
            </label>
            <input
              type="text"
              inputMode="numeric"
              value={amountStr}
              onChange={(e) => {
                setAmountStr(e.target.value);
                if (error) setError('');
              }}
              placeholder="যেমন: ১৫০০"
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-base font-bold text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1D1A18] mb-1.5">
              বিবরণ / নোট
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {quickNotes.map((chip) => (
                <button
                  key={chip}
                  type="button"
                  onClick={() => setNote(chip)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                    note === chip
                      ? 'bg-[#1D1A18] text-white shadow-xs'
                      : 'bg-[#FBF5F0] text-[#7A6F68] border border-[#E9DACD] hover:text-[#1D1A18]'
                  }`}
                >
                  {chip}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="অথবা নিজে লিখুন..."
              className="w-full px-4 py-3 rounded-[16px] bg-[#FAF5F0] border border-[#E9DACD] text-sm text-[#1D1A18] focus:bg-white focus:outline-hidden focus:border-[#009E8F] transition-all"
            />
          </div>

          {error && <p className="text-xs font-bold text-[#E5484D]">{error}</p>}

          <div className="flex gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-[16px] bg-[#F4EBE3] text-[#1D1A18] font-bold text-sm hover:bg-[#EAE0D7] active:scale-[0.98] transition-all"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className={`flex-1 py-3 px-4 rounded-[16px] text-white font-bold text-sm shadow-md active:scale-[0.98] transition-all ${themeStyles.primaryBtn}`}
            >
              টাকা দিন
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
