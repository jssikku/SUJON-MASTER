import { jsPDF } from 'jspdf';
import { Worker, AttendanceRecord, OvertimeRecord, WorkerPayment, Site, SitePayment } from '../types';
import {
  toBengaliNumber,
  formatBengaliDate,
  formatTaka,
  getDayOfWeekBengali,
  getDayOfWeekEnglish,
  ENGLISH_MONTHS,
  BENGALI_MONTHS,
} from './bengali';

/**
 * Worker PDF Generator
 * RULE 13: English ONLY, EXACTLY 1 page covering the full account:
 * worked-days table and money-taken table on the same page, with both totals and summary/due,
 * no row dropped, even for 31 days + many payments. Row height must scale to fit 1 page.
 */
export const generateWorkerPdf = async (
  worker: Worker,
  year: number,
  monthIndex: number, // 0-indexed
  attendance: AttendanceRecord[],
  overtime: OvertimeRecord[],
  payments: WorkerPayment[]
): Promise<void> => {
  const monthStr = String(monthIndex + 1).padStart(2, '0');
  const monthPrefix = `${year}-${monthStr}`;
  const monthNameEn = ENGLISH_MONTHS[monthIndex];

  // Filter attendance for this month
  const monthlyAttendance = attendance
    .filter((a) => a.workerId === worker.id && a.date.startsWith(monthPrefix))
    .sort((a, b) => a.date.localeCompare(b.date));

  // Filter overtime for this month
  const monthlyOvertime = overtime
    .filter((o) => o.workerId === worker.id && o.date.startsWith(monthPrefix));
  const totalOtAmount = monthlyOvertime.reduce((sum, o) => sum + o.amount, 0);

  // Filter payments for this month
  const monthlyPayments = payments
    .filter((p) => p.workerId === worker.id && p.date.startsWith(monthPrefix))
    .sort((a, b) => a.date.localeCompare(b.date));

  const totalWorkedDays = monthlyAttendance.length;
  const haziraEarnings = totalWorkedDays * worker.dailyWage;
  const totalEarned = haziraEarnings + totalOtAmount;
  const totalTaken = monthlyPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalDue = totalEarned - totalTaken;

  // Render on off-screen high-DPI canvas
  const canvas = document.createElement('canvas');
  const width = 1200;
  const height = 1700; // standard A4 aspect ~ 1 : 1.414
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, height);

  // Header banner
  ctx.fillStyle = '#0F172A';
  ctx.fillRect(40, 40, width - 80, 110);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 36px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('SUJON MASTER — WORKER STATEMENT', 65, 95);

  ctx.font = '500 20px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.fillText(`ELECTRIC • PLUMBING • SANITARY CONTRACTOR`, 65, 128);

  ctx.font = 'bold 22px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = '#38BDF8';
  ctx.textAlign = 'right';
  ctx.fillText(`${monthNameEn.toUpperCase()} ${year}`, width - 65, 105);
  ctx.textAlign = 'left';

  // Worker Info Card
  ctx.fillStyle = '#F8FAFC';
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(40, 165, width - 80, 85, 10);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 26px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(worker.name, 65, 205);

  ctx.font = '500 18px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = '#64748B';
  const roleEn = worker.role === 'মিস্ত্রি' ? 'Mistri (Head Worker)' : 'Helper';
  ctx.fillText(`Role: ${roleEn}   |   Daily Wage: BDT ${worker.dailyWage.toLocaleString('en-IN')}`, 65, 235);

  // Summary Metrics (5 boxes)
  const metricY = 265;
  const boxW = (width - 80 - 40) / 5;
  const boxH = 75;

  const metrics = [
    { label: 'Worked Days', value: `${totalWorkedDays} Days`, color: '#0284C7' },
    { label: 'Hazira Earned', value: `৳${haziraEarnings.toLocaleString('en-IN')}`, color: '#0F172A' },
    { label: 'OT Earned', value: `৳${totalOtAmount.toLocaleString('en-IN')}`, color: '#854D0E' },
    { label: 'Money Taken', value: `৳${totalTaken.toLocaleString('en-IN')}`, color: '#DC2626' },
    { label: 'Balance Due', value: `৳${totalDue.toLocaleString('en-IN')}`, color: totalDue >= 0 ? '#16A34A' : '#DC2626' },
  ];

  metrics.forEach((m, idx) => {
    const x = 40 + idx * (boxW + 10);
    ctx.fillStyle = '#F1F5F9';
    ctx.strokeStyle = '#CBD5E1';
    ctx.beginPath();
    ctx.roundRect(x, metricY, boxW, boxH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#64748B';
    ctx.font = 'bold 13px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(m.label.toUpperCase(), x + 12, metricY + 26);

    ctx.fillStyle = m.color;
    ctx.font = 'bold 20px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(m.value, x + 12, metricY + 58);
  });

  // Dual Table Layout on Same Page (Rule 13: Scaled row height so ALL 31 days fit)
  const tablesY = 360;
  const tableHeight = 1220; // Available space for tables
  const halfWidth = (width - 80 - 20) / 2;
  const leftTableX = 40;
  const rightTableX = 40 + halfWidth + 20;

  // Determine row height dynamically based on max rows (max 31 days)
  const maxRows = Math.max(monthlyAttendance.length, monthlyPayments.length, 1);
  const rowHeight = Math.min(32, Math.max(22, Math.floor((tableHeight - 100) / (maxRows + 2))));

  // Left Table: Worked Days
  ctx.fillStyle = '#0F172A';
  ctx.beginPath();
  ctx.roundRect(leftTableX, tablesY, halfWidth, 38, [6, 6, 0, 0]);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('WORKED DAYS (HAZIRA)', leftTableX + 15, tablesY + 25);
  ctx.textAlign = 'right';
  ctx.fillText(`TOTAL: ${totalWorkedDays} DAYS`, leftTableX + halfWidth - 15, tablesY + 25);
  ctx.textAlign = 'left';

  // Subheaders
  ctx.fillStyle = '#E2E8F0';
  ctx.fillRect(leftTableX, tablesY + 38, halfWidth, 26);
  ctx.fillStyle = '#475569';
  ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('#', leftTableX + 10, tablesY + 56);
  ctx.fillText('DATE', leftTableX + 45, tablesY + 56);
  ctx.fillText('DAY', leftTableX + 175, tablesY + 56);
  ctx.textAlign = 'right';
  ctx.fillText('WAGE (BDT)', leftTableX + halfWidth - 15, tablesY + 56);
  ctx.textAlign = 'left';

  let currentY = tablesY + 64;
  monthlyAttendance.forEach((att, idx) => {
    ctx.fillStyle = idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC';
    ctx.fillRect(leftTableX, currentY, halfWidth, rowHeight);
    ctx.strokeStyle = '#E2E8F0';
    ctx.strokeRect(leftTableX, currentY, halfWidth, rowHeight);

    ctx.fillStyle = '#64748B';
    ctx.font = '12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(String(idx + 1), leftTableX + 10, currentY + rowHeight - 8);

    ctx.fillStyle = '#0F172A';
    ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(att.date, leftTableX + 45, currentY + rowHeight - 8);

    ctx.fillStyle = '#475569';
    ctx.font = '12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(getDayOfWeekEnglish(att.date), leftTableX + 175, currentY + rowHeight - 8);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#059669';
    ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(worker.dailyWage.toLocaleString('en-IN'), leftTableX + halfWidth - 15, currentY + rowHeight - 8);
    ctx.textAlign = 'left';

    currentY += rowHeight;
  });

  if (monthlyAttendance.length === 0) {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(leftTableX, currentY, halfWidth, 40);
    ctx.fillStyle = '#94A3B8';
    ctx.font = 'italic 14px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('No attendance recorded for this month', leftTableX + 20, currentY + 25);
    currentY += 40;
  }

  // Left table total bottom
  ctx.fillStyle = '#F1F5F9';
  ctx.fillRect(leftTableX, currentY, halfWidth, 32);
  ctx.strokeStyle = '#CBD5E1';
  ctx.strokeRect(leftTableX, currentY, halfWidth, 32);
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 13px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('Total Hazira:', leftTableX + 15, currentY + 21);
  ctx.textAlign = 'right';
  ctx.fillText(`৳ ${haziraEarnings.toLocaleString('en-IN')}`, leftTableX + halfWidth - 15, currentY + 21);
  ctx.textAlign = 'left';

  // Right Table: Money Taken
  ctx.fillStyle = '#0F172A';
  ctx.beginPath();
  ctx.roundRect(rightTableX, tablesY, halfWidth, 38, [6, 6, 0, 0]);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('MONEY TAKEN (PAYMENTS)', rightTableX + 15, tablesY + 25);
  ctx.textAlign = 'right';
  ctx.fillText(`TOTAL: ৳ ${totalTaken.toLocaleString('en-IN')}`, rightTableX + halfWidth - 15, tablesY + 25);
  ctx.textAlign = 'left';

  // Subheaders
  ctx.fillStyle = '#E2E8F0';
  ctx.fillRect(rightTableX, tablesY + 38, halfWidth, 26);
  ctx.fillStyle = '#475569';
  ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('#', rightTableX + 10, tablesY + 56);
  ctx.fillText('DATE', rightTableX + 45, tablesY + 56);
  ctx.fillText('DETAILS / NOTE', rightTableX + 165, tablesY + 56);
  ctx.textAlign = 'right';
  ctx.fillText('AMOUNT (BDT)', rightTableX + halfWidth - 15, tablesY + 56);
  ctx.textAlign = 'left';

  let rightY = tablesY + 64;
  monthlyPayments.forEach((p, idx) => {
    ctx.fillStyle = idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC';
    ctx.fillRect(rightTableX, rightY, halfWidth, rowHeight);
    ctx.strokeStyle = '#E2E8F0';
    ctx.strokeRect(rightTableX, rightY, halfWidth, rowHeight);

    ctx.fillStyle = '#64748B';
    ctx.font = '12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(String(idx + 1), rightTableX + 10, rightY + rowHeight - 8);

    ctx.fillStyle = '#0F172A';
    ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(p.date, rightTableX + 45, rightY + rowHeight - 8);

    ctx.fillStyle = '#475569';
    ctx.font = '12px "Plus Jakarta Sans", sans-serif';
    const noteText = p.note || 'Cash payment';
    ctx.fillText(noteText.length > 22 ? noteText.slice(0, 20) + '...' : noteText, rightTableX + 165, rightY + rowHeight - 8);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#DC2626';
    ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(p.amount.toLocaleString('en-IN'), rightTableX + halfWidth - 15, rightY + rowHeight - 8);
    ctx.textAlign = 'left';

    rightY += rowHeight;
  });

  if (monthlyPayments.length === 0) {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(rightTableX, rightY, halfWidth, 40);
    ctx.fillStyle = '#94A3B8';
    ctx.font = 'italic 14px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('No payments recorded for this month', rightTableX + 20, rightY + 25);
    rightY += 40;
  }

  // Right table total bottom
  ctx.fillStyle = '#F1F5F9';
  ctx.fillRect(rightTableX, rightY, halfWidth, 32);
  ctx.strokeStyle = '#CBD5E1';
  ctx.strokeRect(rightTableX, rightY, halfWidth, 32);
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 13px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('Total Taken:', rightTableX + 15, currentY + 21);
  ctx.textAlign = 'right';
  ctx.fillText(`৳ ${totalTaken.toLocaleString('en-IN')}`, rightTableX + halfWidth - 15, currentY + 21);
  ctx.textAlign = 'left';

  // Single page statement footer
  ctx.fillStyle = '#94A3B8';
  ctx.font = '12px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(
    `Generated by SUJON MASTER App — Confidential Worker Ledger Statement — Page 1 of 1`,
    width / 2,
    height - 35
  );
  ctx.textAlign = 'left';

  // Convert canvas to image and add to jsPDF
  const imgData = canvas.toDataURL('image/jpeg', 0.95);
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();
  pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
  pdf.save(`Worker_${worker.name}_${monthNameEn}_${year}.pdf`);
};

/**
 * Site PDF Generator
 * RULE 12: in Bengali ONLY, and contains ONLY the date-wise received/cash list plus total received.
 * NO total bill, NO due, NO progress, NO start date, NO expenses, NO other sites, NO workers.
 * Correct "পৃষ্ঠা X / Y" footer on every page (30 rows per page for sites; total only on the last page).
 */
export const generateSitePdf = async (
  site: Site,
  sitePayments: SitePayment[]
): Promise<void> => {
  // Sort payments by date
  const payments = sitePayments
    .filter((p) => p.siteId === site.id)
    .sort((a, b) => a.date.localeCompare(b.date));

  const totalReceived = payments.reduce((sum, p) => sum + p.amount, 0);

  const rowsPerPage = 30;
  const totalPages = Math.max(1, Math.ceil(payments.length / rowsPerPage));

  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();

  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    if (pageNum > 1) {
      pdf.addPage();
    }

    const startIndex = (pageNum - 1) * rowsPerPage;
    const pagePayments = payments.slice(startIndex, startIndex + rowsPerPage);
    const isLastPage = pageNum === totalPages;

    const canvas = document.createElement('canvas');
    const width = 1200;
    const height = 1700;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;

    // Background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);

    // Header banner
    ctx.fillStyle = '#0F766E';
    ctx.fillRect(40, 40, width - 80, 115);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 36px "Hind Siliguri", sans-serif';
    ctx.fillText('সুজন মাস্টার — সাইট পাওয়া টাকার হিসাব', 65, 95);

    ctx.font = '500 22px "Hind Siliguri", sans-serif';
    ctx.fillStyle = '#CCFBF1';
    ctx.fillText(`সাইট: ${site.name}`, 65, 130);

    // Table Header
    const tableY = 185;
    const tableWidth = width - 80;
    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    ctx.roundRect(40, tableY, tableWidth, 42, [8, 8, 0, 0]);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 18px "Hind Siliguri", sans-serif';
    ctx.fillText('ক্রম', 60, tableY + 28);
    ctx.fillText('তারিখ', 130, tableY + 28);
    ctx.fillText('বিবরণ / কিস্তি', 400, tableY + 28);
    ctx.textAlign = 'right';
    ctx.fillText('পাওয়া টাকা (৳)', width - 65, tableY + 28);
    ctx.textAlign = 'left';

    let currentY = tableY + 42;
    const rowHeight = 36;

    pagePayments.forEach((p, idx) => {
      const globalIdx = startIndex + idx + 1;
      ctx.fillStyle = idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC';
      ctx.fillRect(40, currentY, tableWidth, rowHeight);
      ctx.strokeStyle = '#E2E8F0';
      ctx.strokeRect(40, currentY, tableWidth, rowHeight);

      ctx.fillStyle = '#64748B';
      ctx.font = '16px "Hind Siliguri", sans-serif';
      ctx.fillText(toBengaliNumber(globalIdx), 60, currentY + 24);

      ctx.fillStyle = '#0F172A';
      ctx.font = 'bold 16px "Hind Siliguri", sans-serif';
      ctx.fillText(formatBengaliDate(p.date), 130, currentY + 24);

      ctx.fillStyle = '#334155';
      ctx.font = '16px "Hind Siliguri", sans-serif';
      const detailStr = p.details || 'নগদ গ্রহণ';
      ctx.fillText(detailStr, 400, currentY + 24);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#0F766E';
      ctx.font = 'bold 18px "Hind Siliguri", sans-serif';
      ctx.fillText(formatTaka(p.amount), width - 65, currentY + 24);
      ctx.textAlign = 'left';

      currentY += rowHeight;
    });

    if (pagePayments.length === 0) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(40, currentY, tableWidth, 50);
      ctx.fillStyle = '#94A3B8';
      ctx.font = 'italic 18px "Hind Siliguri", sans-serif';
      ctx.fillText('কোনো পাওয়া টাকার এন্ট্রি নেই', 60, currentY + 32);
      currentY += 50;
    }

    // Total only on the last page (Rule 12)
    if (isLastPage) {
      currentY += 15;
      ctx.fillStyle = '#042F2E';
      ctx.beginPath();
      ctx.roundRect(40, currentY, tableWidth, 52, 8);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 22px "Hind Siliguri", sans-serif';
      ctx.fillText('সর্বমোট পাওয়া টাকা:', 65, currentY + 34);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#2DD4BF';
      ctx.font = 'bold 26px "Hind Siliguri", sans-serif';
      ctx.fillText(formatTaka(totalReceived), width - 65, currentY + 34);
      ctx.textAlign = 'left';
    }

    // Footer with Rule 12 requirement: "পৃষ্ঠা X / Y"
    ctx.fillStyle = '#64748B';
    ctx.font = '16px "Hind Siliguri", sans-serif';
    ctx.textAlign = 'center';
    const footerText = `পৃষ্ঠা ${toBengaliNumber(pageNum)} / ${toBengaliNumber(totalPages)}`;
    ctx.fillText(footerText, width / 2, height - 40);
    ctx.textAlign = 'left';

    const pageImg = canvas.toDataURL('image/jpeg', 0.95);
    pdf.addImage(pageImg, 'JPEG', 0, 0, pdfWidth, pdfHeight);
  }

  pdf.save(`Site_${site.name}_Received_List.pdf`);
};
