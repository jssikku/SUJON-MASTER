import {
  DailyEntry,
  Worker,
  AttendanceRecord,
  OvertimeRecord,
  WorkerPayment,
  Site,
  SitePayment,
  SiteExpense,
  NoteItem,
  PriceItem,
  AppSettings,
  BackupData,
  CloudBackupMetadata,
} from '../types';

const STORAGE_KEYS = {
  DAILY: 'sujon_daily_entries',
  WORKERS: 'sujon_workers',
  ATTENDANCE: 'sujon_attendance',
  OVERTIME: 'sujon_overtime',
  WORKER_PAYMENTS: 'sujon_worker_payments',
  SITES: 'sujon_sites',
  SITE_PAYMENTS: 'sujon_site_payments',
  SITE_EXPENSES: 'sujon_site_expenses',
  NOTES: 'sujon_notes',
  PRICES: 'sujon_prices',
  SETTINGS: 'sujon_settings',
  INITIALIZED: 'sujon_seed_initialized_v1',
  CLOUD_BACKUP: 'sujon_cloud_backup_data',
  CLOUD_META: 'sujon_cloud_backup_meta',
};

export const defaultSettings: AppSettings = {
  theme: 'ocean',
  language: 'bn',
  hideMoney: false,
  pinLockEnabled: false,
  pinCode: '',
  seedInitialized: false,
};

// Initial Seed Data
const getInitialSeed = () => {
  const workers: Worker[] = [
    { id: 'w-rahim', name: 'Rahim', role: 'মিস্ত্রি', dailyWage: 900, createdAt: 1729000000000 },
    { id: 'w-karim', name: 'Karim', role: 'মিস্ত্রি', dailyWage: 850, createdAt: 1729000000001 },
    { id: 'w-salam', name: 'Salam', role: 'হেলপার', dailyWage: 550, createdAt: 1729000000002 },
    { id: 'w-jamal', name: 'Jamal', role: 'হেলপার', dailyWage: 500, createdAt: 1729000000003 },
  ];

  // Salam: 19 days in October 2026 (Oct 1..19) -> 19 * 550 = 10,450. Payments 9,550. Due = 900
  const attendance: AttendanceRecord[] = [];
  for (let d = 1; d <= 19; d++) {
    attendance.push({
      id: `att-salam-${d}`,
      workerId: 'w-salam',
      date: `2026-10-${String(d).padStart(2, '0')}`,
    });
  }

  // Jamal: 12 days in October 2026 (Oct 1..12) -> 12 * 500 = 6,000. Payments 6,000. Due = 0
  for (let d = 1; d <= 12; d++) {
    attendance.push({
      id: `att-jamal-${d}`,
      workerId: 'w-jamal',
      date: `2026-10-${String(d).padStart(2, '0')}`,
    });
  }

  const workerPayments: WorkerPayment[] = [
    {
      id: 'wp-salam-1',
      workerId: 'w-salam',
      date: '2026-10-10',
      amount: 3000,
      note: 'সাপ্তাহিক',
      createdAt: 1729000100000,
    },
    {
      id: 'wp-salam-2',
      workerId: 'w-salam',
      date: '2026-10-20',
      amount: 4000,
      note: 'সাপ্তাহিক',
      createdAt: 1729000200000,
    },
    {
      id: 'wp-salam-3',
      workerId: 'w-salam',
      date: '2026-10-28',
      amount: 2550,
      note: 'অগ্রিম',
      createdAt: 1729000300000,
    },
    {
      id: 'wp-jamal-1',
      workerId: 'w-jamal',
      date: '2026-10-15',
      amount: 3000,
      note: 'সাপ্তাহিক',
      createdAt: 1729000400000,
    },
    {
      id: 'wp-jamal-2',
      workerId: 'w-jamal',
      date: '2026-10-28',
      amount: 3000,
      note: 'হিসাব পরিশোধ',
      createdAt: 1729000500000,
    },
  ];

  const overtime: OvertimeRecord[] = [];

  const sites: Site[] = [
    {
      id: 's-dhanmondi',
      name: 'Dhanmondi Flat',
      type: 'ইলেক্ট্রিক + প্লাম্বিং',
      totalBill: 120000,
      startDate: '2026-10-10',
      createdAt: 1729000000000,
    },
    {
      id: 's-uttara',
      name: 'Uttara House',
      type: 'ইলেক্ট্রিক',
      totalBill: 50000,
      startDate: '2026-10-15',
      createdAt: 1729000000001,
    },
  ];

  const sitePayments: SitePayment[] = [
    {
      id: 'sp-dh-1',
      siteId: 's-dhanmondi',
      date: '2026-10-10',
      amount: 50000,
      details: '১ম কিস্তি অগ্রিম',
      createdAt: 1729000100000,
    },
    {
      id: 'sp-dh-2',
      siteId: 's-dhanmondi',
      date: '2026-10-25',
      amount: 35000,
      details: '২য় কিস্তি কাজ চলমান',
      createdAt: 1729000200000,
    },
    {
      id: 'sp-ut-1',
      siteId: 's-uttara',
      date: '2026-10-15',
      amount: 20000,
      details: 'কাজ শুরুর সময়',
      createdAt: 1729000300000,
    },
    {
      id: 'sp-ut-2',
      siteId: 's-uttara',
      date: '2026-10-28',
      amount: 11500,
      details: 'বোর্ডের কাজ সম্পন্ন',
      createdAt: 1729000400000,
    },
  ];

  const siteExpenses: SiteExpense[] = [
    {
      id: 'se-dh-1',
      siteId: 's-dhanmondi',
      date: '2026-10-12',
      category: 'কর্মী খরচ',
      workerCount: 2,
      details: 'কর্মী মজুরি ও নাস্তা',
      amount: 1500,
      createdAt: 1729000150000,
    },
    {
      id: 'se-dh-2',
      siteId: 's-dhanmondi',
      date: '2026-10-18',
      category: 'অন্যান্য খরচ',
      details: 'সাইট সামগ্রী পরিবহন ভ্যান ভাড়া',
      amount: 1200,
      createdAt: 1729000250000,
    },
    {
      id: 'se-ut-1',
      siteId: 's-uttara',
      date: '2026-10-16',
      category: 'কর্মী খরচ',
      workerCount: 1,
      details: 'ড্রিলিং হেলপার খরচ',
      amount: 1000,
      createdAt: 1729000350000,
    },
    {
      id: 'se-ut-2',
      siteId: 's-uttara',
      date: '2026-10-22',
      category: 'অন্যান্য খরচ',
      details: 'টেপ, স্ক্রু ও কাটিং ব্লেড',
      amount: 700,
      createdAt: 1729000450000,
    },
  ];

  const dailyEntries: DailyEntry[] = [
    {
      id: 'de-1',
      type: 'income',
      details: 'Site payment — Dhanmondi',
      amount: 8000,
      date: '2026-10-31',
      createdAt: 1730360000000,
    },
    {
      id: 'de-2',
      type: 'income',
      details: 'small work — fan fitting',
      amount: 4500,
      date: '2026-10-31',
      createdAt: 1730361000000,
    },
    {
      id: 'de-3',
      type: 'expense',
      details: 'cable and switch purchase',
      amount: 3200,
      date: '2026-10-31',
      createdAt: 1730362000000,
    },
  ];

  const prices: PriceItem[] = [
    {
      id: 'p-1',
      name: 'কেবল ১.৫ মিমি',
      category: 'ইলেক্ট্রিক',
      unit: 'প্রতি কয়েল',
      price: 3200,
      createdAt: 1729000000000,
    },
    {
      id: 'p-2',
      name: 'সুইচ + সকেট সেট',
      category: 'ইলেক্ট্রিক',
      unit: 'প্রতি পিস',
      price: 280,
      createdAt: 1729000000001,
    },
    {
      id: 'p-3',
      name: 'সিলিং ফ্যান (নমুনা)',
      category: 'ইলেক্ট্রিক',
      unit: 'প্রতি পিস',
      price: 3800,
      createdAt: 1729000000002,
    },
    {
      id: 'p-4',
      name: 'PVC পাইপ ৩/৪"',
      category: 'প্লাম্বিং',
      unit: 'প্রতি পিস',
      price: 450,
      createdAt: 1729000000003,
    },
    {
      id: 'p-5',
      name: 'এলবো ও টি ফিটিংস',
      category: 'প্লাম্বিং',
      unit: 'প্রতি সেট',
      price: 180,
      createdAt: 1729000000004,
    },
    {
      id: 'p-6',
      name: 'পানির ট্যাপ / কল',
      category: 'প্লাম্বিং',
      unit: 'প্রতি পিস',
      price: 950,
      createdAt: 1729000000005,
    },
    {
      id: 'p-7',
      name: 'কমোড সেট (বেসিক)',
      category: 'স্যানিটারি',
      unit: 'প্রতি সেট',
      price: 7500,
      createdAt: 1729000000006,
    },
    {
      id: 'p-8',
      name: 'বেসিন মিক্সার কল',
      category: 'স্যানিটারি',
      unit: 'প্রতি পিস',
      price: 2400,
      createdAt: 1729000000007,
    },
    {
      id: 'p-9',
      name: 'পি-ট্র্যাপ ও ওয়েস্ট পাইপ',
      category: 'স্যানিটারি',
      unit: 'প্রতি পিস',
      price: 650,
      createdAt: 1729000000008,
    },
  ];

  const notes: NoteItem[] = [
    {
      id: 'n-1',
      title: 'সাইটের মাপ',
      text: 'ধানমন্ডি ফ্ল্যাটের ডাইনিং স্পেসের ৬টি সুইচবোর্ড ও ২টি এসির পয়েন্ট চেক করতে হবে। পাইপ লেআউট ড্রয়িং সম্পন্ন।',
      createdAt: 1729000000000,
    },
  ];

  return {
    workers,
    attendance,
    overtime,
    workerPayments,
    sites,
    sitePayments,
    siteExpenses,
    dailyEntries,
    prices,
    notes,
  };
};

export class AppStorage {
  static initializeIfFresh(): void {
    const isInit = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
    if (!isInit) {
      const seed = getInitialSeed();
      localStorage.setItem(STORAGE_KEYS.WORKERS, JSON.stringify(seed.workers));
      localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(seed.attendance));
      localStorage.setItem(STORAGE_KEYS.OVERTIME, JSON.stringify(seed.overtime));
      localStorage.setItem(STORAGE_KEYS.WORKER_PAYMENTS, JSON.stringify(seed.workerPayments));
      localStorage.setItem(STORAGE_KEYS.SITES, JSON.stringify(seed.sites));
      localStorage.setItem(STORAGE_KEYS.SITE_PAYMENTS, JSON.stringify(seed.sitePayments));
      localStorage.setItem(STORAGE_KEYS.SITE_EXPENSES, JSON.stringify(seed.siteExpenses));
      localStorage.setItem(STORAGE_KEYS.DAILY, JSON.stringify(seed.dailyEntries));
      localStorage.setItem(STORAGE_KEYS.PRICES, JSON.stringify(seed.prices));
      localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(seed.notes));
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(defaultSettings));
      localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    }
  }

  // Workers
  static getWorkers(): Worker[] {
    const data = localStorage.getItem(STORAGE_KEYS.WORKERS);
    return data ? JSON.parse(data) : [];
  }

  static setWorkers(workers: Worker[]): void {
    localStorage.setItem(STORAGE_KEYS.WORKERS, JSON.stringify(workers));
  }

  // Attendance
  static getAttendance(): AttendanceRecord[] {
    const data = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
    return data ? JSON.parse(data) : [];
  }

  static setAttendance(records: AttendanceRecord[]): void {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(records));
  }

  // Overtime
  static getOvertime(): OvertimeRecord[] {
    const data = localStorage.getItem(STORAGE_KEYS.OVERTIME);
    return data ? JSON.parse(data) : [];
  }

  static setOvertime(records: OvertimeRecord[]): void {
    localStorage.setItem(STORAGE_KEYS.OVERTIME, JSON.stringify(records));
  }

  // Worker Payments
  static getWorkerPayments(): WorkerPayment[] {
    const data = localStorage.getItem(STORAGE_KEYS.WORKER_PAYMENTS);
    return data ? JSON.parse(data) : [];
  }

  static setWorkerPayments(payments: WorkerPayment[]): void {
    localStorage.setItem(STORAGE_KEYS.WORKER_PAYMENTS, JSON.stringify(payments));
  }

  // Daily
  static getDailyEntries(): DailyEntry[] {
    const data = localStorage.getItem(STORAGE_KEYS.DAILY);
    return data ? JSON.parse(data) : [];
  }

  static setDailyEntries(entries: DailyEntry[]): void {
    localStorage.setItem(STORAGE_KEYS.DAILY, JSON.stringify(entries));
  }

  // Sites
  static getSites(): Site[] {
    const data = localStorage.getItem(STORAGE_KEYS.SITES);
    return data ? JSON.parse(data) : [];
  }

  static setSites(sites: Site[]): void {
    localStorage.setItem(STORAGE_KEYS.SITES, JSON.stringify(sites));
  }

  // Site Payments
  static getSitePayments(): SitePayment[] {
    const data = localStorage.getItem(STORAGE_KEYS.SITE_PAYMENTS);
    return data ? JSON.parse(data) : [];
  }

  static setSitePayments(payments: SitePayment[]): void {
    localStorage.setItem(STORAGE_KEYS.SITE_PAYMENTS, JSON.stringify(payments));
  }

  // Site Expenses
  static getSiteExpenses(): SiteExpense[] {
    const data = localStorage.getItem(STORAGE_KEYS.SITE_EXPENSES);
    return data ? JSON.parse(data) : [];
  }

  static setSiteExpenses(expenses: SiteExpense[]): void {
    localStorage.setItem(STORAGE_KEYS.SITE_EXPENSES, JSON.stringify(expenses));
  }

  // Notes
  static getNotes(): NoteItem[] {
    const data = localStorage.getItem(STORAGE_KEYS.NOTES);
    return data ? JSON.parse(data) : [];
  }

  static setNotes(notes: NoteItem[]): void {
    localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(notes));
  }

  // Prices
  static getPrices(): PriceItem[] {
    const data = localStorage.getItem(STORAGE_KEYS.PRICES);
    return data ? JSON.parse(data) : [];
  }

  static setPrices(prices: PriceItem[]): void {
    localStorage.setItem(STORAGE_KEYS.PRICES, JSON.stringify(prices));
  }

  // Settings
  static getSettings(): AppSettings {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!data) return defaultSettings;
    try {
      return { ...defaultSettings, ...JSON.parse(data) };
    } catch {
      return defaultSettings;
    }
  }

  static setSettings(settings: AppSettings): void {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }

  // Export JSON Backup (Never includes PIN or PIN lock state)
  static exportBackup(): string {
    const settings = this.getSettings();
    const backup: BackupData = {
      version: '1.0.0-native',
      appName: 'SUJON ⚡ MASTER',
      appPackage: 'com.worksledger.app',
      exportDate: new Date().toISOString(),
      deviceInfo: 'Android Device (SUJON ⚡ MASTER Native)',
      workers: this.getWorkers(),
      attendance: this.getAttendance(),
      overtime: this.getOvertime(),
      workerPayments: this.getWorkerPayments(),
      dailyEntries: this.getDailyEntries(),
      sites: this.getSites(),
      sitePayments: this.getSitePayments(),
      siteExpenses: this.getSiteExpenses(),
      notes: this.getNotes(),
      prices: this.getPrices(),
      settings: {
        theme: settings.theme,
        language: settings.language,
        hideMoney: settings.hideMoney,
      },
    };
    return JSON.stringify(backup, null, 2);
  }

  // Cloud Backup Simulation & Persistence (Drive appDataFolder)
  static saveToCloudStorage(backupJson: string): CloudBackupMetadata {
    localStorage.setItem(STORAGE_KEYS.CLOUD_BACKUP, backupJson);
    const sizeBytes = new Blob([backupJson]).size;
    const meta: CloudBackupMetadata = {
      id: 'drive-appdata-sujon-' + Date.now(),
      filename: 'sujon_master_backup.json',
      modifiedTime: Date.now(),
      sizeBytes,
      deviceInfo: 'Google Drive (appDataFolder)',
      version: '1.0.0-native',
    };
    localStorage.setItem(STORAGE_KEYS.CLOUD_META, JSON.stringify(meta));
    return meta;
  }

  static getCloudBackup(): { json: string | null; meta: CloudBackupMetadata | null } {
    const json = localStorage.getItem(STORAGE_KEYS.CLOUD_BACKUP);
    const metaStr = localStorage.getItem(STORAGE_KEYS.CLOUD_META);
    const meta = metaStr ? (JSON.parse(metaStr) as CloudBackupMetadata) : null;
    return { json, meta };
  }

  static clearCloudSession(): void {
    const current = this.getSettings();
    this.setSettings({
      ...current,
      googleAccount: undefined,
    });
  }

  // Restore JSON Backup (PIN is never read from backup)
  static restoreBackup(jsonString: string): boolean {
    try {
      const data: BackupData = JSON.parse(jsonString);
      if (!data.version || !Array.isArray(data.workers) || !Array.isArray(data.dailyEntries)) {
        throw new Error('Invalid backup format');
      }

      this.setWorkers(data.workers);
      this.setAttendance(data.attendance ?? []);
      this.setOvertime(data.overtime ?? []);
      this.setWorkerPayments(data.workerPayments ?? []);
      this.setDailyEntries(data.dailyEntries);
      this.setSites(data.sites ?? []);
      this.setSitePayments(data.sitePayments ?? []);
      this.setSiteExpenses(data.siteExpenses ?? []);
      this.setNotes(data.notes ?? []);
      this.setPrices(data.prices ?? []);

      // Keep current PIN lock intact, but restore theme, language, and hideMoney
      const currentSettings = this.getSettings();
      this.setSettings({
        ...currentSettings,
        theme: data.settings?.theme ?? currentSettings.theme,
        language: data.settings?.language ?? currentSettings.language,
        hideMoney: data.settings?.hideMoney ?? currentSettings.hideMoney,
      });

      return true;
    } catch (e) {
      console.error('Failed to restore backup:', e);
      return false;
    }
  }
}
