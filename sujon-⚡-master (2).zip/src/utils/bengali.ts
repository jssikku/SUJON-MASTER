/**
 * Bengali numbers and date utilities for SUJON ⚡ MASTER
 */

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
const ENGLISH_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

export const toBengaliNumber = (num: number | string | undefined | null): string => {
  if (num === undefined || num === null) return '০';
  const str = num.toString();
  return str.replace(/[0-9]/g, (d) => BENGALI_DIGITS[parseInt(d, 10)] ?? d);
};

export const toEnglishNumber = (str: string): string => {
  return str.replace(/[০-৯]/g, (d) => {
    const idx = BENGALI_DIGITS.indexOf(d);
    return idx !== -1 ? ENGLISH_DIGITS[idx] : d;
  });
};

export const formatTaka = (amount: number, hideMoney: boolean = false): string => {
  if (hideMoney) {
    return '৳ ••••';
  }
  const formatted = Math.abs(amount).toLocaleString('en-IN');
  const bnFormatted = toBengaliNumber(formatted);
  return amount < 0 ? `- ৳ ${bnFormatted}` : `৳ ${bnFormatted}`;
};

export const formatTakaWithoutSymbol = (amount: number, hideMoney: boolean = false): string => {
  if (hideMoney) {
    return '••••';
  }
  const formatted = Math.abs(amount).toLocaleString('en-IN');
  return toBengaliNumber(formatted);
};

export const BENGALI_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

export const ENGLISH_MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const BENGALI_DAYS = [
  'রবিবার',
  'সোমবার',
  'মঙ্গলবার',
  'বুধবার',
  'বৃহস্পতিবার',
  'শুক্রবার',
  'শনিবার',
];

export const getTodayDateString = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const formatBengaliDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const [yearStr, monthStr, dayStr] = dateStr.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10) - 1;
  const day = parseInt(dayStr, 10);
  
  if (isNaN(year) || isNaN(month) || isNaN(day)) return dateStr;
  
  const bnDay = toBengaliNumber(day);
  const bnMonth = BENGALI_MONTHS[month] ?? '';
  const bnYear = toBengaliNumber(year);
  
  return `${bnDay} ${bnMonth} ${bnYear}`;
};

export const formatFullBengaliDateWithDay = (dateStr: string): string => {
  if (!dateStr) return '';
  const [yearStr, monthStr, dayStr] = dateStr.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10) - 1;
  const day = parseInt(dayStr, 10);
  
  const d = new Date(year, month, day);
  const weekday = BENGALI_DAYS[d.getDay()] ?? '';
  const dateFormatted = formatBengaliDate(dateStr);
  
  return `${weekday}, ${dateFormatted}`;
};

export const getDayOfWeekBengali = (dateStr: string): string => {
  if (!dateStr) return '';
  const [yearStr, monthStr, dayStr] = dateStr.split('-');
  const d = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, parseInt(dayStr, 10));
  return BENGALI_DAYS[d.getDay()] ?? '';
};

export const getDayOfWeekEnglish = (dateStr: string): string => {
  if (!dateStr) return '';
  const [yearStr, monthStr, dayStr] = dateStr.split('-');
  const d = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, parseInt(dayStr, 10));
  return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d.getDay()] ?? '';
};

export const getDaysInMonth = (year: number, monthIndex: number): number => {
  return new Date(year, monthIndex + 1, 0).getDate();
};

export const getFirstDayOfMonth = (year: number, monthIndex: number): number => {
  return new Date(year, monthIndex, 1).getDay();
};
