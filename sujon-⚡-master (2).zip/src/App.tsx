import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { OverviewScreen } from './components/overview/OverviewScreen';
import { DailyScreen } from './components/daily/DailyScreen';
import { TeamScreen } from './components/team/TeamScreen';
import { WorkerStatementScreen } from './components/team/WorkerStatementScreen';
import { SitesScreen } from './components/sites/SitesScreen';
import { SiteDetailScreen } from './components/sites/SiteDetailScreen';
import { NotesScreen } from './components/notes/NotesScreen';
import { PhotoEditor } from './components/notes/PhotoEditor';
import { PricesScreen } from './components/prices/PricesScreen';
import { MonthlyHisabScreen } from './components/monthly/MonthlyHisabScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';
import { LockScreen } from './components/lock/LockScreen';
import { BottomNav } from './components/common/BottomNav';

const MainContent: React.FC = () => {
  const { screen, isLocked, toast } = useApp();

  if (isLocked) {
    return <LockScreen />;
  }

  const renderCurrentScreen = () => {
    switch (screen.type) {
      case 'monthly-hisab':
        return <MonthlyHisabScreen />;
      case 'worker-statement':
        return (
          <WorkerStatementScreen
            workerId={screen.workerId}
            initialDate={screen.initialDate}
          />
        );
      case 'site-detail':
        return <SiteDetailScreen siteId={screen.siteId} />;
      case 'photo-editor':
        return <PhotoEditor noteId={screen.noteId} />;
      case 'settings':
        return <SettingsScreen />;
      case 'main':
      default:
        switch (screen.tab) {
          case 'daily':
            return <DailyScreen />;
          case 'team':
            return <TeamScreen />;
          case 'sites':
            return <SitesScreen />;
          case 'notes':
            return <NotesScreen />;
          case 'prices':
            return <PricesScreen />;
          case 'overview':
          default:
            return <OverviewScreen />;
        }
    }
  };

  return (
    <div className="min-h-screen bg-[#FFF8F1] text-[#1D1A18] font-['Hind_Siliguri',sans-serif] flex flex-col justify-between max-w-md mx-auto shadow-2xl relative overflow-x-hidden selection:bg-[#009E8F] selection:text-white">
      {/* Toast Notification Container */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 max-w-xs w-full px-4 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="bg-[#1D1A18] text-white px-4 py-2.5 rounded-2xl shadow-xl text-center text-xs font-bold border border-white/10 tracking-wide">
            {toast.text}
          </div>
        </div>
      )}

      {/* Screen Body */}
      <div className="flex-1 w-full">
        {renderCurrentScreen()}
      </div>

      {/* Bottom Nav on main tabs only */}
      <BottomNav />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
