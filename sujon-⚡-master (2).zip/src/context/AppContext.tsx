import React, { createContext, useContext, useState, useEffect, useMemo, useRef, ReactNode } from 'react';
import {
  DailyEntry,
  Worker,
  AttendanceRecord,
  OvertimeRecord,
  WorkerPayment,
  Site,
  SitePayment,
  SiteExpense,
  NoteItem,
  PriceItem,
  AppSettings,
  ThemeMode,
  Language,
  CloudBackupMetadata,
} from '../types';
import { AppStorage, defaultSettings } from '../utils/storage';
import { getTodayDateString, formatTaka } from '../utils/bengali';

export type ActiveScreen =
  | { type: 'main'; tab: 'overview' | 'daily' | 'team' | 'sites' | 'notes' | 'prices' }
  | { type: 'monthly-hisab' }
  | { type: 'worker-statement'; workerId: string; initialDate?: string }
  | { type: 'site-detail'; siteId: string }
  | { type: 'photo-editor'; noteId: string }
  | { type: 'settings' };

export interface ToastMessage {
  id: string;
  text: string;
}

interface AppContextType {
  screen: ActiveScreen;
  setScreen: (screen: ActiveScreen) => void;
  goBack: () => void;
  isLocked: boolean;
  unlockWithPin: (pin: string) => boolean;
  lockNow: () => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  hideMoney: boolean;
  setHideMoney: (hide: boolean) => void;
  toggleHideMoney: () => void;
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  
  // Daily Entries
  dailyEntries: DailyEntry[];
  addDailyEntry: (entry: Omit<DailyEntry, 'id' | 'createdAt'>) => void;
  deleteDailyEntry: (id: string) => void;

  // Shared computed balance
  totalBalance: number;
  todayIncome: number;
  todayExpense: number;

  // Workers & Hazira
  workers: Worker[];
  attendance: AttendanceRecord[];
  overtime: OvertimeRecord[];
  workerPayments: WorkerPayment[];
  addWorker: (name: string, role: 'মিস্ত্রি' | 'হেলপার', dailyWage: number) => { success: boolean; message?: string };
  deleteWorker: (id: string) => void;
  toggleAttendance: (workerId: string, date: string) => void;
  setWorkerOvertime: (workerId: string, date: string, amount: number) => void;
  deleteWorkerOvertime: (workerId: string, date: string) => void;
  addWorkerPayment: (workerId: string, date: string, amount: number, note: string) => void;
  deleteWorkerPayment: (paymentId: string) => void;

  // Sites
  sites: Site[];
  sitePayments: SitePayment[];
  siteExpenses: SiteExpense[];
  addSite: (name: string, type: string, totalBill: number, startDate: string, firstPayment?: number) => { success: boolean; message?: string };
  deleteSite: (id: string) => void;
  addSitePayment: (siteId: string, date: string, amount: number, details: string) => void;
  deleteSitePayment: (paymentId: string) => void;
  addSiteExpense: (siteId: string, date: string, category: 'কর্মী খরচ' | 'অন্যান্য খরচ', details: string, amount: number, workerCount?: number) => void;
  deleteSiteExpense: (expenseId: string) => void;

  // Notes
  notes: NoteItem[];
  addNote: (title: string, text: string, photoUrl?: string) => void;
  updateNotePhoto: (id: string, photoUrl: string) => void;
  deleteNote: (id: string) => void;

  // Prices
  prices: PriceItem[];
  addPriceItem: (name: string, category: 'ইলেক্ট্রিক' | 'প্লাম্বিং' | 'স্যানিটারি', unit: string, price: number) => { success: boolean; message?: string };
  deletePriceItem: (id: string) => void;

  // Toasts
  toast: ToastMessage | null;
  showToast: (text: string) => void;
  
  // Backup & Restore
  exportBackupData: () => string;
  restoreBackupData: (json: string) => boolean;

  // Google Cloud Backup / Sync
  googleAccount?: AppSettings['googleAccount'];
  isSyncing: boolean;
  cloudMetadata: CloudBackupMetadata | null;
  cloudConflict: CloudBackupMetadata | null;
  signInWithGoogle: (email?: string) => Promise<boolean>;
  signOutGoogle: () => void;
  uploadToCloud: (silent?: boolean) => Promise<{ success: boolean; message?: string }>;
  restoreFromCloud: () => Promise<boolean>;
  toggleAutoSync: () => void;
  ignoreConflict: () => void;

  // Theme Gradients CSS helper
  themeStyles: {
    heroGradient: string;
    headerGradient: string;
    accentColor: string;
    pillBg: string;
    primaryBtn: string;
  };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Initialize storage seeds once
  AppStorage.initializeIfFresh();

  const [screen, setScreen] = useState<ActiveScreen>({ type: 'main', tab: 'overview' });
  const [screenHistory, setScreenHistory] = useState<ActiveScreen[]>([]);
  const [settings, setSettingsState] = useState<AppSettings>(() => AppStorage.getSettings());
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    const s = AppStorage.getSettings();
    return s.pinLockEnabled && !!s.pinCode;
  });

  // Google Cloud Sync states
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [cloudMetadata, setCloudMetadata] = useState<CloudBackupMetadata | null>(() => {
    return AppStorage.getCloudBackup().meta;
  });
  const [cloudConflict, setCloudConflict] = useState<CloudBackupMetadata | null>(null);
  const autoSyncTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isFirstRenderRef = useRef<boolean>(true);

  // Data states
  const [workers, setWorkers] = useState<Worker[]>(() => AppStorage.getWorkers());
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => AppStorage.getAttendance());
  const [overtime, setOvertime] = useState<OvertimeRecord[]>(() => AppStorage.getOvertime());
  const [workerPayments, setWorkerPayments] = useState<WorkerPayment[]>(() => AppStorage.getWorkerPayments());
  const [dailyEntries, setDailyEntries] = useState<DailyEntry[]>(() => AppStorage.getDailyEntries());
  const [sites, setSites] = useState<Site[]>(() => AppStorage.getSites());
  const [sitePayments, setSitePayments] = useState<SitePayment[]>(() => AppStorage.getSitePayments());
  const [siteExpenses, setSiteExpenses] = useState<SiteExpense[]>(() => AppStorage.getSiteExpenses());
  const [notes, setNotes] = useState<NoteItem[]>(() => AppStorage.getNotes());
  const [prices, setPrices] = useState<PriceItem[]>(() => AppStorage.getPrices());

  const [toast, setToast] = useState<ToastMessage | null>(null);

  const showToast = (text: string) => {
    const id = Math.random().toString();
    setToast({ id, text });
    setTimeout(() => {
      setToast((cur) => (cur?.id === id ? null : cur));
    }, 2800);
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettingsState(updated);
    AppStorage.setSettings(updated);
  };

  const setTheme = (theme: ThemeMode) => updateSettings({ theme });
  const setLanguage = (language: Language) => updateSettings({ language });
  const setHideMoney = (hideMoney: boolean) => updateSettings({ hideMoney });
  const toggleHideMoney = () => setHideMoney(!settings.hideMoney);

  const unlockWithPin = (pin: string): boolean => {
    if (pin === settings.pinCode) {
      setIsLocked(false);
      return true;
    }
    return false;
  };

  const lockNow = () => {
    if (settings.pinLockEnabled && settings.pinCode) {
      setIsLocked(true);
    }
  };

  const navigateTo = (newScreen: ActiveScreen) => {
    setScreenHistory((prev) => [...prev, screen]);
    setScreen(newScreen);
  };

  const goBack = () => {
    if (screenHistory.length > 0) {
      const prev = screenHistory[screenHistory.length - 1];
      setScreenHistory((history) => history.slice(0, history.length - 1));
      setScreen(prev);
    } else {
      setScreen({ type: 'main', tab: 'overview' });
    }
  };

  // Shared calculation for balance and today's income/expense
  const { totalBalance, todayIncome, todayExpense } = useMemo(() => {
    const today = getTodayDateString();
    let balance = 0;
    let tIncome = 0;
    let tExpense = 0;

    dailyEntries.forEach((entry) => {
      if (entry.type === 'income') {
        balance += entry.amount;
        if (entry.date === today) {
          tIncome += entry.amount;
        }
      } else {
        balance -= entry.amount;
        if (entry.date === today) {
          tExpense += entry.amount;
        }
      }
    });

    return { totalBalance: balance, todayIncome: tIncome, todayExpense: tExpense };
  }, [dailyEntries]);

  // DAILY ENTRIES
  const addDailyEntry = (entry: Omit<DailyEntry, 'id' | 'createdAt'>) => {
    const newEntry: DailyEntry = {
      ...entry,
      id: 'de-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
      createdAt: Date.now(),
    };
    const updated = [newEntry, ...dailyEntries];
    setDailyEntries(updated);
    AppStorage.setDailyEntries(updated);

    // Rule 10: Toasts hide amount when eye-hide is ON!
    if (settings.hideMoney) {
      showToast(entry.type === 'income' ? 'আয় যোগ হয়েছে' : 'খরচ যোগ হয়েছে');
    } else {
      showToast(`${entry.type === 'income' ? 'আয়' : 'খরচ'} যোগ হয়েছে: ${formatTaka(entry.amount)}`);
    }
  };

  const deleteDailyEntry = (id: string) => {
    const updated = dailyEntries.filter((e) => e.id !== id);
    setDailyEntries(updated);
    AppStorage.setDailyEntries(updated);
    showToast('এন্ট্রি মুছে ফেলা হয়েছে');
  };

  // WORKERS
  const addWorker = (name: string, role: 'মিস্ত্রি' | 'হেলপার', dailyWage: number) => {
    const trimmed = name.trim();
    if (!trimmed) return { success: false, message: 'নাম লিখুন' };
    if (workers.some((w) => w.name.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, message: 'এই নামের কর্মী ইতোমধ্যে যুক্ত আছে' };
    }
    const newWorker: Worker = {
      id: 'w-' + Date.now(),
      name: trimmed,
      role,
      dailyWage,
      createdAt: Date.now(),
    };
    const updated = [...workers, newWorker];
    setWorkers(updated);
    AppStorage.setWorkers(updated);
    showToast('কর্মী যোগ হয়েছে');
    return { success: true };
  };

  // Rule 8: When worker deleted, delete attendance, OT, payments too. List is authoritative!
  const deleteWorker = (id: string) => {
    const updatedWorkers = workers.filter((w) => w.id !== id);
    const updatedAtt = attendance.filter((a) => a.workerId !== id);
    const updatedOt = overtime.filter((o) => o.workerId !== id);
    const updatedPayments = workerPayments.filter((p) => p.workerId !== id);

    setWorkers(updatedWorkers);
    setAttendance(updatedAtt);
    setOvertime(updatedOt);
    setWorkerPayments(updatedPayments);

    AppStorage.setWorkers(updatedWorkers);
    AppStorage.setAttendance(updatedAtt);
    AppStorage.setOvertime(updatedOt);
    AppStorage.setWorkerPayments(updatedPayments);

    showToast('কর্মী ও সকল হিসাব মুছে ফেলা হয়েছে');
  };

  // Rule 5: Mark present toggles on/off. NEVER pre-mark.
  const toggleAttendance = (workerId: string, date: string) => {
    const existing = attendance.find((a) => a.workerId === workerId && a.date === date);
    let updated: AttendanceRecord[];
    if (existing) {
      updated = attendance.filter((a) => !(a.workerId === workerId && a.date === date));
    } else {
      updated = [...attendance, { id: 'att-' + Date.now(), workerId, date }];
    }
    setAttendance(updated);
    AppStorage.setAttendance(updated);
  };

  // Rule 6: Overtime is ONLY a blank manual box typed into, saved per date.
  const setWorkerOvertime = (workerId: string, date: string, amount: number) => {
    const existing = overtime.find((o) => o.workerId === workerId && o.date === date);
    let updated: OvertimeRecord[];
    if (amount <= 0) {
      updated = overtime.filter((o) => !(o.workerId === workerId && o.date === date));
    } else if (existing) {
      updated = overtime.map((o) => (o.workerId === workerId && o.date === date ? { ...o, amount } : o));
    } else {
      updated = [...overtime, { id: 'ot-' + Date.now(), workerId, date, amount }];
    }
    setOvertime(updated);
    AppStorage.setOvertime(updated);
    showToast('OT হিসাব সংরক্ষিত হয়েছে');
  };

  const deleteWorkerOvertime = (workerId: string, date: string) => {
    const updated = overtime.filter((o) => !(o.workerId === workerId && o.date === date));
    setOvertime(updated);
    AppStorage.setOvertime(updated);
    showToast('OT মুছে ফেলা হয়েছে');
  };

  // Worker Payment
  const addWorkerPayment = (workerId: string, date: string, amount: number, note: string) => {
    const newPayment: WorkerPayment = {
      id: 'wp-' + Date.now(),
      workerId,
      date,
      amount,
      note,
      createdAt: Date.now(),
    };
    const updated = [newPayment, ...workerPayments];
    setWorkerPayments(updated);
    AppStorage.setWorkerPayments(updated);
    showToast('টাকা প্রদান সংরক্ষিত হয়েছে');

    // Auto-open that worker's statement for the chosen date's month
    navigateTo({ type: 'worker-statement', workerId, initialDate: date });
  };

  const deleteWorkerPayment = (paymentId: string) => {
    const updated = workerPayments.filter((p) => p.id !== paymentId);
    setWorkerPayments(updated);
    AppStorage.setWorkerPayments(updated);
    showToast('টাকা প্রদানের রেকর্ড মুছে ফেলা হয়েছে');
  };

  // SITES
  const addSite = (name: string, type: string, totalBill: number, startDate: string, firstPayment?: number) => {
    const trimmed = name.trim();
    if (!trimmed) return { success: false, message: 'সাইটের নাম লিখুন' };
    if (sites.some((s) => s.name.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, message: 'এই নামের সাইট ইতোমধ্যে রয়েছে' };
    }
    const newSite: Site = {
      id: 's-' + Date.now(),
      name: trimmed,
      type: type || 'ইলেক্ট্রিক + প্লাম্বিং',
      totalBill: totalBill || 0,
      startDate: startDate || getTodayDateString(),
      createdAt: Date.now(),
    };
    const updatedSites = [newSite, ...sites];
    setSites(updatedSites);
    AppStorage.setSites(updatedSites);

    if (firstPayment && firstPayment > 0) {
      const firstPay: SitePayment = {
        id: 'sp-' + Date.now(),
        siteId: newSite.id,
        date: startDate || getTodayDateString(),
        amount: firstPayment,
        details: '১ম কিস্তি অগ্রিম',
        createdAt: Date.now(),
      };
      const updatedPayments = [firstPay, ...sitePayments];
      setSitePayments(updatedPayments);
      AppStorage.setSitePayments(updatedPayments);
    }

    showToast('নতুন সাইট খোলা হয়েছে');
    return { success: true };
  };

  const deleteSite = (id: string) => {
    const updatedSites = sites.filter((s) => s.id !== id);
    const updatedPayments = sitePayments.filter((p) => p.siteId !== id);
    const updatedExpenses = siteExpenses.filter((e) => e.siteId !== id);

    setSites(updatedSites);
    setSitePayments(updatedPayments);
    setSiteExpenses(updatedExpenses);

    AppStorage.setSites(updatedSites);
    AppStorage.setSitePayments(updatedPayments);
    AppStorage.setSiteExpenses(updatedExpenses);

    showToast('সাইট মুছে ফেলা হয়েছে');
  };

  const addSitePayment = (siteId: string, date: string, amount: number, details: string) => {
    const newPayment: SitePayment = {
      id: 'sp-' + Date.now(),
      siteId,
      date,
      amount,
      details,
      createdAt: Date.now(),
    };
    const updated = [newPayment, ...sitePayments];
    setSitePayments(updated);
    AppStorage.setSitePayments(updated);
    showToast('পাওয়া টাকা যোগ হয়েছে');
  };

  const deleteSitePayment = (paymentId: string) => {
    const updated = sitePayments.filter((p) => p.id !== paymentId);
    setSitePayments(updated);
    AppStorage.setSitePayments(updated);
    showToast('পেমেন্ট রেকর্ড মুছে ফেলা হয়েছে');
  };

  const addSiteExpense = (
    siteId: string,
    date: string,
    category: 'কর্মী খরচ' | 'অন্যান্য খরচ',
    details: string,
    amount: number,
    workerCount?: number
  ) => {
    const newExpense: SiteExpense = {
      id: 'se-' + Date.now(),
      siteId,
      date,
      category,
      details,
      amount,
      workerCount,
      createdAt: Date.now(),
    };
    const updated = [newExpense, ...siteExpenses];
    setSiteExpenses(updated);
    AppStorage.setSiteExpenses(updated);
    showToast('সাইটের খরচ যোগ হয়েছে');
  };

  const deleteSiteExpense = (expenseId: string) => {
    const updated = siteExpenses.filter((e) => e.id !== expenseId);
    setSiteExpenses(updated);
    AppStorage.setSiteExpenses(updated);
    showToast('খরচের রেকর্ড মুছে ফেলা হয়েছে');
  };

  // NOTES
  const addNote = (title: string, text: string, photoUrl?: string) => {
    let finalTitle = title.trim();
    if (!finalTitle) {
      finalTitle = `নোট ${notes.length + 1}`;
    }
    const newNote: NoteItem = {
      id: 'n-' + Date.now(),
      title: finalTitle,
      text: text.trim(),
      photoUrl,
      createdAt: Date.now(),
    };
    const updated = [newNote, ...notes];
    setNotes(updated);
    AppStorage.setNotes(updated);
    showToast('নোট যোগ হয়েছে');
  };

  const updateNotePhoto = (id: string, photoUrl: string) => {
    const updated = notes.map((n) => (n.id === id ? { ...n, photoUrl } : n));
    setNotes(updated);
    AppStorage.setNotes(updated);
    showToast('ড্রয়িং ও ছবি সংরক্ষিত হয়েছে');
  };

  const deleteNote = (id: string) => {
    const updated = notes.filter((n) => n.id !== id);
    setNotes(updated);
    AppStorage.setNotes(updated);
    showToast('নোট মুছে ফেলা হয়েছে');
  };

  // PRICES
  const addPriceItem = (name: string, category: 'ইলেক্ট্রিক' | 'প্লাম্বিং' | 'স্যানিটারি', unit: string, price: number) => {
    const trimmed = name.trim();
    if (!trimmed) return { success: false, message: 'পণ্যের নাম দিন' };
    if (prices.some((p) => p.name.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, message: 'এই পণ্যটি তালিকায় বিদ্যমান' };
    }
    const newItem: PriceItem = {
      id: 'p-' + Date.now(),
      name: trimmed,
      category,
      unit: unit || 'প্রতি পিস',
      price,
      createdAt: Date.now(),
    };
    const updated = [newItem, ...prices];
    setPrices(updated);
    AppStorage.setPrices(updated);
    showToast('নতুন পণ্য তালিকায় যোগ হয়েছে');
    return { success: true };
  };

  const deletePriceItem = (id: string) => {
    const updated = prices.filter((p) => p.id !== id);
    setPrices(updated);
    AppStorage.setPrices(updated);
    showToast('পণ্য মুছে ফেলা হয়েছে');
  };

  // BACKUP & RESTORE (OFFLINE JSON)
  const exportBackupData = () => {
    return AppStorage.exportBackup();
  };

  const restoreBackupData = (json: string): boolean => {
    const ok = AppStorage.restoreBackup(json);
    if (ok) {
      setWorkers(AppStorage.getWorkers());
      setAttendance(AppStorage.getAttendance());
      setOvertime(AppStorage.getOvertime());
      setWorkerPayments(AppStorage.getWorkerPayments());
      setDailyEntries(AppStorage.getDailyEntries());
      setSites(AppStorage.getSites());
      setSitePayments(AppStorage.getSitePayments());
      setSiteExpenses(AppStorage.getSiteExpenses());
      setNotes(AppStorage.getNotes());
      setPrices(AppStorage.getPrices());
      setSettingsState(AppStorage.getSettings());
      showToast('ব্যাকআপ সফলভাবে ফিরিয়ে আনা হয়েছে');
      return true;
    } else {
      showToast('ব্যাকআপ ফাইলটি সঠিক নয়');
      return false;
    }
  };

  // Check cloud backup on startup/mount for conflict (Rule 6: Never auto-overwrite local work)
  useEffect(() => {
    const { meta } = AppStorage.getCloudBackup();
    setCloudMetadata(meta);

    if (settings.googleAccount && meta) {
      const localLastSync = settings.googleAccount.lastSyncTime || 0;
      // If cloud was modified significantly after local last sync, notify user
      if (meta.modifiedTime > localLastSync + 5000 && localLastSync > 0) {
        setCloudConflict(meta);
      }
    }
  }, [settings.googleAccount?.email]);

  // GOOGLE CLOUD BACKUP & SYNC METHODS
  const signInWithGoogle = async (customEmail?: string): Promise<boolean> => {
    setIsSyncing(true);
    try {
      // Simulate OAuth connection delay
      await new Promise((r) => setTimeout(r, 600));

      const email = customEmail?.trim() || 'sumusikku@gmail.com';
      const existingCloud = AppStorage.getCloudBackup();

      const updatedAccount = {
        email,
        displayName: 'Sujon Contractor',
        lastSyncTime: existingCloud.meta?.modifiedTime || undefined,
        autoSyncEnabled: false,
      };

      updateSettings({ googleAccount: updatedAccount });
      setCloudMetadata(existingCloud.meta);

      // Check conflict if cloud backup already exists
      if (existingCloud.meta && existingCloud.meta.modifiedTime > 0) {
        setCloudConflict(existingCloud.meta);
      }

      showToast('Google দিয়ে সাইন-ইন সফল হয়েছে');
      return true;
    } catch (e) {
      showToast('সাইন-ইন হয়নি, পুনরায় চেষ্টা করুন');
      return false;
    } finally {
      setIsSyncing(false);
    }
  };

  const signOutGoogle = () => {
    AppStorage.clearCloudSession();
    const current = AppStorage.getSettings();
    setSettingsState(current);
    setCloudConflict(null);
    showToast('সাইন-আউট সম্পন্ন হয়েছে');
  };

  const uploadToCloud = async (silent = false): Promise<{ success: boolean; message?: string }> => {
    if (!navigator.onLine) {
      if (!silent) showToast('ইন্টারনেট নেই • অফলাইনে সংরক্ষিত');
      return { success: false, message: 'ইন্টারনেট নেই' };
    }

    setIsSyncing(true);
    try {
      // Small simulated Drive network upload
      await new Promise((r) => setTimeout(r, 700));

      const backupJson = AppStorage.exportBackup();
      const meta = AppStorage.saveToCloudStorage(backupJson);

      const now = Date.now();
      setCloudMetadata(meta);
      setCloudConflict(null);

      if (settings.googleAccount) {
        updateSettings({
          googleAccount: {
            ...settings.googleAccount,
            lastSyncTime: now,
          },
        });
      }

      if (!silent) {
        const timeStr = new Date(now).toLocaleTimeString('bn-BD', {
          hour: '2-digit',
          minute: '2-digit',
        });
        showToast(`ব্যাকআপ সফল হয়েছে • ${timeStr}`);
      }

      return { success: true };
    } catch (e) {
      if (!silent) showToast('ব্যাকআপ ব্যর্থ হয়েছে');
      return { success: false, message: 'ড্রাইভে ব্যাকআপ ব্যর্থ' };
    } finally {
      setIsSyncing(false);
    }
  };

  const restoreFromCloud = async (): Promise<boolean> => {
    setIsSyncing(true);
    try {
      await new Promise((r) => setTimeout(r, 800));

      const { json, meta } = AppStorage.getCloudBackup();
      if (!json || !meta) {
        showToast('ক্লাউডে কোনো ব্যাকআপ পাওয়া যায়নি');
        return false;
      }

      const ok = restoreBackupData(json);
      if (ok) {
        setCloudConflict(null);
        showToast('ক্লাউড থেকে হিসাব ফিরিয়ে আনা হয়েছে');
        return true;
      }
      return false;
    } catch {
      showToast('ক্লাউড ব্যাকআপ ফিরিয়ে আনা যায়নি');
      return false;
    } finally {
      setIsSyncing(false);
    }
  };

  const toggleAutoSync = () => {
    if (!settings.googleAccount) return;
    const newState = !settings.googleAccount.autoSyncEnabled;
    updateSettings({
      googleAccount: {
        ...settings.googleAccount,
        autoSyncEnabled: newState,
      },
    });
    showToast(newState ? 'অটো সিঙ্ক চালু করা হয়েছে' : 'অটো সিঙ্ক বন্ধ করা হয়েছে');
  };

  const ignoreConflict = () => {
    setCloudConflict(null);
  };

  // Rule 6: Auto-sync (when ON): after any data change, wait about 30 seconds debounced
  useEffect(() => {
    if (isFirstRenderRef.current) {
      isFirstRenderRef.current = false;
      return;
    }

    if (settings.googleAccount?.autoSyncEnabled) {
      if (autoSyncTimerRef.current) {
        clearTimeout(autoSyncTimerRef.current);
      }
      autoSyncTimerRef.current = setTimeout(() => {
        if (navigator.onLine) {
          uploadToCloud(true);
        }
      }, 30000); // 30 seconds debounced
    }

    return () => {
      if (autoSyncTimerRef.current) {
        clearTimeout(autoSyncTimerRef.current);
      }
    };
  }, [
    dailyEntries,
    workers,
    attendance,
    overtime,
    workerPayments,
    sites,
    sitePayments,
    siteExpenses,
    notes,
    prices,
  ]);

  // Dynamic Theme Gradients
  const themeStyles = useMemo(() => {
    switch (settings.theme) {
      case 'sunset':
        return {
          heroGradient: 'bg-gradient-to-r from-[#FF5A3C] via-[#FFB020] to-[#FF3D8A]',
          headerGradient: 'bg-gradient-to-r from-[#FF5A3C] via-[#FF8A29] to-[#FF3D8A]',
          accentColor: '#FF5A3C',
          pillBg: 'from-[#FF5A3C] to-[#FF3D8A]',
          primaryBtn: 'bg-gradient-to-r from-[#FF5A3C] to-[#FF3D8A] text-white shadow-md active:scale-[0.98]',
        };
      case 'leaf':
        return {
          heroGradient: 'bg-gradient-to-r from-[#16A34A] via-[#84CC16] to-[#009E8F]',
          headerGradient: 'bg-gradient-to-r from-[#16A34A] via-[#65A30D] to-[#009E8F]',
          accentColor: '#16A34A',
          pillBg: 'from-[#16A34A] to-[#009E8F]',
          primaryBtn: 'bg-gradient-to-r from-[#16A34A] to-[#009E8F] text-white shadow-md active:scale-[0.98]',
        };
      case 'ocean':
      default:
        return {
          heroGradient: 'bg-gradient-to-r from-[#009E8F] via-[#2563EB] to-[#00C2D1]',
          headerGradient: 'bg-gradient-to-r from-[#009E8F] via-[#1D4ED8] to-[#00C2D1]',
          accentColor: '#009E8F',
          pillBg: 'from-[#009E8F] to-[#00C2D1]',
          primaryBtn: 'bg-[#00B4B4] hover:bg-[#009E9E] text-white shadow-md active:scale-[0.98]',
        };
    }
  }, [settings.theme]);

  return (
    <AppContext.Provider
      value={{
        screen,
        setScreen: navigateTo,
        goBack,
        isLocked,
        unlockWithPin,
        lockNow,
        theme: settings.theme,
        setTheme,
        language: settings.language,
        setLanguage,
        hideMoney: settings.hideMoney,
        setHideMoney,
        toggleHideMoney,
        settings,
        updateSettings,
        dailyEntries,
        addDailyEntry,
        deleteDailyEntry,
        totalBalance,
        todayIncome,
        todayExpense,
        workers,
        attendance,
        overtime,
        workerPayments,
        addWorker,
        deleteWorker,
        toggleAttendance,
        setWorkerOvertime,
        deleteWorkerOvertime,
        addWorkerPayment,
        deleteWorkerPayment,
        sites,
        sitePayments,
        siteExpenses,
        addSite,
        deleteSite,
        addSitePayment,
        deleteSitePayment,
        addSiteExpense,
        deleteSiteExpense,
        notes,
        addNote,
        updateNotePhoto,
        deleteNote,
        prices,
        addPriceItem,
        deletePriceItem,
        toast,
        showToast,
        exportBackupData,
        restoreBackupData,
        googleAccount: settings.googleAccount,
        isSyncing,
        cloudMetadata,
        cloudConflict,
        signInWithGoogle,
        signOutGoogle,
        uploadToCloud,
        restoreFromCloud,
        toggleAutoSync,
        ignoreConflict,
        themeStyles,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
