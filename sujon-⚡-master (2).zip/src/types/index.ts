export type ThemeMode = 'sunset' | 'ocean' | 'leaf';
export type Language = 'bn' | 'en';

export interface DailyEntry {
  id: string;
  type: 'income' | 'expense';
  details: string;
  amount: number;
  date: string; // YYYY-MM-DD
  createdAt: number;
}

export type WorkerRole = 'মিস্ত্রি' | 'হেলপার';

export interface Worker {
  id: string;
  name: string;
  role: WorkerRole;
  dailyWage: number;
  createdAt: number;
}

export interface AttendanceRecord {
  id: string;
  workerId: string;
  date: string; // YYYY-MM-DD
}

export interface OvertimeRecord {
  id: string;
  workerId: string;
  date: string; // YYYY-MM-DD
  amount: number; // Blank manual box typed into, saved per date
}

export interface WorkerPayment {
  id: string;
  workerId: string;
  date: string; // YYYY-MM-DD
  amount: number;
  note: string; // অগ্রিম / সাপ্তাহিক / ধার or custom text
  createdAt: number;
}

export interface Site {
  id: string;
  name: string;
  type: string; // e.g. ইলেক্ট্রিক + প্লাম্বিং
  totalBill: number;
  startDate: string; // YYYY-MM-DD
  createdAt: number;
}

export interface SitePayment {
  id: string;
  siteId: string;
  date: string; // YYYY-MM-DD
  amount: number;
  details: string;
  createdAt: number;
}

export interface SiteExpense {
  id: string;
  siteId: string;
  date: string; // YYYY-MM-DD
  category: 'কর্মী খরচ' | 'অন্যান্য খরচ';
  workerCount?: number;
  details: string;
  amount: number;
  createdAt: number;
}

export interface NoteItem {
  id: string;
  title: string;
  text: string;
  photoUrl?: string; // base64 or blob URL
  createdAt: number;
}

export type PriceCategory = 'ইলেক্ট্রিক' | 'প্লাম্বিং' | 'স্যানিটারি';

export interface PriceItem {
  id: string;
  name: string;
  category: PriceCategory;
  unit: string; // e.g. প্রতি কয়েল, প্রতি পিস, প্রতি সেট
  price: number;
  createdAt: number;
}

export interface AppSettings {
  theme: ThemeMode;
  language: Language;
  hideMoney: boolean;
  pinLockEnabled: boolean;
  pinCode: string; // 4-digit PIN, never exported in backup
  seedInitialized: boolean;
  googleAccount?: {
    email: string;
    displayName?: string;
    lastSyncTime?: number;
    autoSyncEnabled: boolean;
  };
}

export interface CloudBackupMetadata {
  id: string;
  filename: string;
  modifiedTime: number;
  sizeBytes: number;
  deviceInfo: string;
  version: string;
}

export interface BackupData {
  version: string;
  appName: string;
  appPackage?: string;
  exportDate: string;
  deviceInfo?: string;
  workers: Worker[];
  attendance: AttendanceRecord[];
  overtime: OvertimeRecord[];
  workerPayments: WorkerPayment[];
  dailyEntries: DailyEntry[];
  sites: Site[];
  sitePayments: SitePayment[];
  siteExpenses: SiteExpense[];
  notes: NoteItem[];
  prices: PriceItem[];
  settings: {
    theme: ThemeMode;
    language: Language;
    hideMoney: boolean;
  };
}
