package com.worksledger.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.worksledger.app.data.AppDao
import com.worksledger.app.data.SettingsEntity
import com.worksledger.app.ui.theme.*

sealed class Screen {
    data class Main(val tab: String) : Screen()
    object MonthlyHisab : Screen()
    data class WorkerStatement(val workerId: String, val initialDate: String?) : Screen()
    data class SiteDetail(val siteId: String) : Screen()
    data class PhotoEditor(val noteId: String) : Screen()
    object Settings : Screen()
}

@Composable
fun MainAppScreen(dao: AppDao) {
    val settingsState by dao.getSettings().collectAsState(initial = null)
    val settings = settingsState ?: SettingsEntity()

    var isLocked by remember { mutableStateOf(settings.pinLockEnabled && settings.pinCode.isNotEmpty()) }
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Main("overview")) }

    if (isLocked) {
        NativeLockScreen(
            correctPin = settings.pinCode,
            onUnlocked = { isLocked = false }
        )
        return
    }

    Scaffold(
        bottomBar = {
            if (currentScreen is Screen.Main) {
                val currentTab = (currentScreen as Screen.Main).tab
                NativeBottomNav(
                    currentTab = currentTab,
                    onTabSelected = { currentScreen = Screen.Main(it) },
                    isEnglish = settings.language == "en"
                )
            }
        },
        containerColor = PageBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val screen = currentScreen) {
                is Screen.Main -> {
                    when (screen.tab) {
                        "daily" -> NativeDailyScreen(dao = dao, settings = settings)
                        "team" -> NativeTeamScreen(
                            dao = dao,
                            settings = settings,
                            onOpenStatement = { workerId ->
                                currentScreen = Screen.WorkerStatement(workerId, null)
                            }
                        )
                        "sites" -> NativeSitesScreen(
                            dao = dao,
                            settings = settings,
                            onOpenSiteDetail = { siteId ->
                                currentScreen = Screen.SiteDetail(siteId)
                            }
                        )
                        "notes" -> NativeNotesScreen(
                            dao = dao,
                            onOpenEditor = { noteId ->
                                currentScreen = Screen.PhotoEditor(noteId)
                            }
                        )
                        "prices" -> NativePricesScreen(dao = dao)
                        else -> NativeOverviewScreen(
                            dao = dao,
                            settings = settings,
                            onNavigateTab = { currentScreen = Screen.Main(it) },
                            onOpenSettings = { currentScreen = Screen.Settings },
                            onOpenMonthly = { currentScreen = Screen.MonthlyHisab }
                        )
                    }
                }
                is Screen.MonthlyHisab -> {
                    NativeMonthlyHisabScreen(
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("overview") }
                    )
                }
                is Screen.WorkerStatement -> {
                    NativeWorkerStatementScreen(
                        workerId = screen.workerId,
                        initialDate = screen.initialDate,
                        dao = dao,
                        onBack = { currentScreen = Screen.Main("team") }
                    )
                }
                is Screen.SiteDetail -> {
                    NativeSiteDetailScreen(
                        siteId = screen.siteId,
                        dao = dao,
                        onBack = { currentScreen = Screen.Main("sites") }
                    )
                }
                is Screen.PhotoEditor -> {
                    NativePhotoEditorScreen(
                        noteId = screen.noteId,
                        dao = dao,
                        onBack = { currentScreen = Screen.Main("notes") }
                    )
                }
                is Screen.Settings -> {
                    NativeSettingsScreen(
                        dao = dao,
                        settings = settings,
                        onLockNow = { isLocked = true },
                        onBack = { currentScreen = Screen.Main("overview") }
                    )
                }
            }
        }
    }
}

// Bottom Navigation: 6 equal cells, icon above a short single-line label
@Composable
fun NativeBottomNav(
    currentTab: String,
    onTabSelected: (String) -> Unit,
    isEnglish: Boolean
) {
    data class NavItem(val id: String, val labelBn: String, val labelEn: String, val icon: ImageVector)

    val items = listOf(
        NavItem("overview", "ওভারভিউ", "Overview", Icons.Default.Home),
        NavItem("daily", "ডেইলি", "Daily", Icons.Default.CalendarToday),
        NavItem("team", "টিম", "Team", Icons.Default.People),
        NavItem("sites", "সাইট", "Sites", Icons.Default.Apartment),
        NavItem("notes", "নোট", "Notes", Icons.Default.Description),
        NavItem("prices", "প্রাইস", "Prices", Icons.Default.LocalOffer)
    )

    Surface(
        color = SurfaceColor,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { item ->
                val isSelected = currentTab == item.id
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onTabSelected(item.id) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.labelBn,
                        tint = if (isSelected) OceanStart else MutedText,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = if (isEnglish) item.labelEn else item.labelBn,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) OceanStart else MutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
