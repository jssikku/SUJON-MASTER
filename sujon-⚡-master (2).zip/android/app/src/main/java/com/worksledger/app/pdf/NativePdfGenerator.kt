package com.worksledger.app.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.worksledger.app.data.AttendanceEntity
import com.worksledger.app.data.OvertimeEntity
import com.worksledger.app.data.SiteEntity
import com.worksledger.app.data.SitePaymentEntity
import com.worksledger.app.data.WorkerEntity
import com.worksledger.app.data.WorkerPaymentEntity
import java.io.File
import java.io.FileOutputStream

object NativePdfGenerator {

    /**
     * RULE 13: Worker PDF in English ONLY, EXACTLY 1 page covering the full account:
     * worked-days table and money-taken table on the same page, with both totals and summary/due.
     */
    fun generateWorkerPdf(
        context: Context,
        worker: WorkerEntity,
        year: Int,
        month: Int,
        attendance: List<AttendanceEntity>,
        overtime: List<OvertimeEntity>,
        payments: List<WorkerPaymentEntity>
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 at 72dpi
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint().apply {
            isAntiAlias = true
        }

        // Header Background (Ocean Teal)
        paint.color = Color.parseColor("#0F172A")
        canvas.drawRect(20f, 20f, 575f, 80f, paint)

        // Header text
        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 16f
        canvas.drawText("SUJON MASTER — WORKER STATEMENT", 35f, 48f, paint)

        paint.textSize = 10f
        paint.typeface = Typeface.DEFAULT
        paint.color = Color.parseColor("#94A3B8")
        canvas.drawText("ELECTRIC • PLUMBING • SANITARY CONTRACTOR", 35f, 68f, paint)

        // Worker Info Box
        paint.color = Color.parseColor("#F8FAFC")
        canvas.drawRect(20f, 90f, 575f, 130f, paint)
        paint.color = Color.parseColor("#0F172A")
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 13f
        canvas.drawText("Name: ${worker.name}  |  Role: ${worker.role}  |  Wage: BDT ${worker.dailyWage.toInt()}", 35f, 115f, paint)

        // Totals
        val totalDays = attendance.size
        val haziraEarned = totalDays * worker.dailyWage
        val otEarned = overtime.sumOf { it.amount }
        val totalEarned = haziraEarned + otEarned
        val totalTaken = payments.sumOf { it.amount }
        val due = totalEarned - totalTaken

        paint.textSize = 10f
        paint.color = Color.parseColor("#0F172A")
        canvas.drawText("Worked: $totalDays Days  |  Hazira: BDT ${haziraEarned.toInt()}  |  OT: BDT ${otEarned.toInt()}  |  Taken: BDT ${totalTaken.toInt()}  |  Due: BDT ${due.toInt()}", 35f, 150f, paint)

        // Left Table: Worked Days
        val left = 20f
        val mid = 290f
        paint.color = Color.parseColor("#0F172A")
        canvas.drawRect(left, 165f, mid, 185f, paint)
        paint.color = Color.WHITE
        paint.textSize = 9f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("WORKED DAYS (${attendance.size})", left + 8f, 178f, paint)

        var y = 198f
        val rowH = 17f
        paint.color = Color.BLACK
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 8.5f
        attendance.forEachIndexed { i, a ->
            val otForDay = overtime.find { it.date == a.date }
            val otText = if (otForDay != null && otForDay.amount > 0) " + OT: ${otForDay.amount.toInt()}" else ""
            canvas.drawText("${i + 1}. ${a.date}  (BDT ${worker.dailyWage.toInt()}$otText)", left + 8f, y, paint)
            y += rowH
        }

        // Right Table: Payments Taken
        val right = 305f
        val end = 575f
        paint.color = Color.parseColor("#0F172A")
        canvas.drawRect(right, 165f, end, 185f, paint)
        paint.color = Color.WHITE
        paint.textSize = 9f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("MONEY TAKEN (${payments.size})", right + 8f, 178f, paint)

        var ry = 198f
        paint.color = Color.BLACK
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 8.5f
        payments.forEachIndexed { i, p ->
            canvas.drawText("${i + 1}. ${p.date} - ${p.note}: BDT ${p.amount.toInt()}", right + 8f, ry, paint)
            ry += rowH
        }

        // Footer
        paint.color = Color.parseColor("#94A3B8")
        paint.textSize = 8f
        canvas.drawText("SUJON MASTER App — Confidential Ledger Statement — Page 1 of 1", 160f, 825f, paint)

        document.finishPage(page)

        val outputFile = File(context.cacheDir, "Worker_${worker.name}_Statement.pdf")
        document.writeTo(FileOutputStream(outputFile))
        document.close()
        return outputFile
    }

    /**
     * RULE 12: Site PDF in Bengali ONLY, received-only list + total.
     * NO expenses, NO total bill, NO due in the PDF.
     */
    fun generateSitePdf(
        context: Context,
        site: SiteEntity,
        payments: List<SitePaymentEntity>
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint().apply { isAntiAlias = true }

        // Header Background (Teal)
        paint.color = Color.parseColor("#009E8F")
        canvas.drawRect(20f, 20f, 575f, 85f, paint)

        // Header Text
        paint.color = Color.WHITE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 16f
        canvas.drawText("SUJON MASTER — সাইট জমার রশিদ", 35f, 48f, paint)

        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT
        canvas.drawText("সাইটের নাম: ${site.name}  |  কাজের ধরন: ${site.type}", 35f, 70f, paint)

        // Subheader
        paint.color = Color.parseColor("#F8FAFC")
        canvas.drawRect(20f, 95f, 575f, 125f, paint)
        paint.color = Color.parseColor("#0F172A")
        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("প্রাপ্ত টাকার বিবরণ (Received Payments Only)", 35f, 115f, paint)

        // List
        var y = 145f
        paint.typeface = Typeface.DEFAULT
        paint.color = Color.BLACK
        paint.textSize = 10f
        payments.forEachIndexed { i, p ->
            val num = i + 1
            canvas.drawText("$num. তারিখ: ${p.date}   বিবরণ: ${p.details}   টাকা: BDT ${p.amount.toInt()}", 35f, y, paint)
            y += 24f
        }

        val totalReceived = payments.sumOf { it.amount }
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.color = Color.parseColor("#009E8F")
        paint.textSize = 13f
        canvas.drawText("মোট প্রাপ্ত টাকা: BDT ${totalReceived.toInt()}", 35f, y + 16f, paint)

        paint.color = Color.GRAY
        paint.textSize = 9f
        paint.typeface = Typeface.DEFAULT
        canvas.drawText("এই রশিদে শুধুমাত্র ক্লায়েন্টের প্রদত্ত টাকার হিসাব দেওয়া হলো — পৃষ্ঠা ১ / ১", 130f, 825f, paint)

        document.finishPage(page)

        val outputFile = File(context.cacheDir, "Site_${site.name}_Received.pdf")
        document.writeTo(FileOutputStream(outputFile))
        document.close()
        return outputFile
    }

    /**
     * Share PDF helper using FileProvider
     */
    fun sharePdf(context: Context, pdfFile: File, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "com.worksledger.app.fileprovider",
            pdfFile
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
