package com.worksledger.app.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.ByteArrayContent
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Collections

/**
 * GoogleDriveSyncManager for SUJON ⚡ MASTER (com.worksledger.app)
 *
 * PRIVACY & SCOPE RULE:
 * Strictly requests ONLY `drive.appdata` scope (https://www.googleapis.com/auth/drive.appdata) + email.
 * Files are isolated in the private `appDataFolder`, invisible to regular Drive UI and other apps.
 */
class GoogleDriveSyncManager(private val context: Context) {

    companion object {
        const val BACKUP_FILENAME = "sujon_master_backup.json"
        val SCOPE_APPDATA = Scope("https://www.googleapis.com/auth/drive.appdata")
    }

    // Google Sign-In Client configured with minimal scopes
    fun getGoogleSignInClient(): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(SCOPE_APPDATA)
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getSignedInAccount(): GoogleSignInAccount? {
        return GoogleSignIn.getLastSignedInAccount(context)
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun getDriveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context, Collections.singleton(DriveScopes.DRIVE_APPDATA)
        )
        credential.selectedAccount = account.account

        return Drive.Builder(
            AndroidHttp.newCompatibleTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("SUJON MASTER").build()
    }

    /**
     * Upload full JSON backup to private appDataFolder.
     * Note photos are uploaded with references in the appDataFolder.
     */
    suspend fun uploadBackupToDrive(jsonContent: String): Result<String> = withContext(Dispatchers.IO) {
        if (!isNetworkAvailable()) {
            return@withContext Result.failure(Exception("ইন্টারনেট নেই"))
        }

        val account = getSignedInAccount()
            ?: return@withContext Result.failure(Exception("সাইন-ইন হয়নি"))

        try {
            val drive = getDriveService(account)

            // Find existing backup file in appDataFolder
            val fileList = drive.files().list()
                .setSpaces("appDataFolder")
                .setQ("name = '$BACKUP_FILENAME' and trashed = false")
                .setFields("files(id, name, modifiedTime)")
                .execute()

            val existingFile = fileList.files?.firstOrNull()

            val contentStream = ByteArrayContent("application/json", jsonContent.toByteArray(Charsets.UTF_8))

            if (existingFile != null) {
                // Update existing file
                val fileMetadata = File()
                drive.files().update(existingFile.id, fileMetadata, contentStream)
                    .setFields("id, modifiedTime")
                    .execute()
                Result.success("ব্যাকআপ সফল হয়েছে")
            } else {
                // Create new file in appDataFolder
                val fileMetadata = File().apply {
                    name = BACKUP_FILENAME
                    parents = listOf("appDataFolder")
                }
                drive.files().create(fileMetadata, contentStream)
                    .setFields("id, modifiedTime")
                    .execute()
                Result.success("ব্যাকআপ সফল হয়েছে")
            }
        } catch (e: Exception) {
            val msg = if (e.message?.contains("quota", ignoreCase = true) == true) {
                "ড্রাইভে জায়গা নেই"
            } else {
                "ড্রাইভে ব্যাকআপ ব্যর্থ হয়েছে"
            }
            Result.failure(Exception(msg, e))
        }
    }

    /**
     * Download backup JSON from private appDataFolder
     */
    suspend fun downloadBackupFromDrive(): Result<Pair<String, Long>> = withContext(Dispatchers.IO) {
        if (!isNetworkAvailable()) {
            return@withContext Result.failure(Exception("ইন্টারনেট নেই"))
        }

        val account = getSignedInAccount()
            ?: return@withContext Result.failure(Exception("সাইন-ইন হয়নি"))

        try {
            val drive = getDriveService(account)

            val fileList = drive.files().list()
                .setSpaces("appDataFolder")
                .setQ("name = '$BACKUP_FILENAME' and trashed = false")
                .setFields("files(id, name, modifiedTime, size)")
                .execute()

            val file = fileList.files?.firstOrNull()
                ?: return@withContext Result.failure(Exception("ক্লাউডে কোনো ব্যাকআপ পাওয়া যায়নি"))

            val outputStream = ByteArrayOutputStream()
            drive.files().get(file.id).executeMediaAndDownloadTo(outputStream)
            val json = outputStream.toString("UTF-8")
            val modifiedTime = file.modifiedTime?.value ?: System.currentTimeMillis()

            Result.success(Pair(json, modifiedTime))
        } catch (e: Exception) {
            Result.failure(Exception("ক্লাউড ব্যাকআপ ফিরিয়ে আনা যায়নি", e))
        }
    }
}
