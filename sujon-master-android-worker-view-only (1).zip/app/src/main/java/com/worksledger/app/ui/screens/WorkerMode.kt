package com.worksledger.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.worksledger.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

// ---------- Worker snapshot: ONLY this worker's data, never the full DB ----------
data class SnapshotPayment(val date: String, val amount: Double, val note: String)

data class WorkerSnapshot(
    val workerId: String,
    val name: String,
    val role: String,
    val dailyWage: Double,
    val attendanceDates: List<String>,
    val overtime: Map<String, Double>,
    val payments: List<SnapshotPayment>,
    val lastUpdated: Long,
    val codeHash: String,
    val isLocal: Boolean = false
)

fun sha256Hex(input: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
}

fun workerSnapshotToJson(s: WorkerSnapshot): String {
    val o = JSONObject()
    o.put("workerId", s.workerId); o.put("name", s.name); o.put("role", s.role)
    o.put("dailyWage", s.dailyWage); o.put("lastUpdated", s.lastUpdated); o.put("codeHash", s.codeHash)
    val att = JSONArray(); s.attendanceDates.forEach { att.put(it) }; o.put("attendance", att)
    val ot = JSONObject(); s.overtime.forEach { (k, v) -> ot.put(k, v) }; o.put("overtime", ot)
    val pay = JSONArray()
    s.payments.forEach { p -> val po = JSONObject(); po.put("date", p.date); po.put("amount", p.amount); po.put("note", p.note); pay.put(po) }
    o.put("payments", pay)
    return o.toString()
}

fun workerSnapshotFromJson(jsonStr: String): WorkerSnapshot? {
    return try {
        val o = JSONObject(jsonStr)
        val att = mutableListOf<String>()
        val attArr = o.optJSONArray("attendance")
        if (attArr != null) for (i in 0 until attArr.length()) att.add(attArr.getString(i))
        val ot = mutableMapOf<String, Double>()
        val otObj = o.optJSONObject("overtime")
        if (otObj != null) { val keys = otObj.keys(); while (keys.hasNext()) { val k = keys.next(); ot[k] = otObj.optDouble(k) } }
        val pay = mutableListOf<SnapshotPayment>()
        val payArr = o.optJSONArray("payments")
        if (payArr != null) for (i in 0 until payArr.length()) {
            val po = payArr.getJSONObject(i)
            pay.add(SnapshotPayment(po.optString("date"), po.optDouble("amount"), po.optString("note")))
        }
        WorkerSnapshot(
            workerId = o.optString("workerId"), name = o.optString("name"), role = o.optString("role"),
            dailyWage = o.optDouble("dailyWage"), attendanceDates = att, overtime = ot, payments = pay,
            lastUpdated = o.optLong("lastUpdated", System.currentTimeMillis()), codeHash = o.optString("codeHash")
        )
    } catch (_: Exception) { null }
}

fun saveWorkerSnapshot(context: Context, s: WorkerSnapshot) {
    context.getSharedPreferences("worker_snapshots", Context.MODE_PRIVATE)
        .edit().putString(s.codeHash, workerSnapshotToJson(s)).apply()
}

fun loadWorkerSnapshotByHash(context: Context, codeHash: String): WorkerSnapshot? {
    val json = context.getSharedPreferences("worker_snapshots", Context.MODE_PRIVATE).getString(codeHash, null) ?: return null
    return workerSnapshotFromJson(json)
}

fun deleteWorkerSnapshot(context: Context, workerId: String) {
    val prefs = context.getSharedPreferences("worker_snapshots", Context.MODE_PRIVATE)
    val all = prefs.all
    val ed = prefs.edit()
    all.forEach { (k, v) ->
        val s = (v as? String)?.let { workerSnapshotFromJson(it) }
        if (s != null && s.workerId == workerId) ed.remove(k)
    }
    ed.apply()
}

suspend fun buildSnapshotFromDao(dao: AppDao, worker: WorkerEntity): WorkerSnapshot {
    val att = dao.getAllAttendance().first().filter { it.workerId == worker.id }.map { it.date }
    val ot = dao.getAllOvertime().first().filter { it.workerId == worker.id }.associate { it.date to it.amount }
    val pay = dao.getAllWorkerPayments().first().filter { it.workerId == worker.id }
        .map { SnapshotPayment(it.date, it.amount, it.note) }
    return WorkerSnapshot(
        workerId = worker.id, name = worker.name, role = worker.role, dailyWage = worker.dailyWage,
        attendanceDates = att, overtime = ot, payments = pay,
        lastUpdated = System.currentTimeMillis(),
        codeHash = sha256Hex(worker.workerCode), isLocal = true
    )
}

fun isNetworkAvailable(context: Context): Boolean {
    return try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(net) ?: return false
        cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) { false }
}

fun shareWorkerSnapshotFile(context: Context, snapshot: WorkerSnapshot) {
    try {
        val file = File(context.cacheDir, "worker_snapshot_${snapshot.workerId}.json")
        file.writeText(workerSnapshotToJson(snapshot))
        val uri = FileProvider.getUriForFile(context, "com.worksledger.app.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "${snapshot.name} — মাসিক হিসাব snapshot")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Snapshot Share Korun"))
    } catch (e: Exception) {
        Toast.makeText(context, "Snapshot share kora jayni: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

fun copyToClipboard(context: Context, label: String, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, "Copy hoyeche", Toast.LENGTH_SHORT).show()
}

fun shareCodeOnWhatsApp(context: Context, workerName: String, code: String) {
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            setPackage("com.whatsapp")
            putExtra(Intent.EXTRA_TEXT, "SUJON MASTER — $workerName, apnar Worker Code: $code\nEi code diye app e 'Worker Hisab Dekhun' theke apnar hisab dekhte parben.")
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "SUJON MASTER — $workerName, apnar Worker Code: $code")
        }
        context.startActivity(Intent.createChooser(intent, "Code Share Korun"))
    }
}

// ---------- Mode choice ----------
@Composable
fun WorkerModeChoiceScreen(onOwner: () -> Unit, onWorker: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFFFFF8F1)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("SUJON ⚡ MASTER", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1D1A18))
        Text("Ke hisab dekhben?", fontSize = 15.sp, color = Color(0xFF6B7280), modifier = Modifier.padding(top = 8.dp, bottom = 32.dp))
        Button(
            onClick = onOwner, modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF009E8F))
        ) { Text("Malik / Owner", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onWorker, modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
        ) { Text("Worker Hisab Dekhun", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
        Spacer(modifier = Modifier.height(24.dp))
        Text("Worker ra sudhu nijer hisab dekhte parbe, ar kichu korte parbe na.", fontSize = 12.sp, color = Color(0xFF6B7280), textAlign = TextAlign.Center)
    }
}

// ---------- Worker login: code only, no worker list ----------
@Composable
fun WorkerLoginScreen(
    dao: AppDao,
    onLogin: (WorkerSnapshot) -> Unit,
    onBackToChoice: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val workers by dao.getAllWorkers().collectAsState(initial = emptyList())
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var attempts by remember { mutableStateOf(0) }
    var blockedUntil by remember { mutableStateOf(0L) }
    var busy by remember { mutableStateOf(false) }

    val importPicker = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        coroutineScope.launch(Dispatchers.IO) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                val snap = text?.let { workerSnapshotFromJson(it) }
                withContext(Dispatchers.Main) {
                    if (snap != null && snap.codeHash.isNotBlank()) {
                        saveWorkerSnapshot(context, snap)
                        Toast.makeText(context, "Snapshot pawa geche, code diye login korun", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Ei file ta thik snapshot na", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { Toast.makeText(context, "File khola jayni: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFFFFF8F1)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Worker Hisab Dekhun", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1D1A18))
        Spacer(modifier = Modifier.height(8.dp))
        Text("Sudhu apnar Worker Code din", fontSize = 13.sp, color = Color(0xFF6B7280))
        Spacer(modifier = Modifier.height(24.dp))
        OutlinedTextField(
            value = code, onValueChange = { code = it; error = "" },
            label = { Text("Worker Code") }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp), singleLine = true
        )
        if (error.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(error, color = Color(0xFFE5484D), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                val now = System.currentTimeMillis()
                if (now < blockedUntil) { error = "Code vul"; return@Button }
                if (code.trim().length < 6) { error = "Code vul"; return@Button }
                busy = true
                coroutineScope.launch {
                    val hash = sha256Hex(code.trim())
                    // 1) Same phone: local Room worker with this code
                    val localWorker = workers.find { it.workerCode.isNotBlank() && sha256Hex(it.workerCode) == hash }
                    if (localWorker != null) {
                        val snap = buildSnapshotFromDao(dao, localWorker)
                        saveWorkerSnapshot(context, snap)
                        context.getSharedPreferences("sujon_master_prefs", Context.MODE_PRIVATE)
                            .edit().putString("worker_session_hash", hash).apply()
                        busy = false; onLogin(snap); return@launch
                    }
                    // 2) Other phone: imported snapshot with this code hash
                    val imported = loadWorkerSnapshotByHash(context, hash)
                    if (imported != null) {
                        context.getSharedPreferences("sujon_master_prefs", Context.MODE_PRIVATE)
                            .edit().putString("worker_session_hash", hash).apply()
                        busy = false; onLogin(imported); return@launch
                    }
                    // Wrong code: generic message only, no hint about who / whether it exists
                    attempts += 1
                    if (attempts >= 5) { blockedUntil = System.currentTimeMillis() + 30_000; attempts = 0 }
                    busy = false; error = "Code vul"
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
            enabled = !busy
        ) { Text(if (busy) "Check hocche..." else "Login", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
            onClick = { importPicker.launch("*/*") },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
        ) { Text("Snapshot File Khulun", fontWeight = FontWeight.Bold, color = Color(0xFF1D1A18)) }
        Spacer(modifier = Modifier.height(8.dp))
        TextButton(onClick = onBackToChoice) { Text("← Mode Choice e Firun", color = Color(0xFF2563EB)) }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "Live auto-sync er jonno alada server setup lagbe — ekhon snapshot file share kore hisab pawa jabe, protibar notun hisab er jonno malik notun snapshot pathabe.",
            fontSize = 11.sp, color = Color(0xFF6B7280), textAlign = TextAlign.Center
        )
    }
}

// ---------- Worker view-only statement ----------
@Composable
fun WorkerViewOnlyScreen(
    dao: AppDao,
    snapshot: WorkerSnapshot,
    onSnapshot: (WorkerSnapshot) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var snap by remember { mutableStateOf(snapshot) }
    var currentYear by remember { mutableStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    var currentMonth by remember { mutableStateOf(Calendar.getInstance().get(Calendar.MONTH) + 1) }
    var offline by remember { mutableStateOf(!isNetworkAvailable(context)) }
    var refreshing by remember { mutableStateOf(false) }

    fun doRefresh() {
        refreshing = true
        coroutineScope.launch {
            offline = !isNetworkAvailable(context)
            val workers = dao.getAllWorkers().first()
            val localWorker = workers.find { it.id == snap.workerId }
            if (localWorker != null && localWorker.workerCode.isNotBlank()) {
                val fresh = buildSnapshotFromDao(dao, localWorker)
                saveWorkerSnapshot(context, fresh)
                snap = fresh; onSnapshot(fresh)
            } else {
                val stored = loadWorkerSnapshotByHash(context, snap.codeHash)
                if (stored != null) { snap = stored; onSnapshot(stored) }
            }
            delay(300)
            refreshing = false
        }
    }

    val monthPrefix = String.format("%04d-%02d", currentYear, currentMonth)
    val attThisMonth = snap.attendanceDates.filter { it.startsWith(monthPrefix) }
    val payThisMonth = snap.payments.filter { it.date.startsWith(monthPrefix) }
    val otThisMonth = snap.overtime.filter { it.key.startsWith(monthPrefix) }
    val workedDays = attThisMonth.size
    val haziraTotal = workedDays * snap.dailyWage
    val otTotal = otThisMonth.values.sum()
    val totalEarned = haziraTotal + otTotal
    val totalTaken = payThisMonth.sumOf { it.amount }
    val dueAmount = totalEarned - totalTaken
    val monthNames = arrayOf("", "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
    val monthLabel = "${monthNames[currentMonth]} ${toBengaliNum(currentYear)}"
    val weekdayNames = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")
    val cal = Calendar.getInstance()
    cal.set(Calendar.YEAR, currentYear); cal.set(Calendar.MONTH, currentMonth - 1); cal.set(Calendar.DAY_OF_MONTH, 1)
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
    val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val presentSet = attThisMonth.map { it.substring(8, 10).toIntOrNull() ?: 0 }.toSet()
    val lastUpdatedStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(snap.lastUpdated))

    LazyColumn(modifier = Modifier.fillMaxSize().background(Color(0xFFFFF8F1)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Amar Hisab", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1D1A18))
                OutlinedButton(onClick = onLogout, shape = RoundedCornerShape(12.dp)) { Text("Logout", fontWeight = FontWeight.Bold, color = Color(0xFF1D1A18)) }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(snap.name, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1D1A18))
            Text("${snap.role} • দৈনিক হাজিরা ৳ ${snap.dailyWage.toInt()}", fontSize = 13.sp, color = Color(0xFF6B7280))
            Spacer(modifier = Modifier.height(6.dp))
            Text("Last updated: $lastUpdatedStr", fontSize = 12.sp, color = Color(0xFF6B7280))
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = { doRefresh() }, shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                enabled = !refreshing
            ) { Text(if (refreshing) "Refresh hocche..." else "Refresh", fontWeight = FontWeight.Bold) }
            if (offline) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("Offline - purono hisab dekhacche", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E), modifier = Modifier.padding(10.dp))
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (currentMonth == 1) { currentMonth = 12; currentYear-- } else currentMonth-- }) { Icon(Icons.Default.ChevronLeft, contentDescription = null) }
                    Text(monthLabel, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    IconButton(onClick = { if (currentMonth == 12) { currentMonth = 1; currentYear++ } else currentMonth++ }) { Icon(Icons.Default.ChevronRight, contentDescription = null) }
                }
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("কাজের দিন" to "$workedDays", "আয়" to "৳ ${totalEarned.toInt()}", "নিয়েছে" to "৳ ${totalTaken.toInt()}", "বাকি" to "৳ ${dueAmount.toInt()}").forEach { (label, value) ->
                    Card(modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(label, fontSize = 11.sp, color = Color(0xFF6B7280))
                            Text(value, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text("OT মোট: ৳ ${otTotal.toInt()} (malik er lekha manual OT sudhu)", fontSize = 12.sp, color = Color(0xFF6B7280))
        }
        item {
            Text("কাজের দিনের ক্যালেন্ডার", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(6.dp))
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(modifier = Modifier.padding(10.dp)) {
                    LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.fillMaxWidth().height(((maxDays + firstDayOfWeek - 1 + 6) / 7 * 44).dp)) {
                        val totalCells = firstDayOfWeek - 1 + maxDays
                        items(totalCells) { idx ->
                            if (idx < firstDayOfWeek - 1) {
                                Box(modifier = Modifier.size(40.dp))
                            } else {
                                val day = idx - (firstDayOfWeek - 1) + 1
                                val isPresent = presentSet.contains(day)
                                Box(
                                    modifier = Modifier.size(40.dp).background(if (isPresent) Color(0xFF1D1A18) else Color(0xFFF1F5F9), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) { Text("$day", color = if (isPresent) Color.White else Color(0xFF1D1A18), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                    Text("গাঢ় বাক্স = উপস্থিত দিন। তারিখে ট্যাপ করলে কিছু হবে না।", fontSize = 11.sp, color = Color(0xFF6B7280))
                }
            }
        }
        item {
            Text("দিনের হিসাব", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            if (attThisMonth.isEmpty()) Text("এই মাসে এখনও কোনো উপস্থিতি নেই।", fontSize = 12.sp, color = Color(0xFF6B7280))
            attThisMonth.sorted().forEach { dateStr ->
                val c = Calendar.getInstance()
                try { val parts = dateStr.split("-"); c.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt()) } catch (_: Exception) {}
                val wd = weekdayNames[c.get(Calendar.DAY_OF_WEEK) - 1]
                val otAmt = snap.overtime[dateStr] ?: 0.0
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${formatBengaliDate(dateStr)} • $wd", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("৳ ${snap.dailyWage.toInt()}" + if (otAmt > 0) " + OT ৳ ${otAmt.toInt()}" else "", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Text("টাকা নিয়েছে", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            if (payThisMonth.isEmpty()) Text("এই মাসে কোনো টাকা নেওয়া হয়নি।", fontSize = 12.sp, color = Color(0xFF6B7280))
            payThisMonth.sortedBy { it.date }.forEach { p ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${formatBengaliDate(p.date)} • ${p.note}", fontSize = 13.sp)
                        Text("৳ ${p.amount.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("মোট নিয়েছে: ৳ ${totalTaken.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
