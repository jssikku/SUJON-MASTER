package com.worksledger.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.activity.compose.BackHandler
import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.worksledger.app.sync.GoogleDriveSyncManager
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.worksledger.app.data.AppDao
import com.worksledger.app.data.SettingsEntity
import com.worksledger.app.ui.theme.*

sealed class Screen {
    data class Main(val tab: String) : Screen()
    object MonthlyHisab : Screen()
    data class WorkerStatement(val workerId: String, val initialDate: String?) : Screen()
    data class SiteDetail(val siteId: String) : Screen()
    data class PhotoEditor(val noteId: String) : Screen()
    object Settings : Screen()
}

@Composable
fun MainAppScreen(dao: AppDao) {
    val settingsState by dao.getSettings().collectAsState(initial = null)
    val settings = settingsState ?: SettingsEntity()
    // Worker mode: mode choice is shown first. Owner mode is the existing app.
    // Worker mode never shows owner pages and never needs the owner PIN.
    val modeContext = LocalContext.current
    val modePrefs = remember { modeContext.getSharedPreferences("sujon_master_prefs", Context.MODE_PRIVATE) }
    var appMode by remember { mutableStateOf(modePrefs.getString("app_mode", null)) }
    var workerSnapshot by remember { mutableStateOf<WorkerSnapshot?>(null) }
    if (appMode == null) {
        WorkerModeChoiceScreen(
            onOwner = { modePrefs.edit().putString("app_mode", "owner").apply(); appMode = "owner" },
            onWorker = { appMode = "worker" }
        )
        return
    }
    if (appMode == "worker") {
        if (workerSnapshot == null) {
            WorkerLoginScreen(
                dao = dao,
                onLogin = { snap -> workerSnapshot = snap },
                onBackToChoice = { appMode = null }
            )
        } else {
            WorkerViewOnlyScreen(
                dao = dao,
                snapshot = workerSnapshot!!,
                onSnapshot = { snap -> workerSnapshot = snap },
                onLogout = {
                    modePrefs.edit().remove("app_mode").remove("worker_session_hash").apply()
                    workerSnapshot = null; appMode = null
                }
            )
        }
        return
    }

    // Lock must be derived from the loaded settings, not from the first
    // composition (when settings are still null). Otherwise a PIN-enabled
    // app opens unlocked after restart - the old remember() bug.
    var unlocked by remember { mutableStateOf(false) }
    val isLocked = settings.pinLockEnabled && settings.pinCode.isNotEmpty() && !unlocked
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Main("overview")) }

    // System back must return to the main tab from any detail screen, never
    // exit the app. Previously there was no BackHandler, so pressing system
    // back in the photo editor (especially when its top bar was hidden by a
    // large/zoomed photo) closed the whole app instead of going to Notes.
    BackHandler(enabled = currentScreen !is Screen.Main) {
        currentScreen = when (val s = currentScreen) {
            is Screen.MonthlyHisab -> Screen.Main("overview")
            is Screen.WorkerStatement -> Screen.Main("team")
            is Screen.SiteDetail -> Screen.Main("sites")
            is Screen.PhotoEditor -> Screen.Main("notes")
            is Screen.Settings -> Screen.Main("overview")
            else -> Screen.Main("overview")
        }
    }

    if (isLocked) {
        NativeLockScreen(
            correctPin = settings.pinCode,
            onUnlocked = { unlocked = true }
        )
        return
    }

    // Auto-sync: runs at app level, not in Settings. It polls the saved
    // toggle every 30 seconds and uploads a backup whenever Auto Sync is ON
    // and Google is signed in, on ANY screen. It uploads once immediately
    // on app open if the toggle is already ON, then every 30s after that.
    // Failures are silent here; manual "এখনই ব্যাকআপ নিন" still shows its toast.
    val appContext = LocalContext.current
    val rootSyncManager = remember { GoogleDriveSyncManager(appContext) }
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val prefs = appContext.getSharedPreferences("sujon_master_prefs", Context.MODE_PRIVATE)
                if (prefs.getBoolean("autoSyncEnabled", false) && rootSyncManager.getSignedInAccount() != null) {
                    val json = exportDbAsJson(dao, appContext)
                    rootSyncManager.uploadBackupToDrive(json)
                }
            } catch (e: Exception) {
                // Ignore: next 30s cycle retries. Do not crash the app for sync.
            }
            delay(30_000)
        }
    }

    Scaffold(
        bottomBar = {
            if (currentScreen is Screen.Main) {
                val currentTab = (currentScreen as Screen.Main).tab
                NativeBottomNav(
                    currentTab = currentTab,
                    onTabSelected = { currentScreen = Screen.Main(it) },
                    isEnglish = settings.language == "en",
                    themeStart = themeColors(settings.theme).first
                )
            }
        },
        containerColor = PageBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val screen = currentScreen) {
                is Screen.Main -> {
                    when (screen.tab) {
                        "daily" -> NativeDailyScreen(dao = dao, settings = settings)
                        "team" -> NativeTeamScreen(
                            dao = dao,
                            settings = settings,
                            onOpenStatement = { workerId ->
                                currentScreen = Screen.WorkerStatement(workerId, null)
                            }
                        )
                        "sites" -> NativeSitesScreen(
                            dao = dao,
                            settings = settings,
                            onOpenSiteDetail = { siteId ->
                                currentScreen = Screen.SiteDetail(siteId)
                            }
                        )
                        "notes" -> NativeNotesScreen(
                            dao = dao,
                            settings = settings,
                            onOpenEditor = { noteId ->
                                currentScreen = Screen.PhotoEditor(noteId)
                            }
                        )
                        "prices" -> NativePricesScreen(dao = dao, settings = settings)
                        else -> NativeOverviewScreen(
                            dao = dao,
                            settings = settings,
                            onNavigateTab = { currentScreen = Screen.Main(it) },
                            onOpenSettings = { currentScreen = Screen.Settings },
                            onOpenMonthly = { currentScreen = Screen.MonthlyHisab }
                        )
                    }
                }
                is Screen.MonthlyHisab -> {
                    NativeMonthlyHisabScreen(
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("overview") }
                    )
                }
                is Screen.WorkerStatement -> {
                    NativeWorkerStatementScreen(
                        workerId = screen.workerId,
                        initialDate = screen.initialDate,
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("team") }
                    )
                }
                is Screen.SiteDetail -> {
                    NativeSiteDetailScreen(
                        siteId = screen.siteId,
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("sites") }
                    )
                }
                is Screen.PhotoEditor -> {
                    NativePhotoEditorScreen(
                        noteId = screen.noteId,
                        dao = dao,
                        settings = settings,
                        onBack = { currentScreen = Screen.Main("notes") }
                    )
                }
                is Screen.Settings -> {
                    NativeSettingsScreen(
                        dao = dao,
                        settings = settings,
                        onLockNow = { unlocked = false },
                        onBack = { currentScreen = Screen.Main("overview") }
                    )
                }
            }
        }
    }
}

// Bottom Navigation: 6 equal cells, icon above a short single-line label
@Composable
fun NativeBottomNav(
    currentTab: String,
    onTabSelected: (String) -> Unit,
    isEnglish: Boolean,
    themeStart: Color = OceanStart
) {
    data class NavItem(val id: String, val labelBn: String, val labelEn: String, val icon: ImageVector)

    val items = listOf(
        NavItem("overview", "ওভারভিউ", "Overview", Icons.Default.Home),
        NavItem("daily", "ডেইলি", "Daily", Icons.Default.CalendarToday),
        NavItem("team", "টিম", "Team", Icons.Default.People),
        NavItem("sites", "সাইট", "Sites", Icons.Default.Apartment),
        NavItem("notes", "নোট", "Notes", Icons.Default.Description),
        NavItem("prices", "প্রাইস", "Prices", Icons.Default.LocalOffer)
    )

    Surface(
        color = SurfaceColor,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { item ->
                val isSelected = currentTab == item.id
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onTabSelected(item.id) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.labelBn,
                        tint = if (isSelected) themeStart else MutedText,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = if (isEnglish) item.labelEn else item.labelBn,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) themeStart else MutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
