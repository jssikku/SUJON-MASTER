package com.worksledger.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        DailyEntity::class,
        WorkerEntity::class,
        AttendanceEntity::class,
        OvertimeEntity::class,
        WorkerPaymentEntity::class,
        SiteEntity::class,
        SitePaymentEntity::class,
        SiteExpenseEntity::class,
        NoteEntity::class,
        PriceEntity::class,
        SettingsEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // v1 -> v2: add worker login code column. Old workers get "" = login disabled.
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE workers ADD COLUMN workerCode TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sujon_master_db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .addMigrations(MIGRATION_1_2)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialSeed(database.appDao())
                }
            }
        }

        suspend fun populateInitialSeed(dao: AppDao) {
            // Seed Workers (4)
            dao.insertWorker(WorkerEntity("w-rahim", "Rahim", "মিস্ত্রি", 900.0))
            dao.insertWorker(WorkerEntity("w-karim", "Karim", "মিস্ত্রি", 850.0))
            dao.insertWorker(WorkerEntity("w-salam", "Salam", "হেলপার", 550.0))
            dao.insertWorker(WorkerEntity("w-jamal", "Jamal", "হেলপার", 500.0))

            // Salam: 19 days in Oct 2026
            for (d in 1..19) {
                val dayStr = if (d < 10) "0$d" else "$d"
                dao.insertAttendance(AttendanceEntity("att-salam-$d", "w-salam", "2026-10-$dayStr"))
            }

            // Jamal: 12 days in Oct 2026
            for (d in 1..12) {
                val dayStr = if (d < 10) "0$d" else "$d"
                dao.insertAttendance(AttendanceEntity("att-jamal-$d", "w-jamal", "2026-10-$dayStr"))
            }

            // Salam Payments (Total 9550, Due 900)
            dao.insertWorkerPayment(WorkerPaymentEntity("wp-s-1", "w-salam", "2026-10-10", 3000.0, "সাপ্তাহিক"))
            dao.insertWorkerPayment(WorkerPaymentEntity("wp-s-2", "w-salam", "2026-10-20", 4000.0, "সাপ্তাহিক"))
            dao.insertWorkerPayment(WorkerPaymentEntity("wp-s-3", "w-salam", "2026-10-28", 2550.0, "অগ্রিম"))

            // Jamal Payments (Total 6000, Due 0)
            dao.insertWorkerPayment(WorkerPaymentEntity("wp-j-1", "w-jamal", "2026-10-15", 3000.0, "সাপ্তাহিক"))
            dao.insertWorkerPayment(WorkerPaymentEntity("wp-j-2", "w-jamal", "2026-10-28", 3000.0, "হিসাব পরিশোধ"))

            // Sites (2)
            dao.insertSite(SiteEntity("s-dhanmondi", "Dhanmondi Flat", "ইলেক্ট্রিক + প্লাম্বিং", 120000.0, "2026-10-10"))
            dao.insertSite(SiteEntity("s-uttara", "Uttara House", "ইলেক্ট্রিক", 50000.0, "2026-10-15"))

            dao.insertSitePayment(SitePaymentEntity("sp-dh-1", "s-dhanmondi", "2026-10-10", 50000.0, "১ম কিস্তি অগ্রিম"))
            dao.insertSitePayment(SitePaymentEntity("sp-dh-2", "s-dhanmondi", "2026-10-25", 35000.0, "২য় কিস্তি"))
            dao.insertSitePayment(SitePaymentEntity("sp-ut-1", "s-uttara", "2026-10-15", 20000.0, "কাজ শুরুর সময়"))
            dao.insertSitePayment(SitePaymentEntity("sp-ut-2", "s-uttara", "2026-10-28", 11500.0, "বোর্ডের কাজ সম্পন্ন"))

            dao.insertSiteExpense(SiteExpenseEntity("se-dh-1", "s-dhanmondi", "2026-10-12", "কর্মী খরচ", 2, "কর্মী মজুরি ও নাস্তা", 1500.0))
            dao.insertSiteExpense(SiteExpenseEntity("se-dh-2", "s-dhanmondi", "2026-10-18", "অন্যান্য খরচ", null, "সাইট সামগ্রী পরিবহন", 1200.0))
            dao.insertSiteExpense(SiteExpenseEntity("se-ut-1", "s-uttara", "2026-10-16", "কর্মী খরচ", 1, "ড্রিলিং হেলপার খরচ", 1000.0))
            dao.insertSiteExpense(SiteExpenseEntity("se-ut-2", "s-uttara", "2026-10-22", "অন্যান্য খরচ", null, "টেপ ও কাটিং ব্লেড", 700.0))

            // Daily Rows (3)
            dao.insertDailyEntry(DailyEntity("de-1", "income", "Site payment — Dhanmondi", 8000.0, "2026-10-31"))
            dao.insertDailyEntry(DailyEntity("de-2", "income", "small work — fan fitting", 4500.0, "2026-10-31"))
            dao.insertDailyEntry(DailyEntity("de-3", "expense", "cable and switch purchase", 3200.0, "2026-10-31"))

            // Sample Prices (9)
            dao.insertPrice(PriceEntity("p-1", "কেবল ১.৫ মিমি", "ইলেক্ট্রিক", "প্রতি কয়েল", 3200.0))
            dao.insertPrice(PriceEntity("p-2", "সুইচ + সকেট সেট", "ইলেক্ট্রিক", "প্রতি পিস", 280.0))
            dao.insertPrice(PriceEntity("p-3", "সিলিং ফ্যান (নমুনা)", "ইলেক্ট্রিক", "প্রতি পিস", 3800.0))
            dao.insertPrice(PriceEntity("p-4", "PVC পাইপ ৩/৪\"", "প্লাম্বিং", "প্রতি পিস", 450.0))
            dao.insertPrice(PriceEntity("p-5", "এলবো ও টি ফিটিংস", "প্লাম্বিং", "প্রতি সেট", 180.0))
            dao.insertPrice(PriceEntity("p-6", "পানির ট্যাপ / কল", "প্লাম্বিং", "প্রতি পিস", 950.0))
            dao.insertPrice(PriceEntity("p-7", "কমোড সেট (বেসিক)", "স্যানিটারি", "প্রতি সেট", 7500.0))
            dao.insertPrice(PriceEntity("p-8", "বেসিন মিক্সার কল", "স্যানিটারি", "প্রতি পিস", 2400.0))
            dao.insertPrice(PriceEntity("p-9", "পি-ট্র্যাপ ও ওয়েস্ট পাইপ", "স্যানিটারি", "প্রতি পিস", 650.0))

            // Initial Settings (Fresh install: lock OFF, no pre-set PIN)
            dao.updateSettings(SettingsEntity(id = 1, theme = "ocean", language = "bn", hideMoney = false, pinLockEnabled = false, pinCode = "", seedInitialized = true))
        }
    }
}
