package com.worksledger.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// 1. Daily Entry Entity
@Entity(tableName = "daily_entries")
data class DailyEntity(
    @PrimaryKey val id: String,
    val type: String, // "income" or "expense"
    val details: String,
    val amount: Double,
    val date: String, // YYYY-MM-DD
    val createdAt: Long = System.currentTimeMillis()
)

// 2. Worker Entity
@Entity(tableName = "workers")
data class WorkerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String, // "মিস্ত্রি" or "হেলপার"
    val dailyWage: Double,
    // Worker login code, owner-set only. Empty = login disabled.
    val workerCode: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// 3. Attendance Entity (Rule 5: No pre-mark, tap toggles)
@Entity(
    tableName = "attendance",
    indices = [Index(value = ["workerId", "date"], unique = true)]
)
data class AttendanceEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val date: String // YYYY-MM-DD
)

// 4. Overtime Entity (Rule 6: Manual OT amount only)
@Entity(
    tableName = "overtime",
    indices = [Index(value = ["workerId", "date"], unique = true)]
)
data class OvertimeEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val date: String,
    val amount: Double
)

// 5. Worker Payment Entity
@Entity(tableName = "worker_payments")
data class WorkerPaymentEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val date: String,
    val amount: Double,
    val note: String,
    val createdAt: Long = System.currentTimeMillis()
)

// 6. Site Entity
@Entity(tableName = "sites")
data class SiteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val totalBill: Double,
    val startDate: String,
    val createdAt: Long = System.currentTimeMillis()
)

// 7. Site Payment Entity
@Entity(tableName = "site_payments")
data class SitePaymentEntity(
    @PrimaryKey val id: String,
    val siteId: String,
    val date: String,
    val amount: Double,
    val details: String,
    val createdAt: Long = System.currentTimeMillis()
)

// 8. Site Expense Entity (Rule 12: Never in PDF)
@Entity(tableName = "site_expenses")
data class SiteExpenseEntity(
    @PrimaryKey val id: String,
    val siteId: String,
    val date: String,
    val category: String, // "কর্মী খরচ" or "অন্যান্য খরচ"
    val workerCount: Int?,
    val details: String,
    val amount: Double,
    val createdAt: Long = System.currentTimeMillis()
)

// 9. Note Entity (Rule 6: single-line row, photo path)
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val text: String,
    val photoPath: String?,
    val createdAt: Long = System.currentTimeMillis()
)

// 10. Price Entity
@Entity(tableName = "prices")
data class PriceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String, // "ইলেক্ট্রিক", "প্লাম্বিং", "স্যানিটারি"
    val unit: String,
    val price: Double,
    val createdAt: Long = System.currentTimeMillis()
)

// 11. Settings Entity (PIN code never exported)
@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val theme: String = "ocean",
    val language: String = "bn",
    val hideMoney: Boolean = false,
    val pinLockEnabled: Boolean = false,
    val pinCode: String = "",
    val seedInitialized: Boolean = false
)
