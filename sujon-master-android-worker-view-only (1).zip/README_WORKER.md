# SUJON MASTER — Worker View-Only (Same App, Worker Code Login)

## Ja ache ei build e
- App khulle mode choice: Malik / Owner, Worker Hisab Dekhun.
- Worker login: sudhu Worker Code, kono worker list nei. Vul code e sudhu "Code vul".
  5 bar vul korle 30 second wait.
- Owner Team theke prottek worker er Worker Code set/change/clear kora jay (>=6 okkhor,
  okkhor+songkha, duplicate hole "Ei code agei ache"). Copy + WhatsApp share ache.
  Code change korle purano code sathe sathe bondho, clear/delete korle login bondho.
- Worker sudhu nijer monthly hisab dekhbe (month prev/next, summary, dark-box calendar,
  diner list, payment list, earned/taken/due, manual OT sudhu). Kono attendance,
  Taka Din, OT entry, edit, delete, PDF, Settings, bottom nav nei.
- Last updated + Refresh + Logout ache. Offline hole "Offline - purono hisab dekhacche".

## Live sync niye sotyi kotha (do not fake)
Ei project e kono server/backend nei, tai duita alada phone er moddhe auto live
refresh code diye hobe na. Ekhon ja kaj korbe:
1. Malik er phone e (same phone): worker code diye login korle hisab Room theke
   live banano hoy, sob somoy fresh.
2. Worker er phone e (alada phone): malik Team theke "Snapshot Share" tap kore
   oi worker er snapshot file ta WhatsApp e pathabe. Worker app e login page theke
   "Snapshot File Khulun" tap kore oi file ta khulbe, tarpor code diye login korbe.
   Worker phone e sudhu oi ekjon worker er snapshot thakbe, onno worker/site/
   daily/price/note er data kokhono download hobe na.
   Protibar hisab bodle gele malik notun snapshot pathabe, worker abar file khule
   Refresh korbe, Last updated time bodle jabe.
True live auto-refresh (malik hisab dilei worker er phone e nije theke asbe) er
jonno alada Firebase/Firestore project + security rules setup lagbe — seta ei
zip e nei, karon seta phone theke alada setup. Snapshot share tai ekhonkar
kaj korar rasta, eta fake live na.

## Test checklist
1. Owner code set korun, worker login korun — sudhu oi worker er hisab dekhabe.
2. Vul code e sudhu "Code vul".
3. Onno worker er code diye onno worker er hisab dekhabe na.
4. Owner 1 din uposthit dile, worker Refresh korle din + earned + due barbe.
5. Owner payment dile, taken barbe, due kombe.
6. Owner manual OT dile, OT total + due te sudhu oi amount jog hobe.
7. Worker page e kono edit/PDF/Settings button nei.
8. Worker phone e onno kono data nei (sudhu oi snapshot).
9. Offline e purono hisab + banner dekhabe.
10. Code change korle purano code kaj korbe na, notun code kaj korbe.
11. Code clear / worker delete korle login bondho.
12. Logout korle mode choice e fire jabe.
13. Owner er sob ager feature thik ache.
